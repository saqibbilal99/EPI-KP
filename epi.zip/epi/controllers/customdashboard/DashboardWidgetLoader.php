<?php
class DashboardWidgetLoader extends CI_Controller {

	public function __construct() {
		parent::__construct();
		/* $this -> load -> helper('dashboard_functions_helper');
		$this -> load -> helper('epi_functions_helper');
		authentication();
		$this -> load -> model('Common_model','common'); */
	}
	
	public function index(){}
}
?>