<?php
class Coverage_Detail extends CI_Controller {
	//================ Constructor function Starts Here ==================//
	public function __construct() {
		parent::__construct();
		$this -> load -> model ('vaccination/Crud_model',"crud");
		$this -> load -> model ('Common_model',"common");
	}
	
	//====================== Constructor Function Ends Here ==========================//
	//--------------------------------------------------------------------------------//
	public function get_coverage_record(){
		//echo 'bb'; exit();
		$fmonth = $this -> input-> post('fmonth');
		$uncode = $this -> input-> post('uncode');
		//print_r($fmonth);  print_r($uncode);  exit(); 
		$req = array(
            'fmonth' => $fmonth,
            'uncode' => $uncode
		);
        $fields_string = http_build_query($req);
        $curl = curl_init();
		//curl_setopt($curl, CURLOPT_URL,"");
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($curl, CURLOPT_CUSTOMREQUEST, "POST");
        curl_setopt($curl, CURLOPT_POSTFIELDS,$fields_string);
        if (curl_exec($curl)) { //echo 'a';  exit(); 
			if (curl_getinfo($curl, CURLINFO_HTTP_CODE) == 200) {
				$result = curl_exec ($curl);
                curl_close ($curl);
				$data['result'] = $this -> crud -> checkcoverage_record($fmonth,$uncode);
				if(empty($data['result']))
				{ //insert
					
				}else{ //update
					
				}
			}else{
				// 404 or something, delete file
                $result = array("success"=>"False","message"=>" error 404");
                $res = json_encode($result);
                $data = array(
					'type'      => 'down',
					'table_name' =>'fac_mvrf_db',
					'data' => '',
					'request_json'=>$fields_string,
					'response_json'=>$res,
					"created_date" => date("Y-m-d"),
					"updated_date" => date("Y-m-d")
				);
                $this -> common -> insert_record('down_sync_history',$data);
                echo json_encode($result);exit;
			}  
		}else{  //echo 'b';  exit(); 
            // network error or server down
            $result = array("success"=>"False","message"=>"no internet");
            $res = json_encode($result);
			$data = array(
                'type'      => 'down',
                'table_name' =>'fac_mvrf_db',
                'data' => '',
				'request_json'=>$fields_string, 
                'response_json'=>$res,
				"created_date" => date("Y-m-d"),
				"updated_date" => date("Y-m-d")
			);
			//print_r($data); exit();
			$this -> common -> insert_record('down_sync_history',$data);
            echo json_encode($result);exit;
        }
	}
	
}
?>