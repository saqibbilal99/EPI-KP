<?php
//Live
class District_committee_notified extends CI_Controller{
	//================ Constructor function starts==================//
	public function __construct(){
		parent::__construct();	
		$this -> load -> helper('epi_functions_helper'); 
		$this -> load -> helper('epi_reports_helper');
		authentication();
		$this -> load -> model('communication/District_committee_notified_model','notified');
		$this -> load -> model('Common_model');
	}
	public function Reports_Filters($reportName){
		//echo "i am here";exit;
		$data['data'] = $this -> notified -> Create_Reporting_Filters($reportName);
		//$data['data']=$data;
		if($data != 0){
            $data['fileToLoad'] = 'reports/reports_filters';
			$data['pageTitle']='Report Filters';
			$this -> load -> view('template/epi_template',$data);
		}
		else{
			$data['message']="You must have rights to access this page.";
			$this -> load -> view("message",$data);
		}
	}
	public function notified(){
		//print_r($_POST); exit();
		$data['sessiondistcode'] = $this-> session-> District;
		$year = $this-> input-> post('year');
		$data['data'] = $this-> notified-> district_committee_notified($year);
		//print_r($data); exit();
		$data['data']['exportIcons'] = exportIcons($_REQUEST);
		$data['fileToLoad'] = 'communication/district_committee_notified';
		$data['pageTitle'] = 'District Committee Notified Compliance | EPI-MIS';
		$this->load->view('template/reports_template',$data);		
	}
	function getPostedData(){
		$data=array();$dataPosted=array();
		$dataPosted = $_POST;
		$formats = array("d/m/Y","d-m-Y","Y-m-d","m-d-Y","d-M-y");
		foreach($dataPosted as $key => $value)
		{
			$data[$key] = (($value=='')?NULL:$value);
			foreach ($formats as $format)
			{
				$date = DateTime::createFromFormat($format, $data[$key]);
				if ($date == false || !(date_format($date,$format) == $data[$key]) ) 
				{}
				else
				{
					$data[$key] = date("Y-m-d",strtotime($data[$key]));
				}
			}
			if($data[$key] == NULL || $data[$key]=="0")
				unset($data[$key]);
		}
		return $data;
	}
}
?>