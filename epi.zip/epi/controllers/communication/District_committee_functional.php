<?php
class District_committee_functional extends CI_Controller {
	//================ Constructor function Starts Here ==================//
	public function __construct() {
		parent::__construct();
		$this -> load -> model('communication/District_committee_functional_model','functional');
		$this -> load -> helper('epi_functions_helper');
		$code = md5(date("Y-n-d"));
		if(isset($_REQUEST['code']) && $_REQUEST['code'] == $code){
			$provinceCode = $_REQUEST['procode']; // procode during drilldown from Federal EPI
			$provinceName = get_Province_Name($provinceCode); // province name based on procode
			$sessionData = array(
				'username'  => "EPI Manager",
				'User_Name' => "EPI Manager",
				'federaluser' => true,
				'UserAuth'  => "Yes",
				'UserLevel' => '2',
				'UserType' => 'Manager',
				'utype' => 'Manager',
				'provincename' => $provinceName,
				'Province' => $provinceCode,
				'loginfrom' => "Pakistan EPI"
			);
			$this -> session -> set_userdata($sessionData);
		}else{
			if($this -> session -> UserAuth == 'Yes'){}else{
				authentication();
			}
		}
		//authentication();
		$this -> load -> model('Common_model');
	}
	
	//====================== Constructor Function Ends Here ==========================//
	//======= Function to Create Filters for Sepecific Reports Starts Here ===========//
	public function Reports_Filters($reportName){
		//echo "i am here";exit;
		$data['data'] = $this-> functional-> Create_Reporting_Filters($reportName);
		//$data['data']=$data;
		if($data != 0){
            $data['fileToLoad'] = 'reports/reports_filters';
			$data['pageTitle']='Report Filters';
			$this -> load -> view('template/epi_template',$data);
		}
		else{
			$data['message']="You must have rights to access this page.";
			$this -> load -> view("message",$data);
		}
	}

	public function committee_functional()
	{
		//print_r($_POST); exit();
		$data['sessiondistcode'] = $this-> session-> District;
		$year = $this-> input-> post('year');
		$data['data'] = $this-> functional-> district_committee_functional($year);
		//print_r($data); exit();
		$data['data']['exportIcons'] = exportIcons($_REQUEST);
		$data['fileToLoad'] = 'communication/district_committee_functional';
		$data['pageTitle']='District Committee Functional Compliance';
		$this -> load -> view('template/reports_template',$data);
	}	
	function getPostedData(){
		$data=array();$dataPosted=array();
		$dataPosted = $_POST;
		$formats = array("d/m/Y","d-m-Y","Y-m-d","m-d-Y","d-M-y");
		foreach($dataPosted as $key => $value)
		{
			$data[$key] = (($value=='')?NULL:$value);
			foreach ($formats as $format)
			{
				$date = DateTime::createFromFormat($format, $data[$key]);
				if ($date == false || !(date_format($date,$format) == $data[$key]) ) 
				{}
				else
				{
					$data[$key] = date("Y-m-d",strtotime($data[$key]));
				}
			}
			if($data[$key] == NULL || $data[$key]=="0")
				unset($data[$key]);
		}
		return $data;
	}
	
}
?>