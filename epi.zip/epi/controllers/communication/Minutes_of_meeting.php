<?php 
//Live
	class Minutes_of_meeting extends CI_Controller{
		//================ Constructor function starts==================//
		public function __construct(){
			parent::__construct();	
			$this -> load -> helper('epi_functions_helper'); 
			$this -> load -> model('Common_model');
			//$this -> load -> helper('epi_reports_helper');
			authentication();
			$this -> load -> model('communication/Minutes_of_meeting_model','minutes_of_meeting');
		}

		public function minutes_of_meeting_list(){
			//Code for Pagination
			$page = (int)(!($this -> input -> get('page')) ? 1 : $this -> input -> get('page'));
			if ($page <= 0){
				$page = 1;
			}
			$per_page = 20;
			// Set how many records do you want to display per page.
			$startpoint = ($page * $per_page) - $per_page;
			$statement = "minutes_of_meeting_db ";
			
			$data = $this -> minutes_of_meeting -> minutes_of_meeting_list($per_page,$startpoint);
			$data['pagination'] = $this -> Common_model -> pagination($statement, $per_page, $page, $url = '?');
			$data['UserLevel'] = $this -> session -> UserLevel;
			$data['startpoint'] = ($page * $per_page) - $per_page;
			if ($data != 0) {
				$data['data'] = $data;
				$data['fileToLoad'] = 'communication/minutes_of_meeting_list';
				$data['pageTitle'] = 'District Committe Notified | EPI-MIS';
				$this -> load -> view('template/epi_template', $data);
			}
			else {
				$data['message'] = "You must have rights to access this page.";
				$this -> load -> view("message", $data);
			}
		}

		public function upload_minutes_of_meeting($data=NULL){
			$data['data'] = '';
			$data['fileToLoad'] = 'communication/upload_minutes_of_meeting';
			$data['pageTitle'] = 'EPI-MIS | Upload Minutes of Meeting';
			$this -> load -> view('template/epi_template', $data);
		}

		public function minutes_of_meeting_save(){
			//print_r($_POST); exit();
			//$master_id = $this-> input-> post('master_id');
			$procode = $_SESSION['Province'];
			$distcode = $this -> session -> District;
			$type_of_minutes = $this-> input-> post('type_of_minutes');
			$year = $this-> input-> post('year');
			$quarter = ($this-> input-> post('quarter'))?$this-> input-> post('quarter'):0;
			$month = ($this-> input-> post('month'))?$this-> input-> post('month'):"";
			$remarks = $this-> input-> post('remarks');
			// if($quarter>0){
			// 	$quarter = 'Q'.$quarter;
			// }
			if($type_of_minutes == 'yearly' || $type_of_minutes == 'quarterly'){
				$month = "";
			}
			if($distcode>0){
				$wc = " distcode = '$distcode' ";
			}
			else{
				$wc = " procode = '$procode' ";
			}
			$query = "SELECT max(group_id) as max_id from minutes_of_meeting_db";
			//echo $query; exit();
			$resultGroupid = $this -> db -> query($query);
			$result = $resultGroupid -> row();
			$group_id = $result->max_id;
			$group_id = (int)$group_id+1;
			$date = date('Y-m-d');
			if(!empty($_FILES)){
				$total = count($_FILES['file']['name']);
				//echo $total; exit();
				$minutes_data = array(
					'distcode' => $distcode,
					'group_id'=>$group_id,
					'type_of_minutes' =>$type_of_minutes,
					'year' => $year,
					'quarter' => $quarter,
					'month' => $month,
					'remarks' => $remarks,
					'submitted_date' => $date
				);
				$this-> minutes_of_meeting-> minutes_of_meeting_save_model($minutes_data);
				for($i=0; $i < $total; $i++) {
					//foreach($_FILES['file']['name'] as $key => $val){
					$fileName = $_FILES['file']['name'][$i];
					$fileArray = explode('.', $fileName);
					$fileExt = end($fileArray);
					$date1 = date('Y-m-d H:i:s');
					//echo $fileExt; exit();
					//$fileName = $date1."-".$uncode.".".$fileExt;
					$fileName = $distcode."-".$date1."-".$type_of_minutes."-(".$i.").".$fileExt;
					//echo $fileName; exit();
					$temp = $_FILES['file']['tmp_name'][$i];
					//echo $temp; exit();
					$dir_separator = DIRECTORY_SEPARATOR;
					$folder = "minutes_of_meeting";
					$destination_path = FCPATH.$dir_separator.$folder.$dir_separator;
					$target_path = $destination_path.$fileName;
					//echo $destination_path; exit();
					move_uploaded_file($temp, $target_path);					
					$minutes_uploads = array(
						'distcode' => $distcode,
						'group_id'=>$group_id,
						'uploaded_file_name' => $fileName,
						'submitted_date' => $date
					);
					//print_r($minutes_data); //exit();
					$this-> minutes_of_meeting-> minutes_uploaded_files_model($minutes_uploads);
				}
			}
			redirect('Minutes_of_Meeting_List');
		}

		public function minutes_of_meeting_view($data=NULL){
			$group_id = $this -> input -> get_post('group_id');
			$drilldownDistcode = $this -> input -> get_post('distcode');
			$drilldownYear = $this -> input -> get_post('year');
			$drilldownQuarter = $this -> input -> get_post('quarter');
			$drilldownMonth = $this -> input -> get_post('month');
			$drilldown = $this -> input -> get_post('drilldown');
			//echo $group_id; exit();
			if(!isset($group_id)){
				if(isset($drilldownQuarter)){
					$query = "SELECT group_id as drilldown_id from minutes_of_meeting_db where year='$drilldownYear' and quarter=$drilldownQuarter ";
				}
				if(isset($drilldownMonth)){
					$query = "SELECT group_id as drilldown_id from minutes_of_meeting_db where year='$drilldownYear' and month='$drilldownMonth' ";
				}
				//echo $query; exit();
				$resultGroupid = $this -> db -> query($query);
				$result = $resultGroupid -> row();
				$drilldown_id = $result->drilldown_id;
				$drilldown_id = (int)$drilldown_id;
				$group_id = $drilldown_id;
			}

			$data['data'] = '';
			$query = "SELECT districtname(distcode) AS district, group_id, type_of_minutes, year, quarter, month, remarks FROM minutes_of_meeting_db where group_id=$group_id ";
			$results = $this -> db -> query($query);
			$data['minutes_data'] = $results -> result_array();

			$query = "SELECT districtname(distcode) AS district, group_id, uploaded_file_name FROM minutes_uploaded_files_db where group_id=$group_id ";
			$results = $this -> db -> query($query);
			$data['minutes_uploads'] = $results -> result_array();
			$data['drilldownDistcode'] = $drilldownDistcode;
			$data['drilldown'] = $drilldown;
			$data['fileToLoad'] = 'communication/view_minutes_of_meeting';
			$data['pageTitle'] = 'EPI-MIS | Minutes of Meeting View';
			$this -> load -> view('template/epi_template', $data);
		}

		public function delete_by_group_id($group_id){
			$this-> minutes_of_meeting-> delete_by_group_id($group_id);
			//echo "Done"; exit;
		}

		public function check_minutes_of_meeting(){
			$distcode = $this -> session -> District;
			$type_of_minutes = $this -> input -> post('type_of_minutes');
			$year = $this -> input -> post('year');
			$quarter = $this -> input -> post('quarter');
			$month = $this -> input -> post('month');
			$data=$this -> minutes_of_meeting -> check_minutes_of_meeting($distcode,$type_of_minutes,$year,$quarter,$month);
			echo $data;
		}

		public function minutes_of_meeting_filter(){
			//print_r($_POST); exit();
			$type_of_minutes = $this-> input-> get('type_of_minutes');
			$year = $this-> input-> get('year');
			$data = $this-> minutes_of_meeting-> minutes_of_meeting_filter($type_of_minutes, $year);
			echo $data;
		}
	}
?>