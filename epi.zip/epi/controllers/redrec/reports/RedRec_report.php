<?php 
	class RedRec_report extends CI_Controller {
	//================ Constructor Function Starts ==================//
	public function __construct() {
		parent::__construct();
		
		$this -> load -> model('Compliances_model');
		$this -> load -> model('redrec_model/reports/Redrec_reportmodel');
		$this -> load -> helper('epi_functions_helper');
		date_default_timezone_set("Asia/Karachi");
		$this -> load -> model('Common_model');
		$this -> load -> model('Filter_model');
		$this->load->helper('my_functions_helper');
		$this -> load -> helper('epi_reports_helper');
	}
	public function redrec_Filters(){
		$this -> load -> library('reportfilters');
		$functionName = $this -> uri -> segment (2);
		
		$functionName = str_replace("-", "_", $functionName);
		$reportPath = base_url()."redrec/reports/RedRec_report/".$functionName;
		$reportTitle = $this->reportTitle($functionName);
		//print_r($functionName);exit;
		$array =array(
					array(
						'0' => 'Quarter',// Custom Drop Down Name Should be in this format
						'1' => 'Quarter 1',
						'2' => 'Quarter 2',
						'3' => 'Quarter 3',
						'4' => 'Quarter 4'
					)
				);
		$dataHtml = $this->reportfilters->filtersHeader($reportPath,$reportTitle);
		$dataHtml .= $this->reportfilters->createReportFilters(true,true,true,true,$reportsperiod=array("yearly"),false,NULL,NULL,'No','No',NULL,$array);
		$dataHtml .= $this->reportfilters->filtersFooter();
		//
		$data['listing_filters'] = $dataHtml;
		$data['data']=$data;
		$data['edit'] = "Yes";
//		$data['fileToLoad'] = 'reports/reports_filters';
		$data['fileToLoad'] = 'redrec_view/reports/Reports_filter';
		$data['pageTitle']='EPI-MIS Report Filters';
		
		$this -> load -> view('template/epi_template',$data);
		
	}
	function Quartely_Schedule_plane(){
	//	echo'sa';exit;
		$data = $this -> getPostedData();
		if(isset($data['distcode']))
			$dist = $data['distcode'];
		//print_r($data);exit;
		else 
		$dist = '';
		$quarter = $data['quarter'];
		$year = $data['year'];	
		$data['data'] = $this ->Redrec_reportmodel->Quartely_Schedule_plane($data);
		$data['distcode'] = $dist;
		$data['quarter'] = $quarter;
		$data['year'] = $year;
		$data['data']['TopInfo'] = reportsTopInfo("Quarterly Schedule Plan", $data);
		$data['data']['exportIcons']=exportIcons($_REQUEST);
		$data['fileToLoad'] = 'redrec_view/reports/Reports_schedule_view';
		$data['pageTitle']='Quarterly Schedule Plan Report';
		$this -> load -> view('template/reports_template',$data);
		/* 
		$data = $this -> getPostedData();
		$data['data'] = $this ->Redrec_reportmodel->redrec_Report($data);
		if($data != 0){
		$this->load->view('Add_red_microplanning/reports/Reports_view',$data);
		}else{
		$data['message']="You must have rights to access this page.";
		$this->load->view("message",$data);
		} */
	}
	
	function Quartely_Datewise_plane(){
		//echo'sd';exit;
		$data = $this -> getPostedData();
		if(isset($data['distcode']))
			$dist = $data['distcode'];
		//print_r('$dist');exit;
		else 
		$dist = '';
		$quarter = $data['quarter'];
		$year = $data['year'];
		$data['data'] = $this ->Redrec_reportmodel->Quartely_Datewise_plane($data);
		$data['distcode'] = $dist;
		$data['quarter'] = $quarter;
		$data['year'] = $year;
		$data['data']['TopInfo'] = reportsTopInfo("Quarterly Datewise Plan", $data);
		$data['data']['exportIcons']=exportIcons($_REQUEST);
		$data['fileToLoad'] = 'redrec_view/reports/Reports_datewise_view';
		$data['pageTitle']='Quarterly Schedule Plan Report';
		$this -> load -> view('template/reports_template',$data);
	
		/* 
		$data = $this -> getPostedData();
		$data['data'] = $this ->Redrec_reportmodel->redrec_Report($data);
		if($data != 0){
		$this->load->view('Add_red_microplanning/reports/Reports_view',$data);
		}else{
		$data['message']="You must have rights to access this page.";
		$this->load->view("message",$data);
		} */
	}
	 function reportTitle($functionName){
		$title = "";
		switch($functionName){
			case "Quartely_Schedule_plane":
			case "Quartely_Schedule_plane ":
			$title = "Quarterly Schedule Plan Report";
			break;
			case "Quartely_Datewise_plane":
			case "Quartely_Datewise_plane ":
			$title = "Quarterly Datewise Plan Report";
			break;
		}
		return $title;
	} 
	function getPostedData(){
		$data=array();$dataPosted=array();
		$dataPosted = $_POST;
		$formats = array("d/m/Y","d-m-Y","Y-m-d","m-d-Y","d-M-y");
		foreach($dataPosted as $key => $value){
			$data[$key] = (($value=='')?NULL:$value);
			foreach ($formats as $format){
				$date = DateTime::createFromFormat($format, $data[$key]);
				if ($date == false || !(date_format($date,$format) == $data[$key]) ) 
				{}else{
					$data[$key] = date("Y-m-d",strtotime($data[$key]));
				}
			}
			if($data[$key] == NULL || $data[$key]=="0")
				unset($data[$key]);
		}
		return $data;
	}
}
?>
