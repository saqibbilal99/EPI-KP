<?php 
class Microplan_yearly extends CI_Controller{
		//================ Constructor function starts==================//
	public function __construct(){
		parent::__construct();
		
		$this-> load-> model('redrec_model/dataentry/Microplan_yearly_model');
		//$this-> load-> model('redrec_model/dataentry/Microplan_yearly_modelm');
		authentication();
		$this-> load-> helper('epi_functions_helper'); 
		$this-> load-> helper('epi_reports_helper'); 
	}
	public function microplan_yearly_list(){
		$data['data'] = $this->  Microplan_yearly_model->microplan_yearly_list();
		$data['fileToLoad'] = 'redrec_view/dataentry/microplan_yearly_list';
		$data['pageTitle'] = 'Red Micro Plannning | EPI-MIS';
		$this-> load-> view('template/epi_template',$data);
	}
	public function microplan_yearly_add(){
		$distcode = $this-> session-> District; 
		$data['data'] = $this-> Microplan_yearly_model-> microplan_yearly_add_model($distcode);
		$data['fileToLoad'] = 'redrec_view/dataentry/microplan_yearly_add';
		$data['pageTitle'] = 'RED/REC Micro Plannning | EPI-MIS';
		$this-> load-> view('template/epi_template',$data);	
	}
	public function microplan_yearly_edit(){
		$uncode = $this-> uri ->segment(5);
		$year = $this-> uri ->segment(6);
		$facode = $this-> uri ->segment(7);
		//$master_id = $this-> uri ->segment(8);
		//print_r($techniciancode);exit;
		$data['data'] = $this-> Microplan_yearly_model-> microplan_yearly_editb_model($uncode,$year,$facode);
		//print_r($data); exit;
		$data['fileToLoad'] = 'redrec_view/dataentry/microplan_yearly_edit';
		$data['pageTitle'] = 'RED/REC Micro Plannning | EPI-MIS';
		$this-> load-> view('template/epi_template',$data);	
	}
	public function situation_analysis_save(){
		//print_r($_POST); exit();
	    $update=$this ->input -> post ('update');
		$situationAnalysisData = array(
			'edit' => ($this ->input -> post ('edit')) ? $this ->input -> post ('edit') : Null ,
			'add_edit' => ($this ->input -> post ('add_edit')) ? $this ->input -> post ('add_edit') : Null ,
			'procode' => $this -> session -> Province,
			'distcode' => $this -> session -> District,
			'tcode' => ($this ->input -> post ('tcode')) ? $this ->input -> post ('tcode') : Null ,
			'uncode' => ($this ->input -> post ('uncode')) ? $this ->input -> post ('uncode') : Null,
			'facode' => ($this ->input -> post ('facode')) ? $this ->input -> post ('facode') : Null, 
			'techniciancode' => ($this ->input -> post ('techniciancode')) ? $this ->input -> post ('techniciancode') : Null ,
			'year' => ($this ->input -> post ('year')) ? $this ->input -> post ('year') : Null ,
			//'master_id' => ($this ->input -> post ('master_id')) ? $this ->input -> post ('master_id') : Null ,
			'recid' => ($this ->input -> post ('recid')) ? $this ->input -> post ('recid') : Null ,
			'v_code' => ($this ->input -> post ('v_code')) ? $this ->input -> post ('v_code') : Null ,
			'village_merger_id' => ($this ->input -> post ('village_merger_id')) ? $this ->input -> post ('village_merger_id') : Null ,
			'less_one_year' => ($this ->input -> post ('less_one_year')) ? $this ->input -> post ('less_one_year') : Null, 
			'f3_total_population' => ($this ->input -> post ('f3_total_population')) ? $this ->input -> post ('f3_total_population') : Null, 
			'penta1' => ($this ->input -> post ('penta1')) ? $this ->input -> post ('penta1') : Null, 
			'penta3' => ($this ->input -> post ('penta3')) ? $this ->input -> post ('penta3') : Null, 
			'measles' => ($this ->input -> post ('measles')) ? $this ->input -> post ('measles') : Null, 
			'tt2' => ($this ->input -> post ('tt2')) ? $this ->input -> post ('tt2') : Null, 
			'penta1_percent' => ($this ->input -> post ('penta1_percent')) ? $this ->input -> post ('penta1_percent') : Null, 
			'penta3_percent' => ($this ->input -> post ('penta3_percent')) ? $this ->input -> post ('penta3_percent') : Null, 
			'measles_percent' => ($this ->input -> post ('measles_percent')) ? $this ->input -> post ('measles_percent') : Null, 
			'tt2_percent' => ($this ->input -> post ('tt2_percent')) ? $this ->input -> post ('tt2_percent') : Null, 
			'penta3_not' => ($this ->input -> post ('penta3_not')) ? $this ->input -> post ('penta3_not') : Null, 
			'measles_not' => ($this ->input -> post ('measles_not')) ? $this ->input -> post ('measles_not') : Null, 
			'penta1penta3' => ($this ->input -> post ('penta1penta3')) ? $this ->input -> post ('penta1penta3') : Null, 
			'penta1measles' => ($this ->input -> post ('penta1measles')) ? $this ->input -> post ('penta1measles') : Null, 
			'access' => ($this ->input -> post ('access')) ? $this ->input -> post ('access') : Null, 
			'utilization' => ($this ->input -> post ('utilization')) ? $this ->input -> post ('utilization') : Null, 
			'category' => ($this ->input -> post ('category')) ? $this ->input -> post ('category') : Null, 
			'priority' => ($this ->input -> post ('priority')) ? $this ->input -> post ('priority') : Null, 
			'id' => ($this ->input -> post ('id')) ? $this ->input -> post ('id') : Null, 
			//'plan_id' => ($this ->input -> post ('plan_id')) ? $this ->input -> post ('plan_id') : Null, 
			'submitted_date' => ($this ->input -> post ('submitted_date')) ? $this ->input -> post ('submitted_date') : Null, 
		);
		//print_r($situationAnalysisData); exit();
		$data['data'] = $this-> Microplan_yearly_model-> situation_analysis_save_model($situationAnalysisData);
		//print_r($data['data']);exit();
		if (isset($update) && $update=='update'){
			//echo 'test1'; exit();
			$data['fileToLoad'] = 'redrec_view/dataentry/Planning_problem_area_edit';
		}else{
			//echo 'test2'; exit();
			$data['fileToLoad'] = 'redrec_view/dataentry/Planning_problem_area_add';
		}
		$data['pageTitle'] = 'RED/REC Micro Plannning | EPI-MIS';
		$this-> load-> view('template/epi_template',$data);
	}
	public function situation_analysis_edit(){
		$uncode = $this-> uri ->segment(5);
		$year = $this-> uri ->segment(6);
		$facode = $this-> uri ->segment(7);
		$data['data'] = $this-> Microplan_yearly_model-> situation_analysis_edit_model($uncode,$year,$facode);
		$data['fileToLoad'] = 'redrec_view/dataentry/situation_analysis_edit';
		$data['pageTitle'] = 'RED/REC Micro Plannning | EPI-MIS';
		$this-> load-> view('template/epi_template',$data);	
	}
	public function situation_analysis_view(){
		$uncode = $this-> uri ->segment(5);
	    $year = $this-> uri ->segment(6);
		$facode = $this-> uri ->segment(7);
		$data['data'] = $this-> Microplan_yearly_model-> situation_analysis_view($uncode,$year,$facode);
		$data['fileToLoad'] = 'redrec_view/dataentry/situation_analysis_view';
		$data['pageTitle'] = 'RED/REC Micro Plannning | EPI-MIS';
		$this-> load-> view('template/epi_template',$data);
	}	
	public function planning_problem_area_save(){
		$planningProblemData= array(
			'uncode' => ($this ->input -> post ('uncode')) ? $this ->input -> post ('uncode') : Null,
			//'techniciancode' => ($this ->input -> post ('techniciancode')) ? $this ->input -> post ('techniciancode') : Null,
			'facode' => ($this ->input -> post ('facode')) ? $this ->input -> post ('facode') : Null,
			'year' => ($this ->input -> post ('year')) ? $this ->input -> post ('year') : Null ,
			'hard_to_reach' => ($this ->input -> post ('hard_to_reach')) ? $this ->input -> post ('hard_to_reach') : Null, 
			'reached_last_year' => ($this ->input -> post ('reached_last_year')) ? $this ->input -> post ('reached_last_year') : Null, 
			'activities_improve_hf'=> ($this ->input -> post ('activities_improve_hf')) ? $this ->input -> post ('activities_improve_hf') : Null,
			'activities_need_support' => ($this ->input -> post ('activities_need_support')) ? $this ->input -> post ('activities_need_support') : Null, 
			'interventions_delivered' => ($this ->input -> post ('interventions_delivered')) ? $this ->input -> post ('interventions_delivered') : Null, 
			'v_code' => ($this ->input -> post ('v_code')) ? $this ->input -> post ('v_code') : Null, 
			'rec_id' => ($this ->input -> post ('rec_id')) ? $this ->input -> post ('rec_id') : Null, 
		);
		$data['data'] = $this-> Microplan_yearly_model-> planning_problem_area_save_model($planningProblemData);
		$data['fileToLoad'] = 'redrec_view/dataentry/session_plan_area_add';
		$data['pageTitle'] = 'RED/REC Micro Plannning | EPI-MIS';
		$this-> load-> view('template/epi_template',$data);	
	}
	public function planning_problem_area_edit(){	
		$uncode = $this-> uri ->segment(5);
		$year = $this-> uri ->segment(6);
		$facode = $this-> uri ->segment(7);
		//$master_id = $this-> uri ->segment(8);
		$data['data'] = $this-> Microplan_yearly_model-> planning_problem_area_edit_model($uncode,$year,$facode);
		//print_r($data); exit;
		$data['fileToLoad'] = 'redrec_view/dataentry/Planning_problem_area_edit';
		$data['pageTitle'] = 'RED/REC Micro Plannning | EPI-MIS';
		$this-> load-> view('template/epi_template',$data);	
	}
	public function planning_problem_area_view(){
		$uncode = $this-> uri ->segment(5);
	    $year = $this-> uri ->segment(6);
		$facode = $this-> uri ->segment(7);
		$data['data'] = $this-> Microplan_yearly_model-> planning_problem_area_view($uncode,$year,$facode);
		$data['fileToLoad'] = 'redrec_view/dataentry/planning_problem_area_view';
		$data['pageTitle'] = 'RED/REC Micro Plannning | EPI-MIS';
		$this-> load-> view('template/epi_template',$data);
	}
	public function session_plan_area_save(){
		$sessionplanData=array(
			'uncode' => ($this ->input -> post ('uncode')) ? $this ->input -> post ('uncode') : Null,
			'facode' => ($this ->input -> post ('facode')) ? $this ->input -> post ('facode') : Null,
			//'techniciancode' => ($this ->input -> post ('techniciancode')) ? $this ->input -> post ('techniciancode') : Null,
			'year' => ($this ->input -> post ('year')) ? $this ->input -> post ('year') : Null ,
			'total_population' => ($this ->input -> post ('total_population')) ? $this ->input -> post ('total_population') : Null ,
			'target_population' => ($this ->input -> post ('target_population')) ? $this ->input -> post ('target_population') : Null ,
			'session_type' => ($this ->input -> post ('session_type')) ? $this ->input -> post ('session_type') : Null ,
			'injections_per_year' => ($this ->input -> post ('injections_per_year')) ? $this ->input -> post ('injections_per_year') : Null ,
			'injections_per_month' => ($this ->input -> post ('injections_per_month')) ? $this ->input -> post ('injections_per_month') : Null ,
			'estimated_sessions' => ($this ->input -> post ('estimated_sessions')) ? $this ->input -> post ('estimated_sessions') : Null ,
			'sessions_per_month'=> ($this ->input -> post ('sessions_per_month')) ? $this ->input -> post ('sessions_per_month') : Null ,
			'actual_sessions_plan' => ($this ->input -> post ('actual_sessions_plan')) ? $this ->input -> post ('actual_sessions_plan') : Null ,
			'child_survival_interventions' => ($this ->input -> post ('child_survival_interventions')) ? $this ->input -> post ('child_survival_interventions') : Null ,
			'hard_to_reach' => ($this ->input -> post ('hard_to_reach')) ? $this ->input -> post ('hard_to_reach') : Null ,
			'hard_to_reach_population' => ($this ->input -> post ('hard_to_reach_population')) ? $this ->input -> post ('hard_to_reach_population') : Null ,		
			'v_code' => ($this ->input -> post ('v_code')) ? $this ->input -> post ('v_code') : Null ,		
			'rec_id' => ($this ->input -> post ('rec_id')) ? $this ->input -> post ('rec_id') : Null ,		
		);
		$data['data'] = $this-> Microplan_yearly_model-> session_plan_area_save_model($sessionplanData);
		$data['fileToLoad'] = 'redrec_view/dataentry/red_strategy_add';
		$data['pageTitle'] = 'RED/REC Micro Plannning | EPI-MIS';
		$this-> load-> view('template/epi_template',$data);
	}
	public function session_plan_area_edit(){	
		$uncode = $this-> uri ->segment(5);
		$year = $this-> uri ->segment(6);
		$facode = $this-> uri ->segment(7);
		$data['data'] = $this-> Microplan_yearly_model-> session_plan_area_edit_model($uncode,$year,$facode);
		$data['fileToLoad'] = 'redrec_view/dataentry/session_plan_area_edit';
		$data['pageTitle'] = 'RED/REC Micro Plannning | EPI-MIS';
		$this-> load-> view('template/epi_template',$data);	
	}
    public function session_plan_view(){
		$uncode = $this-> uri ->segment(5);
	    $year = $this-> uri ->segment(6);
		$facode = $this-> uri ->segment(7);
		$data['data'] = $this-> Microplan_yearly_model-> session_plan_view($uncode,$year,$facode);
		//print_r($data); exit;
		$data['fileToLoad'] = 'redrec_view/dataentry/session_plan_view';
		$data['pageTitle'] = 'RED/REC Micro Plannning | EPI-MIS';
		$this-> load-> view('template/epi_template',$data);
	}
	public function red_strategy_save(){
		//print_r($_POST);exit;
		$redstrategyData=array(
			'uncode' => ($this ->input -> post ('uncode')) ? $this ->input -> post ('uncode') : Null,
			'facode' => ($this ->input -> post ('facode')) ? $this ->input -> post ('facode') : Null,
			//'techniciancode' => ($this ->input -> post ('techniciancode')) ? $this ->input -> post ('techniciancode') : Null,
			'year' => ($this ->input -> post ('year')) ? $this ->input -> post ('year') : Null ,
			'rec_id' => ($this ->input -> post ('rec_id')) ? $this ->input -> post ('rec_id') : Null ,
			'v_code' => ($this ->input -> post ('v_code')) ? $this ->input -> post ('v_code') : Null ,
			//for r1
			'problems_r1_c1' => ($this ->input -> post ('problems_r1_c1')) ? $this ->input -> post ('problems_r1_c1') : Null ,
			'actlimitres_r1_c2' => ($this ->input -> post ('actlimitres_r1_c2')) ? $this ->input -> post ('actlimitres_r1_c2') : Null ,
			'actneedresources_r1_c3' => ($this ->input -> post ('actneedresources_r1_c3')) ? $this ->input -> post ('actneedresources_r1_c3') : Null ,
			'date_r1_c4' => ($this ->input -> post ('date_r1_c4')) ? $this ->input -> post ('date_r1_c4') : Null ,
			'area_r1_c5' => ($this ->input -> post ('area_r1_c5')) ? $this ->input -> post ('area_r1_c5') : Null ,
			'person_r1_c6' => ($this ->input -> post ('person_r1_c6')) ? $this ->input -> post ('person_r1_c6') : Null ,
			//for r2
			'problems_r2_c1' => ($this ->input -> post ('problems_r2_c1')) ? $this ->input -> post ('problems_r2_c1') : Null ,
			'actlimitres_r2_c2' => ($this ->input -> post ('actlimitres_r2_c2')) ? $this ->input -> post ('actlimitres_r2_c2') : Null ,
			'actneedresources_r2_c3' => ($this ->input -> post ('actneedresources_r2_c3')) ? $this ->input -> post ('actneedresources_r2_c3') : Null ,
			'date_r2_c4' => ($this ->input -> post ('date_r2_c4')) ? $this ->input -> post ('date_r2_c4') : Null ,
			'area_r2_c5' => ($this ->input -> post ('area_r2_c5')) ? $this ->input -> post ('area_r2_c5') : Null ,
			'person_r2_c6' => ($this ->input -> post ('person_r2_c6')) ? $this ->input -> post ('person_r2_c6') : Null ,
			//for r3
			'problems_r3_c1' => ($this ->input -> post ('problems_r3_c1')) ? $this ->input -> post ('problems_r3_c1') : Null ,
			'actlimitres_r3_c2' => ($this ->input -> post ('actlimitres_r3_c2')) ? $this ->input -> post ('actlimitres_r3_c2') : Null ,
			'actneedresources_r3_c3' => ($this ->input -> post ('actneedresources_r3_c3')) ? $this ->input -> post ('actneedresources_r3_c3') : Null ,
			'date_r3_c4' => ($this ->input -> post ('date_r3_c4')) ? $this ->input -> post ('date_r3_c4') : Null ,
			'area_r3_c5' => ($this ->input -> post ('area_r3_c5')) ? $this ->input -> post ('area_r3_c5') : Null ,
			'person_r3_c6' => ($this ->input -> post ('person_r3_c6')) ? $this ->input -> post ('person_r3_c6') : Null ,
			//for r4
			'problems_r4_c1' => ($this ->input -> post ('problems_r4_c1')) ? $this ->input -> post ('problems_r4_c1') : Null ,
			'actlimitres_r4_c2' => ($this ->input -> post ('actlimitres_r4_c2')) ? $this ->input -> post ('actlimitres_r4_c2') : Null ,
			'actneedresources_r4_c3' => ($this ->input -> post ('actneedresources_r4_c3')) ? $this ->input -> post ('actneedresources_r4_c3') : Null ,
			'date_r4_c4' => ($this ->input -> post ('date_r4_c4')) ? $this ->input -> post ('date_r4_c4') : Null ,
			'area_r4_c5' => ($this ->input -> post ('area_r4_c5')) ? $this ->input -> post ('area_r4_c5') : Null ,
			'person_r4_c6' => ($this ->input -> post ('person_r4_c6')) ? $this ->input -> post ('person_r4_c6') : Null ,
			//for r5
			'problems_r5_c1' =>($this ->input -> post ('problems_r5_c1')) ? $this ->input -> post ('problems_r5_c1') : Null ,
			'actlimitres_r5_c2' => ($this ->input -> post ('actlimitres_r5_c2')) ? $this ->input -> post ('actlimitres_r5_c2') : Null ,
			'actneedresources_r5_c3' => ($this ->input -> post ('actneedresources_r5_c3')) ? $this ->input -> post ('actneedresources_r5_c3') : Null ,
			'date_r5_c4' => ($this ->input -> post ('date_r5_c4')) ? $this ->input -> post ('date_r5_c4') : Null ,
			'area_r5_c5' => ($this ->input -> post ('area_r5_c5')) ? $this ->input -> post ('area_r5_c5') : Null ,
			'person_r5_c6' => ($this ->input -> post ('person_r5_c6')) ? $this ->input -> post ('person_r5_c6') : Null ,
		);
		$data['data'] = $this-> Microplan_yearly_model-> red_strategy_save_model($redstrategyData);
		$data['fileToLoad'] = 'redrec_view/dataentry/red_map_add';
		$data['pageTitle'] = 'RED/REC Micro Plannning | EPI-MIS';
		$this-> load-> view('template/epi_template',$data);
	}
	public function red_strategy_edit(){
		$uncode = $this-> uri ->segment(5);
		$year = $this-> uri ->segment(6);
		$facode = $this-> uri ->segment(7);
		$data['data'] = $this-> Microplan_yearly_model-> red_strategy_edit_model($uncode,$year,$facode);
		$data['fileToLoad'] = 'redrec_view/dataentry/red_strategy_edit';
		$data['pageTitle'] = 'RED/REC Micro Plannning | EPI-MIS';
		$this-> load-> view('template/epi_template',$data);	
	}
	public function red_strategy_view(){
		$uncode = $this-> uri ->segment(5);
	    $year = $this-> uri ->segment(6);
		$facode = $this-> uri ->segment(7);
		$data['data'] = $this-> Microplan_yearly_model-> red_strategy_view($uncode,$year,$facode);
		//print_r($data); exit;
		$data['fileToLoad'] = 'redrec_view/dataentry/red_strategy_view';
		$data['pageTitle'] = 'RED/REC Micro Plannning | EPI-MIS';
		$this-> load-> view('template/epi_template',$data);
	}
	public function red_map_save(){
		//print_r($_POST); exit();
		//$master_id = $this-> input-> post('master_id');
		$facode = $this-> input-> post('facode');
		$uncode = $this-> input-> post('uncode');
		$year = $this-> input-> post('year');
		
		if(!empty($_FILES)){
			$fileName = $_FILES['file']['name'];
			$fileArray = explode('.', $fileName);
			$fileExt = end($fileArray);
			$date = date('Y-m-d H:i:s');
			//$fileName = $date."-".$uncode.".".$fileExt;
			$fileName = $date."-".$facode.".".$fileExt;
			$temp = $_FILES['file']['tmp_name'];
			$dir_separator = DIRECTORY_SEPARATOR;
			$folder = "uploads";
			$destination_path = FCPATH.$dir_separator.$folder.$dir_separator;
			$target_path = $destination_path.$fileName;
			move_uploaded_file($temp, $target_path);
			$date1 = date('Y-m-d');
			$red_map = array(
				'red_map' => $fileName,
				'date_red_map' => $date1,
			 );
			$this-> Microplan_yearly_model-> red_map_save_model($red_map,$uncode,$year,$facode);
		}
	}
	public function red_map_edit(){	
		$uncode = $this-> uri ->segment(5);
		//print_r($pk_id);exit;
		$year = $this-> uri ->segment(6);
		$facode = $this-> uri ->segment(7);
		$data['data'] = $this-> Microplan_yearly_model-> red_map_edit_model($uncode,$year,$facode);
		$data['fileToLoad'] = 'redrec_view/dataentry/red_map_edit';
		$data['pageTitle'] = 'RED/REC Micro Plannning | EPI-MIS';
		$this-> load-> view('template/epi_template',$data);
	}
    public function red_map_view(){
		$uncode = $this-> uri ->segment(5);
	    $year = $this-> uri ->segment(6);
		$facode = $this-> uri ->segment(7);
		$data['data'] = $this-> Microplan_yearly_model-> red_map_view($uncode,$year,$facode);
		//print_r($data); exit;
		$data['fileToLoad'] = 'redrec_view/dataentry/red_map_view';
		$data['pageTitle'] = 'RED/REC Micro Plannning | EPI-MIS';
		$this-> load-> view('template/epi_template',$data);
	}
	public function technician_attachment_view(){
		$uncode = $this-> uri ->segment(5);
	    $year = $this-> uri ->segment(6);
		$techniciancode = $this-> uri ->segment(7);
		$data['data'] = $this-> Microplan_yearly_model-> technician_attachment_view_model($uncode,$year,$techniciancode);
		//print_r($data); exit;
		$data['fileToLoad'] = 'redrec_view/dataentry/technician_attachment_view';
		$data['pageTitle'] = 'RED/REC Micro Plannning | EPI-MIS';
		$this-> load-> view('template/epi_template',$data); 
	}
	public function technician_attachment_save(){
		//print_r($_POST);exit;
		$tecniciandata=array(
			'facode' => ($this ->input -> post ('facode')) ? $this ->input -> post ('facode') : Null,
			'plan_id' => ($this ->input -> post ('plan_id')) ? $this ->input -> post ('plan_id') : Null ,
			'techniciancode' => ($this ->input -> post ('techniciancode')) ? $this ->input -> post ('techniciancode') : Null,
			
		);
		$data['data'] = $this-> Microplan_yearly_model-> technician_attachment_save_model($tecniciandata);
		//print_r($data); exit;
		$data['fileToLoad'] = 'redrec_view/dataentry/technician_attachment_view';
		$data['pageTitle'] = 'RED/REC Micro Plannning | EPI-MIS';
		$this-> load-> view('template/epi_template',$data); 
	}
}
?>