<?php
	class micro_plan_controller extends CI_Controller{
		//================ Constructor function starts==================//
		public function __construct(){
			parent::__construct();
			$this->load->model('Micro_plan_model','micro');
			authentication();
			$this -> load -> helper('epi_functions_helper'); 
		}
		public function supervisory_plan_add(){
			$data['data'] =	"";
			$data['fileToLoad'] = 'micro_plan/supervisory_plan_add';
			$data['pageTitle']='Micro Plan | EPI-MIS';
			$this->load->view('template/epi_template',$data);	
		}
		public function supervisory_plan_save(){
			//print_r($_POST);exit();
			$idm1=$this->input->post('idm1');
			$idm2=$this->input->post('idm2');
			$idm3=$this->input->post('idm3');
			$conduct=$this->input->post('conduct');
			$edit=$this->input->post('edit');
			//print_r($edit); exit;
			if($conduct == "conduct"){
				$supervisorcode = $this->input->post('supervisor_name');
				$quarter= $this->input->post('quarter');
				//get data for m1
				$uncodem1= $this->input->post('uncodem1');
				$monthdate1= $this->input->post('monthm1');
				$year = $this->input->post('date_year');
				$month= $this->input->post('date_month');
				$fmonthm1=$year.'-'.$monthdate1;
				$conductedm1=$this->input->post('conductedm1');
				$conduct_datem1=$this->input->post('conduct_datem1');
				$conduct_remarksm1 = $this->input->post('conduct_remarksm1');
				$statusm1 = $this->input->post('statusm1');
				//get data for m2
				$uncodem2= $this->input->post('uncodem2');
				$monthdate2= $this->input->post('monthm2');
				$year = $this->input->post('date_year');
				$month= $this->input->post('date_month');
				$fmonthm2=$year.'-'.$monthdate2;
				$conductedm2=$this->input->post('conductedm2');
				$conduct_datem2=$this->input->post('conduct_datem2');
				$conduct_remarksm2 = $this->input->post('conduct_remarksm2');
				$statusm2 = $this->input->post('statusm2');
				//get data for m3
				$uncodem3= $this->input->post('uncodem3');
				$monthdate3= $this->input->post('monthm3');
				$year = $this->input->post('date_year');
				$month= $this->input->post('date_month');
				$fmonthm3=$year.'-'.$monthdate3;
				$conductedm3=$this->input->post('conductedm3');
				$conduct_datem3=$this->input->post('conduct_datem3');
				$conduct_remarksm3 = $this->input->post('conduct_remarksm3');
				$statusm3 = $this->input->post('statusm3');
				//foreach for m1
				foreach($this->input->post('conductedm1') as $key=>$val){
					//print_r($val); exit;
					$idm1=$this->input->post('idm1')[$key];
						$conduct_array=array(
						    'is_conducted' => (isset($conductedm1[$key]) AND $conductedm1[$key]>0)?$conductedm1[$key]:'0',
							'conduct_date' => (isset($conduct_datem1[$key]) AND $conduct_datem1[$key] > 0)?$conduct_datem1[$key]:NULL,
							'status' => (isset($statusm1[$key]) AND $statusm1[$key] > 0)?$statusm1[$key]:'0',
							'conduct_remarks' => (isset($conduct_remarksm1[$key]) AND $conduct_remarksm1[$key] !="")?$conduct_remarksm1[$key]:NULL,  
						);
                        //print_r($conduct_array); //exit;						
						$this-> Common_model-> update_record('supervisory_plan',$conduct_array,array('supervisorcode'=>$supervisorcode,'id'=>$idm1));		         
			    }
					//foreach for m2
				foreach($this->input->post('conductedm2') as $key=>$val){
					$idm2=$this->input->post('idm2')[$key];
						$conduct_array=array(
						    'is_conducted' => (isset($conductedm2[$key]) AND $conductedm2[$key]>0)?$conductedm2[$key]:'0',
							'conduct_date' => (isset($conduct_datem2[$key]) AND $conduct_datem2[$key] > 0)?$conduct_datem2[$key]:NULL,
							'status' => (isset($statusm2[$key]) AND $statusm2[$key] > 0)?$statusm2[$key]:'0',
							'conduct_remarks' => (isset($conduct_remarksm2[$key]) AND $conduct_remarksm2[$key] !="")?$conduct_remarksm2[$key]:NULL,  
						);
                        //print_r($conduct_array); //exit;						
						$this-> Common_model-> update_record('supervisory_plan',$conduct_array,array('supervisorcode'=>$supervisorcode,'id'=>$idm2));		         
			    }
					//foreach for m3
				foreach($this->input->post('conductedm3') as $key=>$val){
					$idm3=$this->input->post('idm3')[$key];
						$conduct_array=array(
						    'is_conducted' => (isset($conductedm3[$key]) AND $conductedm3[$key]>0)?$conductedm3[$key]:'0',
							'conduct_date' => (isset($conduct_datem3[$key]) AND $conduct_datem3[$key] > 0)?$conduct_datem3[$key]:NULL,
							'status' => (isset($statusm3[$key]) AND $statusm3[$key] > 0)?$statusm3[$key]:'0',
							'conduct_remarks' => (isset($conduct_remarksm3[$key]) AND $conduct_remarksm3[$key] !="")?$conduct_remarksm3[$key]:NULL,  
						);
                       // print_r($conduct_array);exit; 						
						$this-> Common_model-> update_record('supervisory_plan',$conduct_array,array('supervisorcode'=>$supervisorcode,'id'=>$idm3));		         
			    }
		         $this -> session -> set_flashdata('message','You have successfully Updated your record!'); 
				$location = base_url()."micro_plan/Micro_plan_controller/supervisory_plan";
				//$location = base_url()."Supervisor-Micro-plan";
				redirect($location);
			}
			elseif ($edit  == "edit"){
				//print_r($_POST);exit;
			    $procode = $this -> session -> Province;
			    $distcode = $this-> session-> District; 
				$tcode = $this->input->post('tcode');
				$supervisor_type = $this->input->post('supervisor_type');
				$supervisorcode = $this->input->post('supervisor_name');
				$quarter= $this->input->post('quarter');
				//get data for m1
		        $session_typem1= $this->input->post('sessiontypem1');
		        $uncodem1= $this->input->post('uncodem1');
				$monthdate1= $this->input->post('monthm1');
				$year = $this->input->post('date_year');
				$month= $this->input->post('date_month');
				$fmonthm1=$year.'-'.$monthdate1;
				$facodem1 = $this->input->post('facodem1');
				$datem1 = $this->input->post('datedm1');
				$remarksm1 = $this->input->post('remarksm1');
				$area_namem1 = $this->input->post('vilage_hf_namem1');
				$village_merger_id1 = $this->input->post('vilage_hf_namem1');
				$checkm1 = $this->input->post('checkm1');
			    //get data for m2
		        $session_typem2= $this->input->post('sessiontypem2');
				$uncodem2= $this->input->post('uncodem2');
				$monthdate2= $this->input->post('monthm2');
				$year = $this->input->post('date_year');
				$month= $this->input->post('date_month');
				$fmonthm2=$year.'-'.$monthdate2;
				$facodem2 = $this->input->post('facodem2');
				$datem2 = $this->input->post('datedm2');
				$remarksm2 = $this->input->post('remarksm2');
				$area_namem2 = $this->input->post('vilage_hf_namem2');
				$village_merger_id2 = $this->input->post('vilage_hf_namem2');
				$checkm2 = $this->input->post('checkm2');
				//get data for m3
		        $session_typem3= $this->input->post('sessiontypem3');
				$uncodem3= $this->input->post('uncodem3');
				$monthdate3= $this->input->post('monthm3');
				$year = $this->input->post('date_year');
				$month= $this->input->post('date_month');
				$fmonthm3=$year.'-'.$monthdate3;
				$facodem3 = $this->input->post('facodem3');
				$datem3 = $this->input->post('datedm3');
				$remarksm3 = $this->input->post('remarksm3');
				$area_namem3 = $this->input->post('vilage_hf_namem3');
				$village_merger_id3 = $this->input->post('vilage_hf_namem3');
				$checkm3 = $this->input->post('checkm3');
				 //delete for m1
			    $query1 = "delete from supervisory_plan where supervisorcode='$supervisorcode' AND fmonth='$fmonthm1'";
		        $resm1 = $this->db->query($query1);
				//delete for m2
				$query2 = "delete from supervisory_plan where supervisorcode='$supervisorcode' AND fmonth='$fmonthm2'";
		        $resm2 = $this->db->query($query2);
				//delete for m3
				$query3 = "delete from supervisory_plan where supervisorcode='$supervisorcode' AND fmonth='$fmonthm3'";
		        $resm3 = $this->db->query($query3); 
				//foreach for m1 
				foreach($this->input->post('checkm1') as $key=>$val){
					$add_array=array(
					    'procode' => $procode,
					    'distcode' => $distcode,
					    'tcode' => $tcode,
						'supervisorcode' => $supervisorcode,
						'designation' => $supervisor_type,
						'quarter' => $quarter,
						//'session_type'=>(isset($session_typem1[$key]) AND $session_typem1[$key] !="")?$session_typem1[$key]:NULL,
						'uncode'=>(isset($uncodem1[$key]) AND $uncodem1[$key] !="")?$uncodem1[$key]:NULL,
						'fmonth' => $fmonthm1,
						//'facode'=>(isset($area_namem1[$key]) AND $area_namem1[$key] !="" AND $session_typem1[$key] === "Fixed" )?$area_namem1[$key]:NULL,
						//'area_name' => (isset($area_namem1[$key]) AND $area_namem1[$key]  !="" AND $session_typem1[$key] == "Outreach"  )?$area_namem1[$key]:NULL,
						//'village_merger_id' => (isset($village_merger_id1[$key]) AND $village_merger_id1[$key]  !="" AND $session_typem1[$key] == "Outreach" )?$village_merger_id1[$key]:NULL,
						'planned_date' => (isset($datem1[$key]) AND $datem1[$key] > 0)?$datem1[$key]:NULL,
						'remarks' => (isset($remarksm1[$key]) AND $remarksm1[$key] !="")?$remarksm1[$key]:NULL,  
					);
					$this -> Common_model -> insert_record('supervisory_plan',$add_array);
		            //print_r($add_array);//exit;
				}
				//foreach for m2
				foreach($this->input->post('checkm2') as $key=>$val){
					$add_array=array(
					    'procode' => $procode,
					    'distcode' => $distcode,
					    'tcode' => $tcode,
						'supervisorcode' => $supervisorcode,
						'designation' => $supervisor_type,
						'quarter' => $quarter,
						//'session_type'=>(isset($session_typem2[$key]) AND $session_typem2[$key] !="")?$session_typem2[$key]:NULL,
						'uncode'=>(isset($uncodem2[$key]) AND $uncodem2[$key] !="")?$uncodem2[$key]:NULL,
						'fmonth' => $fmonthm2,
						//'facode'=>(isset($area_namem2[$key]) AND $area_namem2[$key] !="" AND $session_typem2[$key] === "Fixed" )?$area_namem2[$key]:NULL,
						//'area_name' => (isset($area_namem2[$key]) AND $area_namem2[$key]  !="" AND $session_typem2[$key] == "Outreach"  )?$area_namem2[$key]:NULL,
						//'village_merger_id' => (isset($village_merger_id2[$key]) AND $village_merger_id2[$key]  !="" AND $session_typem2[$key] == "Outreach")?$village_merger_id2[$key]:NULL,
						'planned_date' => (isset($datem2[$key]) AND $datem2[$key] > 0)?$datem2[$key]:NULL,
						'remarks' => (isset($remarksm2[$key]) AND $remarksm2[$key] !="")?$remarksm2[$key]:NULL,  
					);
					$this -> Common_model -> insert_record('supervisory_plan',$add_array);
		            //print_r($add_array);//exit;
				}
				//foreach for m3
				foreach($this->input->post('checkm3') as $key=>$val){
					$add_array=array(
					    'procode' => $procode,
					    'distcode' => $distcode,
					    'tcode' => $tcode,
						'supervisorcode' => $supervisorcode,
						'designation' => $supervisor_type,
						'quarter' => $quarter,
						//'session_type'=>(isset($session_typem3[$key]) AND $session_typem3[$key] !="")?$session_typem3[$key]:NULL,
						'uncode'=>(isset($uncodem3[$key]) AND $uncodem3[$key] !="")?$uncodem3[$key]:NULL,
						'fmonth' => $fmonthm3,
						//'facode'=>(isset($area_namem3[$key]) AND $area_namem3[$key] !="" AND $session_typem3[$key] === "Fixed" )?$area_namem3[$key]:NULL,
						//'area_name' => (isset($area_namem3[$key]) AND $area_namem3[$key]  !="" AND $session_typem3[$key] == "Outreach"  )?$area_namem3[$key]:NULL,
						//'village_merger_id' => (isset($village_merger_id3[$key]) AND $village_merger_id3[$key]  !="" AND $session_typem3[$key] == "Outreach" )?$village_merger_id3[$key]:NULL,
						'planned_date' => (isset($datem3[$key]) AND $datem3[$key] > 0)?$datem3[$key]:NULL,
						'remarks' => (isset($remarksm3[$key]) AND $remarksm3[$key] !="")?$remarksm3[$key]:NULL,  
					);
					$this -> Common_model -> insert_record('supervisory_plan',$add_array);
		           //print_r($add_array);//exit;
				}
				//exit;
		        $this -> session -> set_flashdata('message','You have successfully Updated your record!'); 
				$location = base_url()."micro_plan/Micro_plan_controller/supervisory_plan";
				//$location = base_url()."Supervisor-Micro-plan";
				redirect($location);
			}
			else {
				//print_r($_POST);exit;
			    //get for m1
				$distcode = $this-> session->District;
				$supervisorcode = $this->input->post('supervisor_name');
				$quarter= $this->input->post('quarter');
			    $year = $this->input->post('date_year');
				$month= $this->input->post('date_month');
				$monthdatem1= $this->input->post('monthm1');
				$fmonthm1=$year.'-'.$monthdatem1;
				$query1 = "select fmonth,quarter,supervisorcode from supervisory_plan where quarter='$quarter' and fmonth like '$year%'  AND distcode='$distcode' and supervisorcode='$supervisorcode'";
	            $result = $this->db->query($query1);
		        $data1['fmonth'] =	$result->result_array();
				if(!empty($data1['fmonth'])){
				    $this -> session -> set_flashdata('message','This date record is already inserted<br> You just Edit this date record!'); 
					$location = base_url()."micro_plan/Micro_plan_controller/supervisory_plan_add";
					redirect($location);					
			    }
				else{
				    //get data for m1
					$procode = $this -> session -> Province;
					$distcode = $this-> session-> District; 
					$tcode = $this->input->post('tcode');
					$supervisor_type = $this->input->post('supervisor_type');
					$supervisorcode = $this->input->post('supervisor_name');
					$quarter= $this->input->post('quarter');
					$uncodem1= $this->input->post('uncodem1');
					$session_typem1= $this->input->post('sessiontypem1');
					$facodem1= $this->input->post('facodem1');
				    $monthdate1= $this->input->post('monthm1');
					$year = $this->input->post('date_year');
					$month= $this->input->post('date_month');
					$fmonthm1=$year.'-'.$monthdate1;
					$sessionm1 = $this->input->post('sessionm1');
					$datem1 = $this->input->post('datedm1');
					$remarksm1 = $this->input->post('remarksm1');
					$area_namem1 = $this->input->post('vilage_hf_namem1');
					$village_merger_id1 = $this->input->post('vilage_hf_namem1');
					$checkm1 = $this->input->post('checkm1');
					//get data for m2
					$session_typem2= $this->input->post('sessiontypem2');
					$uncodem2= $this->input->post('uncodem2');
					$facodem2= $this->input->post('facodem2');
				    $monthdate2= $this->input->post('monthm2');
					$year = $this->input->post('date_year');
					$month= $this->input->post('date_month');
					$fmonthm2=$year.'-'.$monthdate2;
					$sessionm2 = $this->input->post('sessionm2');
					$datem2 = $this->input->post('datedm2');
					$remarksm2 = $this->input->post('remarksm2');
					$area_namem2 = $this->input->post('vilage_hf_namem2');
					$village_merger_id2 = $this->input->post('vilage_hf_namem2');
					$checkm2 = $this->input->post('checkm2');
					//get data for m3
					$session_typem3= $this->input->post('sessiontypem3');
					$uncodem3= $this->input->post('uncodem3');
					$facodem3= $this->input->post('facodem3');
				    $monthdate3= $this->input->post('monthm3');
					$year = $this->input->post('date_year');
					$month= $this->input->post('date_month');
					$fmonthm3=$year.'-'.$monthdate3;
					$sessionm3 = $this->input->post('sessionm3');
					$datem3 = $this->input->post('datedm3');
					$remarksm3 = $this->input->post('remarksm3');
					$area_namem3 = $this->input->post('vilage_hf_namem3');
					$village_merger_id3 = $this->input->post('vilage_hf_namem3');
					$checkm3 = $this->input->post('checkm3');
					//foreach for m1
					foreach($this->input->post('checkm1') as $key=>$val){
						$add_array=array(
							'procode' => $procode,
						    'distcode' => $distcode,
						    'tcode' => $tcode,
							'supervisorcode' => $supervisorcode,
							'quarter' => $quarter,
							'uncode'=>(isset($uncodem1[$key]) AND $uncodem1[$key] !="")?$uncodem1[$key]:NULL,
							//'session_type'=>(isset($session_typem1[$key]) AND $session_typem1[$key] !="")?$session_typem1[$key]:NULL,
							//'facode'=>(isset($area_namem1[$key]) AND $area_namem1[$key] !="" AND $session_typem1[$key] === "Fixed" )?$area_namem1[$key]:NULL,
							'designation' => $supervisor_type,
							'fmonth' => $fmonthm1,
							//'area_name' => (isset($area_namem1[$key]) AND $area_namem1[$key]  !="" AND $session_typem1[$key] == "Outreach"  )?$area_namem1[$key]:NULL,
							//'village_merger_id' => (isset($village_merger_id1[$key]) AND $village_merger_id1[$key]  !="" AND $session_typem1[$key] == "Outreach" )?$village_merger_id1[$key]:NULL,
							'planned_date' => (isset($datem1[$key]) AND $datem1[$key] > 0)?$datem1[$key]:NULL,
							'remarks' => (isset($remarksm1[$key]) AND $remarksm1[$key] !="")?$remarksm1[$key]:NULL,  
						);
						//print_r($add_array);
						$this -> Common_model -> insert_record('supervisory_plan',$add_array);
				    } 
					//foreach for m2
					foreach($this->input->post('checkm2') as $key=>$val){
						$add_array=array(
							'procode' => $procode,
						    'distcode' => $distcode,
						    'tcode' => $tcode,
							'supervisorcode' => $supervisorcode,
							'quarter' => $quarter,
							'uncode'=>(isset($uncodem2[$key]) AND $uncodem2[$key] !="")?$uncodem2[$key]:NULL,
							//'session_type'=>(isset($session_typem2[$key]) AND $session_typem2[$key] !="")?$session_typem2[$key]:NULL,
							//'facode'=>(isset($area_namem2[$key]) AND $area_namem2[$key] !="" AND $session_typem2[$key] === "Fixed" )?$area_namem2[$key]:NULL,
							'designation' => $supervisor_type,
							'fmonth' => $fmonthm2,
							//'area_name' => (isset($area_namem2[$key]) AND $area_namem2[$key]  !="" AND $session_typem2[$key] == "Outreach"  )?$area_namem2[$key]:NULL,
							//'village_merger_id' => (isset($village_merger_id2[$key]) AND $village_merger_id2[$key]  !="" AND $session_typem2[$key] == "Outreach")?$village_merger_id2[$key]:NULL,
							'planned_date' => (isset($datem2[$key]) AND $datem2[$key] > 0)?$datem2[$key]:NULL,
							'remarks' => (isset($remarksm2[$key]) AND $remarksm2[$key] !="")?$remarksm2[$key]:NULL,  
						);
						//print_r($add_array);
						$this -> Common_model -> insert_record('supervisory_plan',$add_array);
				    } 
					//foreach for m3
					foreach($this->input->post('checkm3') as $key=>$val){
						$add_array=array(
							'procode' => $procode,
						    'distcode' => $distcode,
						    'tcode' => $tcode,
							'supervisorcode' => $supervisorcode,
							'quarter' => $quarter,
							//'session_type'=>(isset($session_typem3[$key]) AND $session_typem3[$key] !="")?$session_typem3[$key]:NULL,
							//'facode'=>(isset($area_namem3[$key]) AND $area_namem3[$key] !="" AND $session_typem3[$key] === "Fixed" )?$area_namem3[$key]:NULL,
							'uncode'=>(isset($uncodem3[$key]) AND $uncodem3[$key] !="")?$uncodem3[$key]:NULL,
							'designation' => $supervisor_type,
							'fmonth' => $fmonthm3,
							//'area_name' => (isset($area_namem3[$key]) AND $area_namem3[$key]  !="" AND $session_typem3[$key] == "Outreach"  )?$area_namem3[$key]:NULL,
							//'village_merger_id' => (isset($village_merger_id3[$key]) AND $village_merger_id3[$key]  !="" AND $session_typem3[$key] == "Outreach" )?$village_merger_id3[$key]:NULL,
							'planned_date' => (isset($datem3[$key]) AND $datem3[$key] > 0)?$datem3[$key]:NULL,
							'remarks' => (isset($remarksm3[$key]) AND $remarksm3[$key] !="")?$remarksm3[$key]:NULL,  
						);
					    //print_r($add_array);
						$this -> Common_model -> insert_record('supervisory_plan',$add_array);
				    } 
					//exit; 
				    $this -> session -> set_flashdata('message','You have successfully saved your record!'); 
					$location = base_url()."micro_plan/Micro_plan_controller/supervisory_plan_add";
					//$location = base_url()."Supervisor-Micro-plan";
					redirect($location);
				}
			}				
		}
		public function supervisory_plan_edit(){
			$supervisorcode = $this -> uri -> segment(4);
			$quarter   = $this -> uri -> segment(5);
			$fmonth   = $this -> uri -> segment(6);
			$year   = $this -> uri -> segment(6);
			$tcode   = $this -> uri -> segment(7);
			$data['data'] =$this->micro->supervisory_plan_edit($supervisorcode,$quarter,$fmonth,$year,$tcode);
			$monthYear = explode("-", $fmonth);
		    $data['year'] = $monthYear[0];
		   // $data['month'] = $monthYear[1];  
		    $data['fileToLoad'] = 'micro_plan/supervisory_plan_edit';
		   // print_r($data);exit;
			$data['pageTitle']='Micro Plan | EPI-MIS';
			$this->load->view('template/epi_template',$data);
		}
		public function supervisory_plan_conducted(){
			$supervisorcode = $this -> uri -> segment(4);
			$quarter   = $this -> uri -> segment(5);
			$fmonth   = $this -> uri -> segment(6);
			$year   = $this -> uri -> segment(6);
			//print_r($fmonth);exit();
			$data['data'] =$this->micro->supervisory_plan_conducted($supervisorcode,$quarter,$fmonth,$year);
			$monthYear = explode("-", $fmonth);
		    $data['year'] = $monthYear[0];
		    //$data['year'] = $year;
		    //echo $data['year']; exit();
		    $data['fileToLoad'] = 'micro_plan/supervisory_plan_conducted';
		   	//print_r($data);exit;
			$data['pageTitle']='Micro Plan | EPI-MIS';
			$this->load->view('template/epi_template',$data);
		}
		public function supervisory_plan(){
			$data['data'] =$this->micro->supervisory_plan();
			//print_r($data['data']);exit;
			$data['fileToLoad'] = 'micro_plan/supervisory_plan';
		    $data['pageTitle']='Micro Plan | EPI-MIS';
			$this->load->view('template/epi_template',$data);
		}
		public function supervisory_plan_view(){
			$supervisorcode = $this -> uri -> segment(4);
			$quarter   = $this -> uri -> segment(5);
		    $fmonth   = $this -> uri -> segment(6);
		    $year   = $this -> uri -> segment(6);
			//print_r($year);exit;
			$data['data'] =$this->micro->supervisory_plan_view($supervisorcode,$quarter,$fmonth,$year);
			$monthYear = explode("-", $fmonth);
		    $data['year'] = $monthYear[0];
			$data['fileToLoad'] = 'micro_plan/supervisory_plan_view';
			$data['pageTitle']='Micro Plan | EPI-MIS';
			$this->load->view('template/epi_template',$data);
		}
		public function health_facility_monitoring_add(){
			//$facode = $this -> uri -> segment(4);
			//$area_name   = $this -> uri -> segment(5);
		    $quarter   = $this -> uri -> segment(4);
		    $id   = $this -> uri -> segment(5);
			$data['data'] =$this->micro->health_facility_monitoring_add_model($quarter,$id);
			$data['fileToLoad'] = 'micro_plan/health_facility_monitoring_add';
		    $data['pageTitle']='Health Facility Monitoring | EPI-MIS';
			$this->load->view('template/epi_template',$data);
		}
		public function health_facility_monitoring_save() {
			$monitor_name = $this -> input -> post ('monitor_name');
			$technician_name=$this -> input -> post ('technician_name');
			$supervisor_name=$this -> input -> post ('supervisor_name');
		    $lhws_name=$this -> input -> post ('lhws_name');
			$acv_name=$this -> input -> post('acv_name');
			$supervisorcode=$this -> input -> post('supervisor_name');
			$quarter=$this -> input -> post('quarter');
			//$quarter='01';
			$procode = $this -> session -> Province;
			$checklist_data=array(
								'procode'=>$procode,
								'distcode' => $this -> input -> post ('distcode'),
								'tcode' => $this -> input -> post ('tcode'),
								'uncode' => $this -> input -> post ('uncode'),
								'facode' => $this -> input -> post ('facode'),
								'supervisorcode' => $this -> input -> post ('supervisor_name'),
								'monitor_name' => $this -> input -> post ('monitor_name'),
								'techniciancode' => $this -> input -> post ('technician_name'),
								'quarter'=>$this -> input -> post('quarter'),
								'area_code'=>$this -> input -> post('area_name'),
								'lhws_name' => $this -> input -> post ('lhws_name'),
								'acv_name' => $this -> input -> post ('acv_name'),
								'date_create' => $this -> input -> post ('date_create'),
								'remark_fc_q1'=> $this -> input -> post ('remark_fixedcenter_q1'),
								'fc_q1'=> $this -> input -> post ('fixedcenter1'),
								'remark_fc_q2'=> $this -> input -> post ('remark_fixedcenter_q2'),
								'fc_q2'=> $this -> input -> post ('fixedcenter2'),
								'remark_fc_q3'=> $this -> input -> post ('remark_fixedcenter_q3'),
								'fc_q3'=> $this -> input -> post ('fixedcenter3'),
								'remark_fc_q4'=> $this -> input -> post ('remark_fixedcenter_q4'),
								'fc_q4'=> $this -> input -> post ('fixedcenter4'),
								'remark_fc_q5'=> $this -> input -> post ('remark_fixedcenter_q5'),
								'fc_q5'=> $this -> input -> post ('fixedcenter5'),
								'remark_fc_q6'=> $this -> input -> post ('remark_fixedcenter_q6'),
								'fc_q6'=> $this -> input -> post ('fixedcenter6'),
								'remark_fc_q7'=> $this -> input -> post ('remark_fixedcenter_q7'),
								'fc_q7'=> $this -> input -> post ('fixedcenter7'),
								'remark_fc_q8'=> $this -> input -> post ('remark_fixedcenter_q8'),
								'fc_q8'=> $this -> input -> post ('fixedcenter8'),
								'remark_fc_q9'=> $this -> input -> post ('remark_fixedcenter_q9'),
								'fc_q9'=> $this -> input -> post ('fixedcenter9'),
								'remark_fc_q10'=> $this -> input -> post ('remark_fixedcenter_q10'),
								'fc_q10'=> $this -> input -> post ('fixedcenter10'),
								'remark_fc_q11' => $this -> input -> post ('remark_fixedcenter_q11'),
								'fc_q11'=> $this -> input -> post ('fixedcenter11'),
								'remark_fc_q12' => $this -> input -> post ('remark_fixedcenter_q12'),
								'fc_q12'=> $this -> input -> post ('fixedcenter12'),
								'remark_fc_q13' => $this -> input -> post ('remark_fixedcenter_q13'),
								'fc_q13'=> $this -> input -> post ('fixedcenter13'),
								'remark_fc_q14' => $this -> input -> post ('remark_fixedcenter_q14'),
								'fc_q14'=> $this -> input -> post ('fixedcenter14'),
								'remark_fc_q15' => $this -> input -> post ('remark_fixedcenter_q15'),
								'fc_q15'=> $this -> input -> post ('fixedcenter15'),
								'remark_fc_q16' => $this -> input -> post ('remark_fixedcenter_q16'),
								'fc_q16'=> $this -> input -> post ('fixedcenter16'),
								'remark_fc_q17' => $this -> input -> post ('remark_fixedcenter_q17'),
								'fc_q17'=> $this -> input -> post ('fixedcenter17'),
								'remark_fc_q18' => $this -> input -> post ('remark_fixedcenter_q18'),
								'fc_q18'=> $this -> input -> post ('fixedcenter18'),
								'remark_fc_q19' => $this -> input -> post ('remark_fixedcenter_q19'),
								'fc_q19'=> $this -> input -> post ('fixedcenter19'),
								'remark_fc_q20' => $this -> input -> post ('remark_fixedcenter_q20'),
								'fc_q20'=> $this -> input -> post ('fixedcenter20'),
								'fk_id'=> $this -> input -> post ('id')
								
							);
						//print_r($checklist_data);exit;
						$data['data'] =$this->micro-> health_facility_monitoring_save_model($checklist_data);
						$location = base_url()."micro_plan/Micro_plan_controller/supervisory_plan_conducted/".$supervisorcode."/".$quarter;
						redirect($location);			
		}
		public function fixed_session_monitoring_add(){
			//$facode = $this -> uri -> segment(4);
			//$area_name   = $this -> uri -> segment(5);
		    $quarter   = $this -> uri -> segment(4);
		    $id   = $this -> uri -> segment(5);
			$data['data'] =$this->micro->fixed_session_monitoring_add_model($quarter,$id);
			$data['fileToLoad'] = 'micro_plan/fixed_session_monitoring_add';
		    $data['pageTitle']='Fixed Session Monitoring | EPI-MIS';
			$this->load->view('template/epi_template',$data);
		}
		public function fixed_session_monitoring_save() {
			$monitor_name = $this -> input -> post ('monitor_name');
			$technician_name=$this -> input -> post ('technician_name');
			$supervisor_name=$this -> input -> post ('supervisor_name');
		    $lhws_name=$this -> input -> post ('lhws_name');
			$acv_name=$this -> input -> post('acv_name');
			$supervisorcode=$this -> input -> post('supervisor_name');
			$procode = $this -> session -> Province;
			$quarter=$this -> input -> post('quarter');
				$checklist_data=array(	
										'procode' =>$procode,
										'distcode' => $this -> input -> post ('distcode'),
										'tcode' => $this -> input -> post ('tcode'),
										'uncode' => $this -> input -> post ('uncode'),
										'facode' => $this -> input -> post ('facode'),
										'supervisorcode' => $this -> input -> post ('supervisor_name'),
										'monitor_name' => $this -> input -> post ('monitor_name'),
										'techniciancode' => $this -> input -> post ('technician_name'),
										'quarter'=>$this -> input -> post('quarter'),
										'area_code'=>$this -> input -> post('area_name'),
										'lhws_name' => $this -> input -> post ('lhws_name'),
										'acv_name' => $this -> input -> post ('acv_name'),
										'date_create' => $this -> input -> post ('date_create'),
										'remark_fs_q1' => $this -> input -> post ('remark_fixedsession_q21'),
										'fs_q1' => $this -> input -> post ('fixedsession21'),
										'remark_fs_q2' => $this -> input -> post ('remark_fixedsession_q22'),
										'fs_q2' => $this -> input -> post ('fixedsession22'),
										'remark_fs_q3' => $this -> input -> post ('remark_fixedsession_q23'),
										'fs_q3' => $this -> input -> post ('fixedsession23'),
										'remark_fs_q4' => $this -> input -> post ('remark_fixedsession_q24'),
										'fs_q4' => $this -> input -> post ('fixedsession24'),
										'remark_fs_q5' => $this -> input -> post ('remark_fixedsession_q25'),
										'fs_q5' => $this -> input -> post ('fixedsession25'),
										'remark_fs_q6' => $this -> input -> post ('remark_fixedsession_q26'),
										'fs_q6' => $this -> input -> post ('fixedsession26'),
										'remark_fs_q7' => $this -> input -> post ('remark_fixedsession_q27'),
										'fs_q7' => $this -> input -> post ('fixedsession27'),
										'remark_fs_q8' => $this -> input -> post ('remark_fixedsession_q28'),
										'fs_q8' => $this -> input -> post ('fixedsession28'),
										'remark_fs_q9' => $this -> input -> post ('remark_fixedsession_q29'),
										'fs_q9' => $this -> input -> post ('fixedsession29'),
										'remark_fs_q10' => $this -> input -> post ('remark_fixedsession_q30'),
										'fs_q10' => $this -> input -> post ('fixedsession30'),
										'fk_id'=> $this -> input -> post ('id')
										
									);
							//print_r($checklist_data);exit;
							$data['data'] =$this->micro-> fixed_session_monitoring_save_model($checklist_data);
			
							$location = base_url()."micro_plan/Micro_plan_controller/supervisory_plan_conducted/".$supervisorcode."/".$quarter;
							redirect($location);
		}
		public function outreach_session_monitoring_add(){
			//$facode = $this -> uri -> segment(4);
			//$area_name   = $this -> uri -> segment(5);
		    $quarter   = $this -> uri -> segment(4);
		    $id   = $this -> uri -> segment(5);
			$data['data'] =$this->micro->outreach_session_monitoring_add_model($quarter,$id);
			//print_r($data);
		    $data['fileToLoad'] = 'micro_plan/outreach_session_monitoring_add';
		    $data['pageTitle']='Outreach Session Monitoring | EPI-MIS';
			$this->load->view('template/epi_template',$data);
		}
		public function outreach_session_monitoring_save() {
			$monitor_name = $this -> input -> post ('monitor_name');
			$technician_name=$this -> input -> post ('technician_name');
			$supervisor_name=$this -> input -> post ('supervisor_name');
		    $lhws_name=$this -> input -> post ('lhws_name');
			$acv_name=$this -> input -> post('acv_name');
			$supervisorcode=$this -> input -> post('supervisor_name');
			$quarter=$this -> input -> post('quarter');
			$fk_id=$this -> input -> post('id');
			$procode = $this -> session -> Province;	
			$checklist_data=array(
									'procode'=>$procode,
									'distcode' => $this -> input -> post ('distcode'),
									'tcode' => $this -> input -> post ('tcode'),
									'uncode' => $this -> input -> post ('uncode'),
									'facode' => $this -> input -> post ('facode'),
									'supervisorcode' => $this -> input -> post ('supervisor_name'),
									'monitor_name' => $this -> input -> post ('monitor_name'),
									'techniciancode' => $this -> input -> post ('technician_name'),
									'quarter'=>$this -> input -> post('quarter'),
									'area_code'=>$this -> input -> post('area_name'),
									'lhws_name' => $this -> input -> post ('lhws_name'),
									'acv_name' => $this -> input -> post ('acv_name'),
									'date_create' => $this -> input -> post ('date_create'),
									'remark_os_q1' => $this -> input -> post ('remark_outreachsession_q1'),
									'os_q1'			=> $this -> input -> post ('outreachsession1'),
									'remark_os_q2' => $this -> input -> post ('remark_outreachsession_q2'),
									'os_q2' 			=> $this -> input -> post ('outreachsession2'),
									'remark_os_q3' => $this -> input -> post ('remark_outreachsession_q3'),
									'os_q3' 		=> $this -> input -> post ('outreachsession3'),
									'remark_os_q4' => $this -> input -> post ('remark_outreachsession_q4'),
									'os_q4' 			=> $this -> input -> post ('outreachsession4'),
									'remark_os_q5' => $this -> input -> post ('remark_outreachsession_q5'),
									'os_q5' 			=> $this -> input -> post ('outreachsession5'),
									'remark_os_q6' => $this -> input -> post ('remark_outreachsession_q6'),
									'os_q6' 			=> $this -> input -> post ('outreachsession6'),
									'remark_os_q7' => $this -> input -> post ('remark_outreachsession_q7'),
									'os_q7' 			=> $this -> input -> post ('outreachsession7'),
									'remark_os_q8' => $this -> input -> post ('remark_outreachsession_q8'),
									'os_q8' 			=> $this -> input -> post ('outreachsession8'),
									'remark_os_q9' => $this -> input -> post ('remark_outreachsession_q9'),
									'os_q9' 			=> $this -> input -> post ('outreachsession9'),
									'remark_os_q10'=> $this -> input -> post ('remark_outreachsession_q10'),
									'os_q10' 		=> $this -> input -> post ('outreachsession10'),
									'remark_os_q11'=> $this -> input -> post ('remark_outreachsession_q11'),
									'os_q11' 		=> $this -> input -> post ('outreachsession11'),
									'remark_os_q12'=> $this -> input -> post ('remark_outreachsession_q12'),
									'os_q12' 		=> $this -> input -> post ('outreachsession12'),
									'remark_os_q13'=> $this -> input -> post ('remark_outreachsession_q13'),
									'os_q13' 		=> $this -> input -> post ('outreachsession13'),
									'remark_os_q14'=> $this -> input -> post ('remark_outreachsession_q14'),
									'os_q14' 		=> $this -> input -> post ('outreachsession14'),
									'remark_os_q15'=> $this -> input -> post ('remark_outreachsession_q15'),
									'os_q15' 		=> $this -> input -> post ('outreachsession15'),
									'remark_os_q16'=> $this -> input -> post ('remark_outreachsession_q16'),
									'os_q16' 		=> $this -> input -> post ('outreachsession16'),
									'remark_os_q17'=> $this -> input -> post ('remark_outreachsession_q17'),
									'os_q17' 		=> $this -> input -> post ('outreachsession17'),
									'fk_id' 		=> $this -> input -> post ('id')
										
								);
						//print_r($checklist_data);exit;
						$data['data'] =$this->micro-> outreach_session_monitoring_save_model($checklist_data);
						$location = base_url()."micro_plan/Micro_plan_controller/supervisory_plan_conducted/".$supervisorcode."/".$quarter;
						redirect($location);
		}	
		public function house_hold_cluster_assesment_add(){
			//$facode = $this -> uri -> segment(4);
			//$area_name   = $this -> uri -> segment(5);
		    $quarter   = $this -> uri -> segment(4);
			$id   = $this -> uri -> segment(5);			
			$data['data'] =$this->micro->house_hold_cluster_assesment_add_model($quarter,$id);
			//print_r($data);
		    $data['fileToLoad'] = 'micro_plan/house_hold_cluster_assesment_add';
		    $data['pageTitle']='House Hold Cluster Assesment | EPI-MIS';
			$this->load->view('template/epi_template',$data);
		}
		public function house_hold_cluster_assesment_save(){
			$supervisorcode=$this -> input -> post('supervisor_name');
			$quarter=$this -> input -> post('quarter');
			$fk_id=$this -> input -> post('id');
			//$v1_bcg_row1=$this -> input -> post('v1_bcg_row1');
			//print_r($v1_bcg_row1);exit;
			$procode = $this -> session -> Province;
			$cluster_data=array(
								'procode' =>$procode,
								'district' =>($this ->input -> post ('district')) ? $this ->input -> post ('district') : Null , 
								'tehsil' =>($this ->input -> post ('tehsil')) ? $this ->input -> post ('tehsil') : Null , 
								'uncode' =>($this ->input -> post ('uncode')) ? $this ->input -> post ('uncode') : Null , 
								'area_code' =>($this ->input -> post ('area_code')) ? $this ->input -> post ('area_code') : Null , 
								'asv_name' =>($this ->input -> post ('asv_name')) ? $this ->input -> post ('asv_name') : Null , 
								'vaccinator_name' =>($this ->input -> post ('vaccinator_name')) ? $this ->input -> post ('vaccinator_name') : Null , 
								'date_create' =>($this ->input -> post ('date_create')) ? $this ->input -> post ('date_create') : Null , 
								'cardno_row1' =>($this ->input -> post ('cardno_row1')) ? $this ->input -> post ('cardno_row1') : Null , 
								'childname_row1' =>($this ->input -> post ('childname_row1')) ? $this ->input -> post ('childname_row1') : Null , 
								'fathername_row1' =>($this ->input -> post ('fathername_row1')) ? $this ->input -> post ('fathername_row1') : Null , 
								'contact_row1' =>($this ->input -> post ('contact_row1')) ? $this ->input -> post ('contact_row1') : Null , 
								'age_dob_row1' =>($this ->input -> post ('age_dob_row1')) ? $this ->input -> post ('age_dob_row1') : Null , 
								'v1_bcg_row1' =>($this ->input -> post ('v1_bcg_row1') !="") ? $this ->input -> post ('v1_bcg_row1') : Null , 
								'v2_penta_1_row1' =>($this ->input -> post ('v2_penta_1_row1') !="") ? $this ->input -> post ('v2_penta_1_row1') : Null , 
								'v3_penta_2_row1' =>($this ->input -> post ('v3_penta_2_row1') !="") ? $this ->input -> post ('v3_penta_2_row1') : Null , 
								'v4_penta_3_row1' =>($this ->input -> post ('v4_penta_3_row1') !="") ? $this ->input -> post ('v4_penta_3_row1') : Null , 
								'v5_measles1_row1' =>($this ->input -> post ('v5_measles1_row1') !="") ? $this ->input -> post ('v5_measles1_row1') : Null , 
								'v6_measles2_row1' =>($this ->input -> post ('v6_measles2_row1') !="") ? $this ->input -> post ('v6_measles2_row1') : Null , 
								'un_vaccinated_row1' =>($this ->input -> post ('un_vaccinated_row1') !="") ? $this ->input -> post ('un_vaccinated_row1') : Null , 
								'partially_vaccinated_row1' =>($this ->input -> post ('partially_vaccinated_row1') !="") ? $this ->input -> post ('partially_vaccinated_row1') : Null , 
								'upto_date_vaccinated_row1' =>($this ->input -> post ('upto_date_vaccinated_row1') !="") ? $this ->input -> post ('upto_date_vaccinated_row1') : Null , 
								'v1_hepa_b_bd_row1' =>($this ->input -> post ('v1_hepa_b_bd_row1') !="") ? $this ->input -> post ('v1_hepa_b_bd_row1') : Null , 
								'v2_pcv10_1_row1' =>($this ->input -> post ('v2_pcv10_1_row1') !="") ? $this ->input -> post ('v2_pcv10_1_row1') : Null , 
								'v3_pcv10_2_row1' =>($this ->input -> post ('v3_pcv10_2_row1') !="") ? $this ->input -> post ('v3_pcv10_2_row1') : Null , 
								'v4_pcv10_3_row1' =>($this ->input -> post ('v4_pcv10_3_row1') !="") ? $this ->input -> post ('v4_pcv10_3_row1') : Null , 
								'v1_opv_0_row1' =>($this ->input -> post ('v1_opv_0_row1') !="") ? $this ->input -> post ('v1_opv_0_row1') : Null , 
								'v2_opv_1_row1' =>($this ->input -> post ('v2_opv_1_row1') !="") ? $this ->input -> post ('v2_opv_1_row1') : Null , 
								'v3_opv_2_row1' =>($this ->input -> post ('v3_opv_2_row1') !="") ? $this ->input -> post ('v3_opv_2_row1') : Null , 
								'v4_opv_3_row1' =>($this ->input -> post ('v4_opv_3_row1') !="") ? $this ->input -> post ('v4_opv_3_row1') : Null , 
								'v2_rota_1_row1' =>($this ->input -> post ('v2_rota_1_row1') !="") ? $this ->input -> post ('v2_rota_1_row1') : Null , 
								'v3_rota_2_row1' =>($this ->input -> post ('v3_rota_2_row1') !="") ? $this ->input -> post ('v3_rota_2_row1') : Null , 
								'v4_ipv_row1' =>($this ->input -> post ('v4_ipv_row1') !="") ? $this ->input -> post ('v4_ipv_row1') : Null , 
								'cardno_row2' =>($this ->input -> post ('cardno_row2')) ? $this ->input -> post ('cardno_row2') : Null , 
								'childname_row2' =>($this ->input -> post ('childname_row2')) ? $this ->input -> post ('childname_row2') : Null , 
								'fathername_row2' =>($this ->input -> post ('fathername_row2')) ? $this ->input -> post ('fathername_row2') : Null , 
								'contact_row2' =>($this ->input -> post ('contact_row2')) ? $this ->input -> post ('contact_row2') : Null , 
								'age_dob_row2' =>($this ->input -> post ('age_dob_row2')) ? $this ->input -> post ('age_dob_row2') : Null , 
								'v1_bcg_row2' =>($this ->input -> post ('v1_bcg_row2') !="") ? $this ->input -> post ('v1_bcg_row2') : Null , 
								'v2_penta_1_row2' =>($this ->input -> post ('v2_penta_1_row2') !="") ? $this ->input -> post ('v2_penta_1_row2') : Null , 
								'v3_penta_2_row2' =>($this ->input -> post ('v3_penta_2_row2') !="") ? $this ->input -> post ('v3_penta_2_row2') : Null , 
								'v4_penta_3_row2' =>($this ->input -> post ('v4_penta_3_row2') !="") ? $this ->input -> post ('v4_penta_3_row2') : Null , 
								'v5_measles1_row2' =>($this ->input -> post ('v5_measles1_row2') !="") ? $this ->input -> post ('v5_measles1_row2') : Null , 
								'v6_measles2_row2' =>($this ->input -> post ('v6_measles2_row2') !="") ? $this ->input -> post ('v6_measles2_row2') : Null , 
								'un_vaccinated_row2' =>($this ->input -> post ('un_vaccinated_row2') !="") ? $this ->input -> post ('un_vaccinated_row2') : Null , 
								'partially_vaccinated_row2' =>($this ->input -> post ('partially_vaccinated_row2') !="") ? $this ->input -> post ('partially_vaccinated_row2') : Null , 
								'upto_date_vaccinated_row2' =>($this ->input -> post ('upto_date_vaccinated_row2') !="") ? $this ->input -> post ('upto_date_vaccinated_row2') : Null , 
								'v1_hepa_b_bd_row2' =>($this ->input -> post ('v1_hepa_b_bd_row2') !="") ? $this ->input -> post ('v1_hepa_b_bd_row2') : Null , 
								'v2_pcv10_1_row2' =>($this ->input -> post ('v2_pcv10_1_row2') !="") ? $this ->input -> post ('v2_pcv10_1_row2') : Null , 
								'v3_pcv10_2_row2' =>($this ->input -> post ('v3_pcv10_2_row2') !="") ? $this ->input -> post ('v3_pcv10_2_row2') : Null , 
								'v4_pcv10_3_row2' =>($this ->input -> post ('v4_pcv10_3_row2') !="") ? $this ->input -> post ('v4_pcv10_3_row2') : Null , 
								'v1_opv_0_row2' =>($this ->input -> post ('v1_opv_0_row2') !="") ? $this ->input -> post ('v1_opv_0_row2') : Null , 
								'v2_opv_1_row2' =>($this ->input -> post ('v2_opv_1_row2') !="") ? $this ->input -> post ('v2_opv_1_row2') : Null , 
								'v3_opv_2_row2' =>($this ->input -> post ('v3_opv_2_row2') !="") ? $this ->input -> post ('v3_opv_2_row2') : Null , 
								'v4_opv_3_row2' =>($this ->input -> post ('v4_opv_3_row2') !="") ? $this ->input -> post ('v4_opv_3_row2') : Null , 
								'v2_rota_1_row2' =>($this ->input -> post ('v2_rota_1_row2') !="") ? $this ->input -> post ('v2_rota_1_row2') : Null , 
								'v3_rota_2_row2' =>($this ->input -> post ('v3_rota_2_row2') !="") ? $this ->input -> post ('v3_rota_2_row2') : Null , 
								'v4_ipv_row2' =>($this ->input -> post ('v4_ipv_row2') !="") ? $this ->input -> post ('v4_ipv_row2') : Null , 
								'cardno_row3' =>($this ->input -> post ('cardno_row3')) ? $this ->input -> post ('cardno_row3') : Null , 
								'childname_row3' =>($this ->input -> post ('childname_row3')) ? $this ->input -> post ('childname_row3') : Null , 
								'fathername_row3' =>($this ->input -> post ('fathername_row3')) ? $this ->input -> post ('fathername_row3') : Null , 
								'contact_row3' =>($this ->input -> post ('contact_row3')) ? $this ->input -> post ('contact_row3') : Null , 
								'age_dob_row3' =>($this ->input -> post ('age_dob_row3')) ? $this ->input -> post ('age_dob_row3') : Null , 
								'v1_bcg_row3' =>($this ->input -> post ('v1_bcg_row3') !="") ? $this ->input -> post ('v1_bcg_row3') : Null , 
								'v2_penta_1_row3' =>($this ->input -> post ('v2_penta_1_row3') !="") ? $this ->input -> post ('v2_penta_1_row3') : Null , 
								'v3_penta_2_row3' =>($this ->input -> post ('v3_penta_2_row3') !="") ? $this ->input -> post ('v3_penta_2_row3') : Null , 
								'v4_penta_3_row3' =>($this ->input -> post ('v4_penta_3_row3') !="") ? $this ->input -> post ('v4_penta_3_row3') : Null , 
								'v5_measles1_row3' =>($this ->input -> post ('v5_measles1_row3') !="") ? $this ->input -> post ('v5_measles1_row3') : Null , 
								'v6_measles2_row3' =>($this ->input -> post ('v6_measles2_row3') !="") ? $this ->input -> post ('v6_measles2_row3') : Null , 
								'un_vaccinated_row3' =>($this ->input -> post ('un_vaccinated_row3') !="") ? $this ->input -> post ('un_vaccinated_row3') : Null , 
								'partially_vaccinated_row3' =>($this ->input -> post ('partially_vaccinated_row3') !="") ? $this ->input -> post ('partially_vaccinated_row3') : Null , 
								'upto_date_vaccinated_row3' =>($this ->input -> post ('upto_date_vaccinated_row3') !="") ? $this ->input -> post ('upto_date_vaccinated_row3') : Null , 
								'v1_hepa_b_bd_row3' =>($this ->input -> post ('v1_hepa_b_bd_row3') !="") ? $this ->input -> post ('v1_hepa_b_bd_row3') : Null , 
								'v2_pcv10_1_row3' =>($this ->input -> post ('v2_pcv10_1_row3') !="") ? $this ->input -> post ('v2_pcv10_1_row3') : Null , 
								'v3_pcv10_2_row3' =>($this ->input -> post ('v3_pcv10_2_row3') !="") ? $this ->input -> post ('v3_pcv10_2_row3') : Null , 
								'v4_pcv10_3_row3' =>($this ->input -> post ('v4_pcv10_3_row3') !="") ? $this ->input -> post ('v4_pcv10_3_row3') : Null , 
								'v1_opv_0_row3' =>($this ->input -> post ('v1_opv_0_row3') !="") ? $this ->input -> post ('v1_opv_0_row3') : Null , 
								'v2_opv_1_row3' =>($this ->input -> post ('v2_opv_1_row3') !="") ? $this ->input -> post ('v2_opv_1_row3') : Null , 
								'v3_opv_2_row3' =>($this ->input -> post ('v3_opv_2_row3') !="") ? $this ->input -> post ('v3_opv_2_row3') : Null , 
								'v4_opv_3_row3' =>($this ->input -> post ('v4_opv_3_row3') !="") ? $this ->input -> post ('v4_opv_3_row3') : Null , 
								'v2_rota_1_row3' =>($this ->input -> post ('v2_rota_1_row3') !="") ? $this ->input -> post ('v2_rota_1_row3') : Null , 
								'v3_rota_2_row3' =>($this ->input -> post ('v3_rota_2_row3') !="") ? $this ->input -> post ('v3_rota_2_row3') : Null , 
								'v4_ipv_row3' =>($this ->input -> post ('v4_ipv_row3') !="") ? $this ->input -> post ('v4_ipv_row3') : Null , 
								'cardno_row4' =>($this ->input -> post ('cardno_row4')) ? $this ->input -> post ('cardno_row4') : Null , 
								'childname_row4' =>($this ->input -> post ('childname_row4')) ? $this ->input -> post ('childname_row4') : Null , 
								'fathername_row4' =>($this ->input -> post ('fathername_row4')) ? $this ->input -> post ('fathername_row4') : Null , 
								'contact_row4' =>($this ->input -> post ('contact_row4')) ? $this ->input -> post ('contact_row4') : Null , 
								'age_dob_row4' =>($this ->input -> post ('age_dob_row4')) ? $this ->input -> post ('age_dob_row4') : Null , 
								'v1_bcg_row4' =>($this ->input -> post ('v1_bcg_row4') !="") ? $this ->input -> post ('v1_bcg_row4') : Null , 
								'v2_penta_1_row4' =>($this ->input -> post ('v2_penta_1_row4') !="") ? $this ->input -> post ('v2_penta_1_row4') : Null , 
								'v3_penta_2_row4' =>($this ->input -> post ('v3_penta_2_row4') !="") ? $this ->input -> post ('v3_penta_2_row4') : Null , 
								'v4_penta_3_row4' =>($this ->input -> post ('v4_penta_3_row4') !="") ? $this ->input -> post ('v4_penta_3_row4') : Null , 
								'v5_measles1_row4' =>($this ->input -> post ('v5_measles1_row4')!="") ? $this ->input -> post ('v5_measles1_row4') : Null , 
								'v6_measles2_row4' =>($this ->input -> post ('v6_measles2_row4')!="") ? $this ->input -> post ('v6_measles2_row4') : Null , 
								'un_vaccinated_row4' =>($this ->input -> post ('un_vaccinated_row4')!="") ? $this ->input -> post ('un_vaccinated_row4') : Null , 
								'partially_vaccinated_row4' =>($this ->input -> post ('partially_vaccinated_row4')!="") ? $this ->input -> post ('partially_vaccinated_row4') : Null , 
								'upto_date_vaccinated_row4' =>($this ->input -> post ('upto_date_vaccinated_row4')!="") ? $this ->input -> post ('upto_date_vaccinated_row4') : Null , 
								'v1_hepa_b_bd_row4' =>($this ->input -> post ('v1_hepa_b_bd_row4')!="") ? $this ->input -> post ('v1_hepa_b_bd_row4') : Null , 
								'v2_pcv10_1_row4' =>($this ->input -> post ('v2_pcv10_1_row4')!="") ? $this ->input -> post ('v2_pcv10_1_row4') : Null , 
								'v3_pcv10_2_row4' =>($this ->input -> post ('v3_pcv10_2_row4')!="") ? $this ->input -> post ('v3_pcv10_2_row4') : Null , 
								'v4_pcv10_3_row4' =>($this ->input -> post ('v4_pcv10_3_row4')!="") ? $this ->input -> post ('v4_pcv10_3_row4') : Null , 
								'v1_opv_0_row4' =>($this ->input -> post ('v1_opv_0_row4')!="") ? $this ->input -> post ('v1_opv_0_row4') : Null , 
								'v2_opv_1_row4' =>($this ->input -> post ('v2_opv_1_row4')!="") ? $this ->input -> post ('v2_opv_1_row4') : Null , 
								'v3_opv_2_row4' =>($this ->input -> post ('v3_opv_2_row4')!="") ? $this ->input -> post ('v3_opv_2_row4') : Null , 
								'v4_opv_3_row4' =>($this ->input -> post ('v4_opv_3_row4')!="") ? $this ->input -> post ('v4_opv_3_row4') : Null , 
								'v2_rota_1_row4' =>($this ->input -> post ('v2_rota_1_row4')!="") ? $this ->input -> post ('v2_rota_1_row4') : Null , 
								'v3_rota_2_row4' =>($this ->input -> post ('v3_rota_2_row4')!="") ? $this ->input -> post ('v3_rota_2_row4') : Null , 
								'v4_ipv_row4' =>($this ->input -> post ('v4_ipv_row4')!="") ? $this ->input -> post ('v4_ipv_row4') : Null , 
								'cardno_row5' =>($this ->input -> post ('cardno_row5')) ? $this ->input -> post ('cardno_row5') : Null , 
								'childname_row5' =>($this ->input -> post ('childname_row5')) ? $this ->input -> post ('childname_row5') : Null , 
								'fathername_row5' =>($this ->input -> post ('fathername_row5')) ? $this ->input -> post ('fathername_row5') : Null , 
								'contact_row5' =>($this ->input -> post ('contact_row5')) ? $this ->input -> post ('contact_row5') : Null , 
								'age_dob_row5' =>($this ->input -> post ('age_dob_row5')) ? $this ->input -> post ('age_dob_row5') : Null , 
								'v1_bcg_row5' =>($this ->input -> post ('v1_bcg_row5')!="") ? $this ->input -> post ('v1_bcg_row5') : Null , 
								'v2_penta_1_row5' =>($this ->input -> post ('v2_penta_1_row5')!="") ? $this ->input -> post ('v2_penta_1_row5') : Null , 
								'v3_penta_2_row5' =>($this ->input -> post ('v3_penta_2_row5')!="") ? $this ->input -> post ('v3_penta_2_row5') : Null , 
								'v4_penta_3_row5' =>($this ->input -> post ('v4_penta_3_row5')!="") ? $this ->input -> post ('v4_penta_3_row5') : Null , 
								'v5_measles1_row5' =>($this ->input -> post ('v5_measles1_row5')!="") ? $this ->input -> post ('v5_measles1_row5') : Null , 
								'v6_measles2_row5' =>($this ->input -> post ('v6_measles2_row5')!="") ? $this ->input -> post ('v6_measles2_row5') : Null , 
								'un_vaccinated_row5' =>($this ->input -> post ('un_vaccinated_row5')!="") ? $this ->input -> post ('un_vaccinated_row5') : Null , 
								'partially_vaccinated_row5' =>($this ->input -> post ('partially_vaccinated_row5')!="") ? $this ->input -> post ('partially_vaccinated_row5') : Null , 
								'upto_date_vaccinated_row5' =>($this ->input -> post ('upto_date_vaccinated_row5')!="") ? $this ->input -> post ('upto_date_vaccinated_row5') : Null , 
								'v1_hepa_b_bd_row5' =>($this ->input -> post ('v1_hepa_b_bd_row5')!="") ? $this ->input -> post ('v1_hepa_b_bd_row5') : Null , 
								'v2_pcv10_1_row5' =>($this ->input -> post ('v2_pcv10_1_row5')!="") ? $this ->input -> post ('v2_pcv10_1_row5') : Null , 
								'v3_pcv10_2_row5' =>($this ->input -> post ('v3_pcv10_2_row5')!="") ? $this ->input -> post ('v3_pcv10_2_row5') : Null , 
								'v4_pcv10_3_row5' =>($this ->input -> post ('v4_pcv10_3_row5')!="") ? $this ->input -> post ('v4_pcv10_3_row5') : Null , 
								'v1_opv_0_row5' =>($this ->input -> post ('v1_opv_0_row5')!="") ? $this ->input -> post ('v1_opv_0_row5') : Null , 
								'v2_opv_1_row5' =>($this ->input -> post ('v2_opv_1_row5')!="") ? $this ->input -> post ('v2_opv_1_row5') : Null , 
								'v3_opv_2_row5' =>($this ->input -> post ('v3_opv_2_row5')!="") ? $this ->input -> post ('v3_opv_2_row5') : Null , 
								'v4_opv_3_row5' =>($this ->input -> post ('v4_opv_3_row5')!="") ? $this ->input -> post ('v4_opv_3_row5') : Null , 
								'v2_rota_1_row5' =>($this ->input -> post ('v2_rota_1_row5')!="") ? $this ->input -> post ('v2_rota_1_row5') : Null , 
								'v3_rota_2_row5' =>($this ->input -> post ('v3_rota_2_row5')!="") ? $this ->input -> post ('v3_rota_2_row5') : Null , 
								'v4_ipv_row5' =>($this ->input -> post ('v4_ipv_row5')!="") ? $this ->input -> post ('v4_ipv_row5') : Null , 
								'cardno_row6' =>($this ->input -> post ('cardno_row6')) ? $this ->input -> post ('cardno_row6') : Null , 
								'childname_row6' =>($this ->input -> post ('childname_row6')) ? $this ->input -> post ('childname_row6') : Null , 
								'fathername_row6' =>($this ->input -> post ('fathername_row6')) ? $this ->input -> post ('fathername_row6') : Null , 
								'contact_row6' =>($this ->input -> post ('contact_row6')) ? $this ->input -> post ('contact_row6') : Null , 
								'age_dob_row6' =>($this ->input -> post ('age_dob_row6')) ? $this ->input -> post ('age_dob_row6') : Null , 
								'v1_bcg_row6' =>($this ->input -> post ('v1_bcg_row6')!="") ? $this ->input -> post ('v1_bcg_row6') : Null , 
								'v2_penta_1_row6' =>($this ->input -> post ('v2_penta_1_row6')!="") ? $this ->input -> post ('v2_penta_1_row6') : Null , 
								'v3_penta_2_row6' =>($this ->input -> post ('v3_penta_2_row6')!="") ? $this ->input -> post ('v3_penta_2_row6') : Null , 
								'v4_penta_3_row6' =>($this ->input -> post ('v4_penta_3_row6')!="") ? $this ->input -> post ('v4_penta_3_row6') : Null , 
								'v5_measles1_row6' =>($this ->input -> post ('v5_measles1_row6')!="") ? $this ->input -> post ('v5_measles1_row6') : Null , 
								'v6_measles2_row6' =>($this ->input -> post ('v6_measles2_row6')!="") ? $this ->input -> post ('v6_measles2_row6') : Null , 
								'un_vaccinated_row6' =>($this ->input -> post ('un_vaccinated_row6')!="") ? $this ->input -> post ('un_vaccinated_row6') : Null , 
								'partially_vaccinated_row6' =>($this ->input -> post ('partially_vaccinated_row6')!="") ? $this ->input -> post ('partially_vaccinated_row6') : Null , 
								'upto_date_vaccinated_row6' =>($this ->input -> post ('upto_date_vaccinated_row6')!="") ? $this ->input -> post ('upto_date_vaccinated_row6') : Null , 
								'v1_hepa_b_bd_row6' =>($this ->input -> post ('v1_hepa_b_bd_row6')!="") ? $this ->input -> post ('v1_hepa_b_bd_row6') : Null , 
								'v2_pcv10_1_row6' =>($this ->input -> post ('v2_pcv10_1_row6')!="") ? $this ->input -> post ('v2_pcv10_1_row6') : Null , 
								'v3_pcv10_2_row6' =>($this ->input -> post ('v3_pcv10_2_row6')!="") ? $this ->input -> post ('v3_pcv10_2_row6') : Null , 
								'v4_pcv10_3_row6' =>($this ->input -> post ('v4_pcv10_3_row6')!="") ? $this ->input -> post ('v4_pcv10_3_row6') : Null , 
								'v1_opv_0_row6' =>($this ->input -> post ('v1_opv_0_row6')!="") ? $this ->input -> post ('v1_opv_0_row6') : Null , 
								'v2_opv_1_row6' =>($this ->input -> post ('v2_opv_1_row6')!="") ? $this ->input -> post ('v2_opv_1_row6') : Null , 
								'v3_opv_2_row6' =>($this ->input -> post ('v3_opv_2_row6')!="") ? $this ->input -> post ('v3_opv_2_row6') : Null , 
								'v4_opv_3_row6' =>($this ->input -> post ('v4_opv_3_row6')!="") ? $this ->input -> post ('v4_opv_3_row6') : Null , 
								'v2_rota_1_row6' =>($this ->input -> post ('v2_rota_1_row6')!="") ? $this ->input -> post ('v2_rota_1_row6') : Null , 
								'v3_rota_2_row6' =>($this ->input -> post ('v3_rota_2_row6')!="") ? $this ->input -> post ('v3_rota_2_row6') : Null , 
								'v4_ipv_row6' =>($this ->input -> post ('v4_ipv_row6')!="") ? $this ->input -> post ('v4_ipv_row6') : Null , 
								'cardno_row7' =>($this ->input -> post ('cardno_row7')) ? $this ->input -> post ('cardno_row7') : Null , 
								'childname_row7' =>($this ->input -> post ('childname_row7')) ? $this ->input -> post ('childname_row7') : Null , 
								'fathername_row7' =>($this ->input -> post ('fathername_row7')) ? $this ->input -> post ('fathername_row7') : Null , 
								'contact_row7' =>($this ->input -> post ('contact_row7')) ? $this ->input -> post ('contact_row7') : Null , 
								'age_dob_row7' =>($this ->input -> post ('age_dob_row7')) ? $this ->input -> post ('age_dob_row7') : Null , 
								'v1_bcg_row7' =>($this ->input -> post ('v1_bcg_row7')!="") ? $this ->input -> post ('v1_bcg_row7') : Null , 
								'v2_penta_1_row7' =>($this ->input -> post ('v2_penta_1_row7')!="") ? $this ->input -> post ('v2_penta_1_row7') : Null , 
								'v3_penta_2_row7' =>($this ->input -> post ('v3_penta_2_row7')!="") ? $this ->input -> post ('v3_penta_2_row7') : Null , 
								'v4_penta_3_row7' =>($this ->input -> post ('v4_penta_3_row7')!="") ? $this ->input -> post ('v4_penta_3_row7') : Null , 
								'v5_measles1_row7' =>($this ->input -> post ('v5_measles1_row7')!="") ? $this ->input -> post ('v5_measles1_row7') : Null , 
								'v6_measles2_row7' =>($this ->input -> post ('v6_measles2_row7')!="") ? $this ->input -> post ('v6_measles2_row7') : Null , 
								'un_vaccinated_row7' =>($this ->input -> post ('un_vaccinated_row7')!="") ? $this ->input -> post ('un_vaccinated_row7') : Null , 
								'partially_vaccinated_row7' =>($this ->input -> post ('partially_vaccinated_row7')!="") ? $this ->input -> post ('partially_vaccinated_row7') : Null , 
								'upto_date_vaccinated_row7' =>($this ->input -> post ('upto_date_vaccinated_row7')!="") ? $this ->input -> post ('upto_date_vaccinated_row7') : Null , 
								'v1_hepa_b_bd_row7' =>($this ->input -> post ('v1_hepa_b_bd_row7')!="") ? $this ->input -> post ('v1_hepa_b_bd_row7') : Null , 
								'v2_pcv10_1_row7' =>($this ->input -> post ('v2_pcv10_1_row7')!="") ? $this ->input -> post ('v2_pcv10_1_row7') : Null , 
								'v3_pcv10_2_row7' =>($this ->input -> post ('v3_pcv10_2_row7')!="") ? $this ->input -> post ('v3_pcv10_2_row7') : Null , 
								'v4_pcv10_3_row7' =>($this ->input -> post ('v4_pcv10_3_row7')!="") ? $this ->input -> post ('v4_pcv10_3_row7') : Null , 
								'v1_opv_0_row7' =>($this ->input -> post ('v1_opv_0_row7')!="") ? $this ->input -> post ('v1_opv_0_row7') : Null , 
								'v2_opv_1_row7' =>($this ->input -> post ('v2_opv_1_row7')!="") ? $this ->input -> post ('v2_opv_1_row7') : Null , 
								'v3_opv_2_row7' =>($this ->input -> post ('v3_opv_2_row7')!="") ? $this ->input -> post ('v3_opv_2_row7') : Null , 
								'v4_opv_3_row7' =>($this ->input -> post ('v4_opv_3_row7')!="") ? $this ->input -> post ('v4_opv_3_row7') : Null , 
								'v2_rota_1_row7' =>($this ->input -> post ('v2_rota_1_row7')!="") ? $this ->input -> post ('v2_rota_1_row7') : Null , 
								'v3_rota_2_row7' =>($this ->input -> post ('v3_rota_2_row7')!="") ? $this ->input -> post ('v3_rota_2_row7') : Null , 
								'v4_ipv_row7' =>($this ->input -> post ('v4_ipv_row7')!="") ? $this ->input -> post ('v4_ipv_row7') : Null , 
								'cardno_row8' =>($this ->input -> post ('cardno_row8')) ? $this ->input -> post ('cardno_row8') : Null , 
								'childname_row8' =>($this ->input -> post ('childname_row8')) ? $this ->input -> post ('childname_row8') : Null , 
								'fathername_row8' =>($this ->input -> post ('fathername_row8')) ? $this ->input -> post ('fathername_row8') : Null , 
								'contact_row8' =>($this ->input -> post ('contact_row8')) ? $this ->input -> post ('contact_row8') : Null , 
								'age_dob_row8' =>($this ->input -> post ('age_dob_row8')) ? $this ->input -> post ('age_dob_row8') : Null , 
								'v1_bcg_row8' =>($this ->input -> post ('v1_bcg_row8')!="") ? $this ->input -> post ('v1_bcg_row8') : Null , 
								'v2_penta_1_row8' =>($this ->input -> post ('v2_penta_1_row8')!="") ? $this ->input -> post ('v2_penta_1_row8') : Null , 
								'v3_penta_2_row8' =>($this ->input -> post ('v3_penta_2_row8')!="") ? $this ->input -> post ('v3_penta_2_row8') : Null , 
								'v4_penta_3_row8' =>($this ->input -> post ('v4_penta_3_row8')!="") ? $this ->input -> post ('v4_penta_3_row8') : Null , 
								'v5_measles1_row8' =>($this ->input -> post ('v5_measles1_row8')!="") ? $this ->input -> post ('v5_measles1_row8') : Null , 
								'v6_measles2_row8' =>($this ->input -> post ('v6_measles2_row8')!="") ? $this ->input -> post ('v6_measles2_row8') : Null , 
								'un_vaccinated_row8' =>($this ->input -> post ('un_vaccinated_row8')!="") ? $this ->input -> post ('un_vaccinated_row8') : Null , 
								'partially_vaccinated_row8' =>($this ->input -> post ('partially_vaccinated_row8')!="") ? $this ->input -> post ('partially_vaccinated_row8') : Null , 
								'upto_date_vaccinated_row8' =>($this ->input -> post ('upto_date_vaccinated_row8')!="") ? $this ->input -> post ('upto_date_vaccinated_row8') : Null , 
								'v1_hepa_b_bd_row8' =>($this ->input -> post ('v1_hepa_b_bd_row8')) ? $this ->input -> post ('v1_hepa_b_bd_row8') : Null , 
								'v2_pcv10_1_row8' =>($this ->input -> post ('v2_pcv10_1_row8')!="") ? $this ->input -> post ('v2_pcv10_1_row8') : Null , 
								'v3_pcv10_2_row8' =>($this ->input -> post ('v3_pcv10_2_row8')!="") ? $this ->input -> post ('v3_pcv10_2_row8') : Null , 
								'v4_pcv10_3_row8' =>($this ->input -> post ('v4_pcv10_3_row8')!="") ? $this ->input -> post ('v4_pcv10_3_row8') : Null , 
								'v1_opv_0_row8' =>($this ->input -> post ('v1_opv_0_row8')!="") ? $this ->input -> post ('v1_opv_0_row8') : Null , 
								'v2_opv_1_row8' =>($this ->input -> post ('v2_opv_1_row8')!="") ? $this ->input -> post ('v2_opv_1_row8') : Null , 
								'v3_opv_2_row8' =>($this ->input -> post ('v3_opv_2_row8')!="") ? $this ->input -> post ('v3_opv_2_row8') : Null , 
								'v4_opv_3_row8' =>($this ->input -> post ('v4_opv_3_row8')!="") ? $this ->input -> post ('v4_opv_3_row8') : Null , 
								'v2_rota_1_row8' =>($this ->input -> post ('v2_rota_1_row8')!="") ? $this ->input -> post ('v2_rota_1_row8') : Null , 
								'v3_rota_2_row8' =>($this ->input -> post ('v3_rota_2_row8')!="") ? $this ->input -> post ('v3_rota_2_row8') : Null , 
								'v4_ipv_row8' =>($this ->input -> post ('v4_ipv_row8')!="") ? $this ->input -> post ('v4_ipv_row8') : Null , 
								'cardno_row9' =>($this ->input -> post ('cardno_row9')) ? $this ->input -> post ('cardno_row9') : Null , 
								'childname_row9' =>($this ->input -> post ('childname_row9')) ? $this ->input -> post ('childname_row9') : Null , 
								'fathername_row9' =>($this ->input -> post ('fathername_row9')) ? $this ->input -> post ('fathername_row9') : Null , 
								'contact_row9' =>($this ->input -> post ('contact_row9')) ? $this ->input -> post ('contact_row9') : Null , 
								'age_dob_row9' =>($this ->input -> post ('age_dob_row9')) ? $this ->input -> post ('age_dob_row9') : Null , 
								'v1_bcg_row9' =>($this ->input -> post ('v1_bcg_row9')!="") ? $this ->input -> post ('v1_bcg_row9') : Null , 
								'v2_penta_1_row9' =>($this ->input -> post ('v2_penta_1_row9')!="") ? $this ->input -> post ('v2_penta_1_row9') : Null , 
								'v3_penta_2_row9' =>($this ->input -> post ('v3_penta_2_row9')!="") ? $this ->input -> post ('v3_penta_2_row9') : Null , 
								'v4_penta_3_row9' =>($this ->input -> post ('v4_penta_3_row9')!="") ? $this ->input -> post ('v4_penta_3_row9') : Null , 
								'v5_measles1_row9' =>($this ->input -> post ('v5_measles1_row9')!="") ? $this ->input -> post ('v5_measles1_row9') : Null , 
								'v6_measles2_row9' =>($this ->input -> post ('v6_measles2_row9')!="") ? $this ->input -> post ('v6_measles2_row9') : Null , 
								'un_vaccinated_row9' =>($this ->input -> post ('un_vaccinated_row9')!="") ? $this ->input -> post ('un_vaccinated_row9') : Null , 
								'partially_vaccinated_row9' =>($this ->input -> post ('partially_vaccinated_row9')!="") ? $this ->input -> post ('partially_vaccinated_row9') : Null , 
								'upto_date_vaccinated_row9' =>($this ->input -> post ('upto_date_vaccinated_row9')!="") ? $this ->input -> post ('upto_date_vaccinated_row9') : Null , 
								'v1_hepa_b_bd_row9' =>($this ->input -> post ('v1_hepa_b_bd_row9')!="") ? $this ->input -> post ('v1_hepa_b_bd_row9') : Null , 
								'v2_pcv10_1_row9' =>($this ->input -> post ('v2_pcv10_1_row9')!="") ? $this ->input -> post ('v2_pcv10_1_row9') : Null , 
								'v3_pcv10_2_row9' =>($this ->input -> post ('v3_pcv10_2_row9')!="") ? $this ->input -> post ('v3_pcv10_2_row9') : Null , 
								'v4_pcv10_3_row9' =>($this ->input -> post ('v4_pcv10_3_row9')!="") ? $this ->input -> post ('v4_pcv10_3_row9') : Null , 
								'v1_opv_0_row9' =>($this ->input -> post ('v1_opv_0_row9')!="") ? $this ->input -> post ('v1_opv_0_row9') : Null , 
								'v2_opv_1_row9' =>($this ->input -> post ('v2_opv_1_row9')!="") ? $this ->input -> post ('v2_opv_1_row9') : Null , 
								'v3_opv_2_row9' =>($this ->input -> post ('v3_opv_2_row9')!="") ? $this ->input -> post ('v3_opv_2_row9') : Null , 
								'v4_opv_3_row9' =>($this ->input -> post ('v4_opv_3_row9')!="") ? $this ->input -> post ('v4_opv_3_row9') : Null , 
								'v2_rota_1_row9' =>($this ->input -> post ('v2_rota_1_row9')!="") ? $this ->input -> post ('v2_rota_1_row9') : Null , 
								'v3_rota_2_row9' =>($this ->input -> post ('v3_rota_2_row9')!="") ? $this ->input -> post ('v3_rota_2_row9') : Null , 
								'v4_ipv_row9' =>($this ->input -> post ('v4_ipv_row9')!="") ? $this ->input -> post ('v4_ipv_row9') : Null , 
								'cardno_row10' =>($this ->input -> post ('cardno_row10')) ? $this ->input -> post ('cardno_row10') : Null , 
								'childname_row10' =>($this ->input -> post ('childname_row10')) ? $this ->input -> post ('childname_row10') : Null , 
								'fathername_row10' =>($this ->input -> post ('fathername_row10')) ? $this ->input -> post ('fathername_row10') : Null , 
								'contact_row10' =>($this ->input -> post ('contact_row10')) ? $this ->input -> post ('contact_row10') : Null , 
								'age_dob_row10' =>($this ->input -> post ('age_dob_row10')) ? $this ->input -> post ('age_dob_row10') : Null , 
								'v1_bcg_row10' =>($this ->input -> post ('v1_bcg_row10')!="") ? $this ->input -> post ('v1_bcg_row10') : Null , 
								'v2_penta_1_row10' =>($this ->input -> post ('v2_penta_1_row10')!="") ? $this ->input -> post ('v2_penta_1_row10') : Null , 
								'v3_penta_2_row10' =>($this ->input -> post ('v3_penta_2_row10')!="") ? $this ->input -> post ('v3_penta_2_row10') : Null , 
								'v4_penta_3_row10' =>($this ->input -> post ('v4_penta_3_row10')!="") ? $this ->input -> post ('v4_penta_3_row10') : Null , 
								'v5_measles1_row10' =>($this ->input -> post ('v5_measles1_row10')!="") ? $this ->input -> post ('v5_measles1_row10') : Null , 
								'v6_measles2_row10' =>($this ->input -> post ('v6_measles2_row10')!="") ? $this ->input -> post ('v6_measles2_row10') : Null , 
								'un_vaccinated_row10' =>($this ->input -> post ('un_vaccinated_row10')!="") ? $this ->input -> post ('un_vaccinated_row10') : Null , 
								'partially_vaccinated_row10' =>($this ->input -> post ('partially_vaccinated_row10')!="") ? $this ->input -> post ('partially_vaccinated_row10') : Null , 
								'upto_date_vaccinated_row10' =>($this ->input -> post ('upto_date_vaccinated_row10')!="") ? $this ->input -> post ('upto_date_vaccinated_row10') : Null , 
								'v1_hepa_b_bd_row10' =>($this ->input -> post ('v1_hepa_b_bd_row10')!="") ? $this ->input -> post ('v1_hepa_b_bd_row10') : Null , 
								'v2_pcv10_1_row10' =>($this ->input -> post ('v2_pcv10_1_row10')!="") ? $this ->input -> post ('v2_pcv10_1_row10') : Null , 
								'v3_pcv10_2_row10' =>($this ->input -> post ('v3_pcv10_2_row10')!="") ? $this ->input -> post ('v3_pcv10_2_row10') : Null , 
								'v4_pcv10_3_row10' =>($this ->input -> post ('v4_pcv10_3_row10')!="") ? $this ->input -> post ('v4_pcv10_3_row10') : Null , 
								'v1_opv_0_row10' =>($this ->input -> post ('v1_opv_0_row10')!="") ? $this ->input -> post ('v1_opv_0_row10') : Null , 
								'v2_opv_1_row10' =>($this ->input -> post ('v2_opv_1_row10')!="") ? $this ->input -> post ('v2_opv_1_row10') : Null , 
								'v3_opv_2_row10' =>($this ->input -> post ('v3_opv_2_row10')!="") ? $this ->input -> post ('v3_opv_2_row10') : Null , 
								'v4_opv_3_row10' =>($this ->input -> post ('v4_opv_3_row10')!="") ? $this ->input -> post ('v4_opv_3_row10') : Null , 
								'v2_rota_1_row10' =>($this ->input -> post ('v2_rota_1_row10')!="") ? $this ->input -> post ('v2_rota_1_row10') : Null , 
								'v3_rota_2_row10' =>($this ->input -> post ('v3_rota_2_row10')!="") ? $this ->input -> post ('v3_rota_2_row10') : Null , 
								'v4_ipv_row10' =>($this ->input -> post ('v4_ipv_row10')!="") ? $this ->input -> post ('v4_ipv_row10') : Null , 
								'total_children_checked' =>($this ->input -> post ('total_children_checked')) ? $this ->input -> post ('total_children_checked') : Null , 
								'total_un_vaccinated' =>($this ->input -> post ('total_un_vaccinated')) ? $this ->input -> post ('total_un_vaccinated') : Null , 
								'total_partially_vaccinated' =>($this ->input -> post ('total_partially_vaccinated')) ? $this ->input -> post ('total_partially_vaccinated') : Null , 
								'total_up_to_date_vaccinated' =>($this ->input -> post ('total_up_to_date_vaccinated')) ? $this ->input -> post ('total_up_to_date_vaccinated') : Null , 
								'remarks' =>($this ->input -> post ('remarks')) ? $this ->input -> post ('remarks') : Null , 
								'monitor_name' =>($this ->input -> post ('monitor_name')) ? $this ->input -> post ('monitor_name') : Null , 
								'verified_by' =>($this ->input -> post ('verified_by')) ? $this ->input -> post ('verified_by') : Null , 
								'quarter' =>($this ->input -> post ('quarter')) ? $this ->input -> post ('quarter') : Null , 
								'fk_id' =>($this ->input -> post ('id')) ? $this ->input -> post ('id') : Null , 
								'v1_bcg_date_row1' =>($this ->input -> post ('v1_bcg_date_row1')) ? $this ->input -> post ('v1_bcg_date_row1') : Null , 
								'v2_penta_1_date_row1' =>($this ->input -> post ('v2_penta_1_date_row1')) ? $this ->input -> post ('v2_penta_1_date_row1') : Null , 
								'v3_penta_2_date_row1' =>($this ->input -> post ('v3_penta_2_date_row1')) ? $this ->input -> post ('v3_penta_2_date_row1') : Null , 
								'v4_penta_3_date_row1' =>($this ->input -> post ('v4_penta_3_date_row1')) ? $this ->input -> post ('v4_penta_3_date_row1') : Null , 
								'v5_measles1_date_row1' =>($this ->input -> post ('v5_measles1_date_row1')) ? $this ->input -> post ('v5_measles1_date_row1') : Null , 
								'v6_measles2_date_row1' =>($this ->input -> post ('v6_measles2_date_row1')) ? $this ->input -> post ('v6_measles2_date_row1') : Null , 
								'v1_hepa_b_bd_date_row1' =>($this ->input -> post ('v1_hepa_b_bd_date_row1')) ? $this ->input -> post ('v1_hepa_b_bd_date_row1') : Null , 
								'v2_pcv10_1_date_row1' =>($this ->input -> post ('v2_pcv10_1_date_row1')) ? $this ->input -> post ('v2_pcv10_1_date_row1') : Null , 
								'v3_pcv10_2_date_row1' =>($this ->input -> post ('v3_pcv10_2_date_row1')) ? $this ->input -> post ('v3_pcv10_2_date_row1') : Null , 
								'v4_pcv10_3_date_row1' =>($this ->input -> post ('v4_pcv10_3_date_row1')) ? $this ->input -> post ('v4_pcv10_3_date_row1') : Null , 
								'v1_opv_0_date_row1' =>($this ->input -> post ('v1_opv_0_date_row1')) ? $this ->input -> post ('v1_opv_0_date_row1') : Null , 
								'v2_opv_1_date_row1' =>($this ->input -> post ('v2_opv_1_date_row1')) ? $this ->input -> post ('v2_opv_1_date_row1') : Null , 
								'v3_opv_2_date_row1' =>($this ->input -> post ('v3_opv_2_date_row1')) ? $this ->input -> post ('v3_opv_2_date_row1') : Null , 
								'v4_opv_3_date_row1' =>($this ->input -> post ('v4_opv_3_date_row1')) ? $this ->input -> post ('v4_opv_3_date_row1') : Null , 
								'v2_rota_1_date_row1' =>($this ->input -> post ('v2_rota_1_date_row1')) ? $this ->input -> post ('v2_rota_1_date_row1') : Null , 
								'v3_rota_2_date_row1' =>($this ->input -> post ('v3_rota_2_date_row1')) ? $this ->input -> post ('v3_rota_2_date_row1') : Null , 
								'v4_ipv_date_row1' =>($this ->input -> post ('v4_ipv_date_row1')) ? $this ->input -> post ('v4_ipv_date_row1') : Null , 
								'v1_bcg_date_row2' =>($this ->input -> post ('v1_bcg_date_row2')) ? $this ->input -> post ('v1_bcg_date_row2') : Null , 
								'v2_penta_1_date_row2' =>($this ->input -> post ('v2_penta_1_date_row2')) ? $this ->input -> post ('v2_penta_1_date_row2') : Null , 
								'v3_penta_2_date_row2' =>($this ->input -> post ('v3_penta_2_date_row2')) ? $this ->input -> post ('v3_penta_2_date_row2') : Null , 
								'v4_penta_3_date_row2' =>($this ->input -> post ('v4_penta_3_date_row2')) ? $this ->input -> post ('v4_penta_3_date_row2') : Null , 
								'v5_measles1_date_row2' =>($this ->input -> post ('v5_measles1_date_row2')) ? $this ->input -> post ('v5_measles1_date_row2') : Null , 
								'v6_measles2_date_row2' =>($this ->input -> post ('v6_measles2_date_row2')) ? $this ->input -> post ('v6_measles2_date_row2') : Null , 
								'v1_hepa_b_bd_date_row2' =>($this ->input -> post ('v1_hepa_b_bd_date_row2')) ? $this ->input -> post ('v1_hepa_b_bd_date_row2') : Null , 
								'v2_pcv10_1_date_row2' =>($this ->input -> post ('v2_pcv10_1_date_row2')) ? $this ->input -> post ('v2_pcv10_1_date_row2') : Null , 
								'v3_pcv10_2_date_row2' =>($this ->input -> post ('v3_pcv10_2_date_row2')) ? $this ->input -> post ('v3_pcv10_2_date_row2') : Null , 
								'v4_pcv10_3_date_row2' =>($this ->input -> post ('v4_pcv10_3_date_row2')) ? $this ->input -> post ('v4_pcv10_3_date_row2') : Null , 
								'v1_opv_0_date_row2' =>($this ->input -> post ('v1_opv_0_date_row2')) ? $this ->input -> post ('v1_opv_0_date_row2') : Null , 
								'v2_opv_1_date_row2' =>($this ->input -> post ('v2_opv_1_date_row2')) ? $this ->input -> post ('v2_opv_1_date_row2') : Null , 
								'v3_opv_2_date_row2' =>($this ->input -> post ('v3_opv_2_date_row2')) ? $this ->input -> post ('v3_opv_2_date_row2') : Null , 
								'v4_opv_3_date_row2' =>($this ->input -> post ('v4_opv_3_date_row2')) ? $this ->input -> post ('v4_opv_3_date_row2') : Null , 
								'v2_rota_1_date_row2' =>($this ->input -> post ('v2_rota_1_date_row2')) ? $this ->input -> post ('v2_rota_1_date_row2') : Null , 
								'v3_rota_2_date_row2' =>($this ->input -> post ('v3_rota_2_date_row2')) ? $this ->input -> post ('v3_rota_2_date_row2') : Null , 
								'v4_ipv_date_row2' =>($this ->input -> post ('v4_ipv_date_row2')) ? $this ->input -> post ('v4_ipv_date_row2') : Null , 
								'v1_bcg_date_row3' =>($this ->input -> post ('v1_bcg_date_row3')) ? $this ->input -> post ('v1_bcg_date_row3') : Null , 
								'v2_penta_1_date_row3' =>($this ->input -> post ('v2_penta_1_date_row3')) ? $this ->input -> post ('v2_penta_1_date_row3') : Null , 
								'v3_penta_2_date_row3' =>($this ->input -> post ('v3_penta_2_date_row3')) ? $this ->input -> post ('v3_penta_2_date_row3') : Null , 
								'v4_penta_3_date_row3' =>($this ->input -> post ('v4_penta_3_date_row3')) ? $this ->input -> post ('v4_penta_3_date_row3') : Null , 
								'v5_measles1_date_row3' =>($this ->input -> post ('v5_measles1_date_row3')) ? $this ->input -> post ('v5_measles1_date_row3') : Null , 
								'v6_measles2_date_row3' =>($this ->input -> post ('v6_measles2_date_row3')) ? $this ->input -> post ('v6_measles2_date_row3') : Null , 
								'v1_hepa_b_bd_date_row3' =>($this ->input -> post ('v1_hepa_b_bd_date_row3')) ? $this ->input -> post ('v1_hepa_b_bd_date_row3') : Null , 
								'v2_pcv10_1_date_row3' =>($this ->input -> post ('v2_pcv10_1_date_row3')) ? $this ->input -> post ('v2_pcv10_1_date_row3') : Null , 
								'v3_pcv10_2_date_row3' =>($this ->input -> post ('v3_pcv10_2_date_row3')) ? $this ->input -> post ('v3_pcv10_2_date_row3') : Null , 
								'v4_pcv10_3_date_row3' =>($this ->input -> post ('v4_pcv10_3_date_row3')) ? $this ->input -> post ('v4_pcv10_3_date_row3') : Null , 
								'v1_opv_0_date_row3' =>($this ->input -> post ('v1_opv_0_date_row3')) ? $this ->input -> post ('v1_opv_0_date_row3') : Null , 
								'v2_opv_1_date_row3' =>($this ->input -> post ('v2_opv_1_date_row3')) ? $this ->input -> post ('v2_opv_1_date_row3') : Null , 
								'v3_opv_2_date_row3' =>($this ->input -> post ('v3_opv_2_date_row3')) ? $this ->input -> post ('v3_opv_2_date_row3') : Null , 
								'v4_opv_3_date_row3' =>($this ->input -> post ('v4_opv_3_date_row3')) ? $this ->input -> post ('v4_opv_3_date_row3') : Null , 
								'v2_rota_1_date_row3' =>($this ->input -> post ('v2_rota_1_date_row3')) ? $this ->input -> post ('v2_rota_1_date_row3') : Null , 
								'v3_rota_2_date_row3' =>($this ->input -> post ('v3_rota_2_date_row3')) ? $this ->input -> post ('v3_rota_2_date_row3') : Null , 
								'v4_ipv_date_row3' =>($this ->input -> post ('v4_ipv_date_row3')) ? $this ->input -> post ('v4_ipv_date_row3') : Null , 
								'v1_bcg_date_row4' =>($this ->input -> post ('v1_bcg_date_row4')) ? $this ->input -> post ('v1_bcg_date_row4') : Null , 
								'v2_penta_1_date_row4' =>($this ->input -> post ('v2_penta_1_date_row4')) ? $this ->input -> post ('v2_penta_1_date_row4') : Null , 
								'v3_penta_2_date_row4' =>($this ->input -> post ('v3_penta_2_date_row4')) ? $this ->input -> post ('v3_penta_2_date_row4') : Null , 
								'v4_penta_3_date_row4' =>($this ->input -> post ('v4_penta_3_date_row4')) ? $this ->input -> post ('v4_penta_3_date_row4') : Null , 
								'v5_measles1_date_row4' =>($this ->input -> post ('v5_measles1_date_row4')) ? $this ->input -> post ('v5_measles1_date_row4') : Null , 
								'v6_measles2_date_row4' =>($this ->input -> post ('v6_measles2_date_row4')) ? $this ->input -> post ('v6_measles2_date_row4') : Null , 
								'v1_hepa_b_bd_date_row4' =>($this ->input -> post ('v1_hepa_b_bd_date_row4')) ? $this ->input -> post ('v1_hepa_b_bd_date_row4') : Null , 
								'v2_pcv10_1_date_row4' =>($this ->input -> post ('v2_pcv10_1_date_row4')) ? $this ->input -> post ('v2_pcv10_1_date_row4') : Null , 
								'v3_pcv10_2_date_row4' =>($this ->input -> post ('v3_pcv10_2_date_row4')) ? $this ->input -> post ('v3_pcv10_2_date_row4') : Null , 
								'v4_pcv10_3_date_row4' =>($this ->input -> post ('v4_pcv10_3_date_row4')) ? $this ->input -> post ('v4_pcv10_3_date_row4') : Null , 
								'v1_opv_0_date_row4' =>($this ->input -> post ('v1_opv_0_date_row4')) ? $this ->input -> post ('v1_opv_0_date_row4') : Null , 
								'v2_opv_1_date_row4' =>($this ->input -> post ('v2_opv_1_date_row4')) ? $this ->input -> post ('v2_opv_1_date_row4') : Null , 
								'v3_opv_2_date_row4' =>($this ->input -> post ('v3_opv_2_date_row4')) ? $this ->input -> post ('v3_opv_2_date_row4') : Null , 
								'v4_opv_3_date_row4' =>($this ->input -> post ('v4_opv_3_date_row4')) ? $this ->input -> post ('v4_opv_3_date_row4') : Null , 
								'v2_rota_1_date_row4' =>($this ->input -> post ('v2_rota_1_date_row4')) ? $this ->input -> post ('v2_rota_1_date_row4') : Null , 
								'v3_rota_2_date_row4' =>($this ->input -> post ('v3_rota_2_date_row4')) ? $this ->input -> post ('v3_rota_2_date_row4') : Null , 
								'v4_ipv_date_row4' =>($this ->input -> post ('v4_ipv_date_row4')) ? $this ->input -> post ('v4_ipv_date_row4') : Null , 
								'v1_bcg_date_row5' =>($this ->input -> post ('v1_bcg_date_row5')) ? $this ->input -> post ('v1_bcg_date_row5') : Null , 
								'v2_penta_1_date_row5' =>($this ->input -> post ('v2_penta_1_date_row5')) ? $this ->input -> post ('v2_penta_1_date_row5') : Null , 
								'v3_penta_2_date_row5' =>($this ->input -> post ('v3_penta_2_date_row5')) ? $this ->input -> post ('v3_penta_2_date_row5') : Null , 
								'v4_penta_3_date_row5' =>($this ->input -> post ('v4_penta_3_date_row5')) ? $this ->input -> post ('v4_penta_3_date_row5') : Null , 
								'v5_measles1_date_row5' =>($this ->input -> post ('v5_measles1_date_row5')) ? $this ->input -> post ('v5_measles1_date_row5') : Null , 
								'v6_measles2_date_row5' =>($this ->input -> post ('v6_measles2_date_row5')) ? $this ->input -> post ('v6_measles2_date_row5') : Null , 
								'v1_hepa_b_bd_date_row5' =>($this ->input -> post ('v1_hepa_b_bd_date_row5')) ? $this ->input -> post ('v1_hepa_b_bd_date_row5') : Null , 
								'v2_pcv10_1_date_row5' =>($this ->input -> post ('v2_pcv10_1_date_row5')) ? $this ->input -> post ('v2_pcv10_1_date_row5') : Null , 
								'v3_pcv10_2_date_row5' =>($this ->input -> post ('v3_pcv10_2_date_row5')) ? $this ->input -> post ('v3_pcv10_2_date_row5') : Null , 
								'v4_pcv10_3_date_row5' =>($this ->input -> post ('v4_pcv10_3_date_row5')) ? $this ->input -> post ('v4_pcv10_3_date_row5') : Null , 
								'v1_opv_0_date_row5' =>($this ->input -> post ('v1_opv_0_date_row5')) ? $this ->input -> post ('v1_opv_0_date_row5') : Null , 
								'v2_opv_1_date_row5' =>($this ->input -> post ('v2_opv_1_date_row5')) ? $this ->input -> post ('v2_opv_1_date_row5') : Null , 
								'v3_opv_2_date_row5' =>($this ->input -> post ('v3_opv_2_date_row5')) ? $this ->input -> post ('v3_opv_2_date_row5') : Null , 
								'v4_opv_3_date_row5' =>($this ->input -> post ('v4_opv_3_date_row5')) ? $this ->input -> post ('v4_opv_3_date_row5') : Null , 
								'v2_rota_1_date_row5' =>($this ->input -> post ('v2_rota_1_date_row5')) ? $this ->input -> post ('v2_rota_1_date_row5') : Null , 
								'v3_rota_2_date_row5' =>($this ->input -> post ('v3_rota_2_date_row5')) ? $this ->input -> post ('v3_rota_2_date_row5') : Null , 
								'v4_ipv_date_row5' =>($this ->input -> post ('v4_ipv_date_row5')) ? $this ->input -> post ('v4_ipv_date_row5') : Null , 
								'v1_bcg_date_row6' =>($this ->input -> post ('v1_bcg_date_row6')) ? $this ->input -> post ('v1_bcg_date_row6') : Null , 
								'v2_penta_1_date_row6' =>($this ->input -> post ('v2_penta_1_date_row6')) ? $this ->input -> post ('v2_penta_1_date_row6') : Null , 
								'v3_penta_2_date_row6' =>($this ->input -> post ('v3_penta_2_date_row6')) ? $this ->input -> post ('v3_penta_2_date_row6') : Null , 
								'v4_penta_3_date_row6' =>($this ->input -> post ('v4_penta_3_date_row6')) ? $this ->input -> post ('v4_penta_3_date_row6') : Null , 
								'v5_measles1_date_row6' =>($this ->input -> post ('v5_measles1_date_row6')) ? $this ->input -> post ('v5_measles1_date_row6') : Null , 
								'v6_measles2_date_row6' =>($this ->input -> post ('v6_measles2_date_row6')) ? $this ->input -> post ('v6_measles2_date_row6') : Null , 
								'v1_hepa_b_bd_date_row6' =>($this ->input -> post ('v1_hepa_b_bd_date_row6')) ? $this ->input -> post ('v1_hepa_b_bd_date_row6') : Null , 
								'v2_pcv10_1_date_row6' =>($this ->input -> post ('v2_pcv10_1_date_row6')) ? $this ->input -> post ('v2_pcv10_1_date_row6') : Null , 
								'v3_pcv10_2_date_row6' =>($this ->input -> post ('v3_pcv10_2_date_row6')) ? $this ->input -> post ('v3_pcv10_2_date_row6') : Null , 
								'v4_pcv10_3_date_row6' =>($this ->input -> post ('v4_pcv10_3_date_row6')) ? $this ->input -> post ('v4_pcv10_3_date_row6') : Null , 
								'v1_opv_0_date_row6' =>($this ->input -> post ('v1_opv_0_date_row6')) ? $this ->input -> post ('v1_opv_0_date_row6') : Null , 
								'v2_opv_1_date_row6' =>($this ->input -> post ('v2_opv_1_date_row6')) ? $this ->input -> post ('v2_opv_1_date_row6') : Null , 
								'v3_opv_2_date_row6' =>($this ->input -> post ('v3_opv_2_date_row6')) ? $this ->input -> post ('v3_opv_2_date_row6') : Null , 
								'v4_opv_3_date_row6' =>($this ->input -> post ('v4_opv_3_date_row6')) ? $this ->input -> post ('v4_opv_3_date_row6') : Null , 
								'v2_rota_1_date_row6' =>($this ->input -> post ('v2_rota_1_date_row6')) ? $this ->input -> post ('v2_rota_1_date_row6') : Null , 
								'v3_rota_2_date_row6' =>($this ->input -> post ('v3_rota_2_date_row6')) ? $this ->input -> post ('v3_rota_2_date_row6') : Null , 
								'v4_ipv_date_row6' =>($this ->input -> post ('v4_ipv_date_row6')) ? $this ->input -> post ('v4_ipv_date_row6') : Null , 
								'v1_bcg_date_row7' =>($this ->input -> post ('v1_bcg_date_row7')) ? $this ->input -> post ('v1_bcg_date_row7') : Null , 
								'v2_penta_1_date_row7' =>($this ->input -> post ('v2_penta_1_date_row7')) ? $this ->input -> post ('v2_penta_1_date_row7') : Null , 
								'v3_penta_2_date_row7' =>($this ->input -> post ('v3_penta_2_date_row7')) ? $this ->input -> post ('v3_penta_2_date_row7') : Null , 
								'v4_penta_3_date_row7' =>($this ->input -> post ('v4_penta_3_date_row7')) ? $this ->input -> post ('v4_penta_3_date_row7') : Null , 
								'v5_measles1_date_row7' =>($this ->input -> post ('v5_measles1_date_row7')) ? $this ->input -> post ('v5_measles1_date_row7') : Null , 
								'v6_measles2_date_row7' =>($this ->input -> post ('v6_measles2_date_row7')) ? $this ->input -> post ('v6_measles2_date_row7') : Null , 
								'v1_hepa_b_bd_date_row7' =>($this ->input -> post ('v1_hepa_b_bd_date_row7')) ? $this ->input -> post ('v1_hepa_b_bd_date_row7') : Null , 
								'v2_pcv10_1_date_row7' =>($this ->input -> post ('v2_pcv10_1_date_row7')) ? $this ->input -> post ('v2_pcv10_1_date_row7') : Null , 
								'v3_pcv10_2_date_row7' =>($this ->input -> post ('v3_pcv10_2_date_row7')) ? $this ->input -> post ('v3_pcv10_2_date_row7') : Null , 
								'v4_pcv10_3_date_row7' =>($this ->input -> post ('v4_pcv10_3_date_row7')) ? $this ->input -> post ('v4_pcv10_3_date_row7') : Null , 
								'v1_opv_0_date_row7' =>($this ->input -> post ('v1_opv_0_date_row7')) ? $this ->input -> post ('v1_opv_0_date_row7') : Null , 
								'v2_opv_1_date_row7' =>($this ->input -> post ('v2_opv_1_date_row7')) ? $this ->input -> post ('v2_opv_1_date_row7') : Null , 
								'v3_opv_2_date_row7' =>($this ->input -> post ('v3_opv_2_date_row7')) ? $this ->input -> post ('v3_opv_2_date_row7') : Null , 
								'v4_opv_3_date_row7' =>($this ->input -> post ('v4_opv_3_date_row7')) ? $this ->input -> post ('v4_opv_3_date_row7') : Null , 
								'v2_rota_1_date_row7' =>($this ->input -> post ('v2_rota_1_date_row7')) ? $this ->input -> post ('v2_rota_1_date_row7') : Null , 
								'v3_rota_2_date_row7' =>($this ->input -> post ('v3_rota_2_date_row7')) ? $this ->input -> post ('v3_rota_2_date_row7') : Null , 
								'v4_ipv_date_row7' =>($this ->input -> post ('v4_ipv_date_row7')) ? $this ->input -> post ('v4_ipv_date_row7') : Null , 
								'v1_bcg_date_row8' =>($this ->input -> post ('v1_bcg_date_row8')) ? $this ->input -> post ('v1_bcg_date_row8') : Null , 
								'v2_penta_1_date_row8' =>($this ->input -> post ('v2_penta_1_date_row8')) ? $this ->input -> post ('v2_penta_1_date_row8') : Null , 
								'v3_penta_2_date_row8' =>($this ->input -> post ('v3_penta_2_date_row8')) ? $this ->input -> post ('v3_penta_2_date_row8') : Null , 
								'v4_penta_3_date_row8' =>($this ->input -> post ('v4_penta_3_date_row8')) ? $this ->input -> post ('v4_penta_3_date_row8') : Null , 
								'v5_measles1_date_row8' =>($this ->input -> post ('v5_measles1_date_row8')) ? $this ->input -> post ('v5_measles1_date_row8') : Null , 
								'v6_measles2_date_row8' =>($this ->input -> post ('v6_measles2_date_row8')) ? $this ->input -> post ('v6_measles2_date_row8') : Null , 
								'v1_hepa_b_bd_date_row8' =>($this ->input -> post ('v1_hepa_b_bd_date_row8')) ? $this ->input -> post ('v1_hepa_b_bd_date_row8') : Null , 
								'v2_pcv10_1_date_row8' =>($this ->input -> post ('v2_pcv10_1_date_row8')) ? $this ->input -> post ('v2_pcv10_1_date_row8') : Null , 
								'v3_pcv10_2_date_row8' =>($this ->input -> post ('v3_pcv10_2_date_row8')) ? $this ->input -> post ('v3_pcv10_2_date_row8') : Null , 
								'v4_pcv10_3_date_row8' =>($this ->input -> post ('v4_pcv10_3_date_row8')) ? $this ->input -> post ('v4_pcv10_3_date_row8') : Null , 
								'v1_opv_0_date_row8' =>($this ->input -> post ('v1_opv_0_date_row8')) ? $this ->input -> post ('v1_opv_0_date_row8') : Null , 
								'v2_opv_1_date_row8' =>($this ->input -> post ('v2_opv_1_date_row8')) ? $this ->input -> post ('v2_opv_1_date_row8') : Null , 
								'v3_opv_2_date_row8' =>($this ->input -> post ('v3_opv_2_date_row8')) ? $this ->input -> post ('v3_opv_2_date_row8') : Null , 
								'v4_opv_3_date_row8' =>($this ->input -> post ('v4_opv_3_date_row8')) ? $this ->input -> post ('v4_opv_3_date_row8') : Null , 
								'v2_rota_1_date_row8' =>($this ->input -> post ('v2_rota_1_date_row8')) ? $this ->input -> post ('v2_rota_1_date_row8') : Null , 
								'v3_rota_2_date_row8' =>($this ->input -> post ('v3_rota_2_date_row8')) ? $this ->input -> post ('v3_rota_2_date_row8') : Null , 
								'v4_ipv_date_row8' =>($this ->input -> post ('v4_ipv_date_row8')) ? $this ->input -> post ('v4_ipv_date_row8') : Null , 
								'v1_bcg_date_row9' =>($this ->input -> post ('v1_bcg_date_row9')) ? $this ->input -> post ('v1_bcg_date_row9') : Null , 
								'v2_penta_1_date_row9' =>($this ->input -> post ('v2_penta_1_date_row9')) ? $this ->input -> post ('v2_penta_1_date_row9') : Null , 
								'v3_penta_2_date_row9' =>($this ->input -> post ('v3_penta_2_date_row9')) ? $this ->input -> post ('v3_penta_2_date_row9') : Null , 
								'v4_penta_3_date_row9' =>($this ->input -> post ('v4_penta_3_date_row9')) ? $this ->input -> post ('v4_penta_3_date_row9') : Null , 
								'v5_measles1_date_row9' =>($this ->input -> post ('v5_measles1_date_row9')) ? $this ->input -> post ('v5_measles1_date_row9') : Null , 
								'v6_measles2_date_row9' =>($this ->input -> post ('v6_measles2_date_row9')) ? $this ->input -> post ('v6_measles2_date_row9') : Null , 
								'v1_hepa_b_bd_date_row9' =>($this ->input -> post ('v1_hepa_b_bd_date_row9')) ? $this ->input -> post ('v1_hepa_b_bd_date_row9') : Null , 
								'v2_pcv10_1_date_row9' =>($this ->input -> post ('v2_pcv10_1_date_row9')) ? $this ->input -> post ('v2_pcv10_1_date_row9') : Null , 
								'v3_pcv10_2_date_row9' =>($this ->input -> post ('v3_pcv10_2_date_row9')) ? $this ->input -> post ('v3_pcv10_2_date_row9') : Null , 
								'v4_pcv10_3_date_row9' =>($this ->input -> post ('v4_pcv10_3_date_row9')) ? $this ->input -> post ('v4_pcv10_3_date_row9') : Null , 
								'v1_opv_0_date_row9' =>($this ->input -> post ('v1_opv_0_date_row9')) ? $this ->input -> post ('v1_opv_0_date_row9') : Null , 
								'v2_opv_1_date_row9' =>($this ->input -> post ('v2_opv_1_date_row9')) ? $this ->input -> post ('v2_opv_1_date_row9') : Null , 
								'v3_opv_2_date_row9' =>($this ->input -> post ('v3_opv_2_date_row9')) ? $this ->input -> post ('v3_opv_2_date_row9') : Null , 
								'v4_opv_3_date_row9' =>($this ->input -> post ('v4_opv_3_date_row9')) ? $this ->input -> post ('v4_opv_3_date_row9') : Null , 
								'v2_rota_1_date_row9' =>($this ->input -> post ('v2_rota_1_date_row9')) ? $this ->input -> post ('v2_rota_1_date_row9') : Null , 
								'v3_rota_2_date_row9' =>($this ->input -> post ('v3_rota_2_date_row9')) ? $this ->input -> post ('v3_rota_2_date_row9') : Null , 
								'v4_ipv_date_row9' =>($this ->input -> post ('v4_ipv_date_row9')) ? $this ->input -> post ('v4_ipv_date_row9') : Null , 
								'v1_bcg_date_row10' =>($this ->input -> post ('v1_bcg_date_row10')) ? $this ->input -> post ('v1_bcg_date_row10') : Null , 
								'v2_penta_1_date_row10' =>($this ->input -> post ('v2_penta_1_date_row10')) ? $this ->input -> post ('v2_penta_1_date_row10') : Null , 
								'v3_penta_2_date_row10' =>($this ->input -> post ('v3_penta_2_date_row10')) ? $this ->input -> post ('v3_penta_2_date_row10') : Null , 
								'v4_penta_3_date_row10' =>($this ->input -> post ('v4_penta_3_date_row10')) ? $this ->input -> post ('v4_penta_3_date_row10') : Null , 
								'v5_measles1_date_row10' =>($this ->input -> post ('v5_measles1_date_row10')) ? $this ->input -> post ('v5_measles1_date_row10') : Null , 
								'v6_measles2_date_row10' =>($this ->input -> post ('v6_measles2_date_row10')) ? $this ->input -> post ('v6_measles2_date_row10') : Null , 
								'v1_hepa_b_bd_date_row10' =>($this ->input -> post ('v1_hepa_b_bd_date_row10')) ? $this ->input -> post ('v1_hepa_b_bd_date_row10') : Null , 
								'v2_pcv10_1_date_row10' =>($this ->input -> post ('v2_pcv10_1_date_row10')) ? $this ->input -> post ('v2_pcv10_1_date_row10') : Null , 
								'v3_pcv10_2_date_row10' =>($this ->input -> post ('v3_pcv10_2_date_row10')) ? $this ->input -> post ('v3_pcv10_2_date_row10') : Null , 
								'v4_pcv10_3_date_row10' =>($this ->input -> post ('v4_pcv10_3_date_row10')) ? $this ->input -> post ('v4_pcv10_3_date_row10') : Null , 
								'v1_opv_0_date_row10' =>($this ->input -> post ('v1_opv_0_date_row10')) ? $this ->input -> post ('v1_opv_0_date_row10') : Null , 
								'v2_opv_1_date_row10' =>($this ->input -> post ('v2_opv_1_date_row10')) ? $this ->input -> post ('v2_opv_1_date_row10') : Null , 
								'v3_opv_2_date_row10' =>($this ->input -> post ('v3_opv_2_date_row10')) ? $this ->input -> post ('v3_opv_2_date_row10') : Null , 
								'v4_opv_3_date_row10' =>($this ->input -> post ('v4_opv_3_date_row10')) ? $this ->input -> post ('v4_opv_3_date_row10') : Null , 
								'v2_rota_1_date_row10' =>($this ->input -> post ('v2_rota_1_date_row10')) ? $this ->input -> post ('v2_rota_1_date_row10') : Null , 
								'v3_rota_2_date_row10' =>($this ->input -> post ('v3_rota_2_date_row10')) ? $this ->input -> post ('v3_rota_2_date_row10') : Null , 
								'v4_ipv_date_row10' =>($this ->input -> post ('v4_ipv_date_row10')) ? $this ->input -> post ('v4_ipv_date_row10') : Null , 
						);
				
						$data['data'] =$this->micro-> house_hold_cluster_assesment_save_model($cluster_data);
						$location = base_url()."micro_plan/Micro_plan_controller/supervisory_plan_conducted/".$supervisorcode."/".$quarter."/".$year;
						redirect($location);
		}
		public function community_verification_add(){
			$facode = $this -> uri -> segment(4);
			$area_name   = $this -> uri -> segment(5);
		    $quarter   = $this -> uri -> segment(6);
		    $id   = $this -> uri -> segment(7);
			$data['data'] =$this->micro->community_verification_add_model($facode,$area_name,$quarter,$id);
		    $data['fileToLoad'] = 'micro_plan/community_verification_add';
		    $data['pageTitle']='Community verification | EPI-MIS';
			$this->load->view('template/epi_template',$data);
		}		
		
	}
?>