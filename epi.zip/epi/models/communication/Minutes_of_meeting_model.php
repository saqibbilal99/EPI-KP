<?php 
class Minutes_of_meeting_model extends CI_Model {
	public function __construct() {
		parent::__construct();
		$this -> load -> model('Common_model');
	}

	public function minutes_of_meeting_list($per_page, $startpoint) {
		$wc = getWC();//helper function
		$procode = $_SESSION['Province'];
		$distcode = $this -> session -> District;
		if(isset($distcode)){
			$wc = " procode='$procode' AND distcode='$distcode' ";
		}
		else{
			$wc = " procode='$procode' ";
		}
		//$UserLevel = $_SESSION['UserLevel'];
		$query="SELECT distcode, district from districts where procode = '$procode' order by district";
		$resultFac=$this -> db -> query($query);
		$data['resultDist'] = $resultFac -> result_array();
		//print_r($data['resultDist']);exit();
		$query = "SELECT districtname(distcode) AS district, group_id, type_of_minutes, year, quarter, month, remarks FROM minutes_of_meeting_db WHERE $wc ORDER BY year DESC, id DESC LIMIT {$per_page} OFFSET {$startpoint} ";
		$results = $this -> db -> query($query);
		$data['results'] = $results -> result_array();
		//echo '<pre>';print_r($data['results']);exit();
		return $data;
	}

	public function minutes_of_meeting_save_model($minutes_data){
		$this-> Common_model-> insert_record('minutes_of_meeting_db',$minutes_data);
		return TRUE;
	}

	public function minutes_uploaded_files_model($minutes_uploads){
		$this-> Common_model-> insert_record('minutes_uploaded_files_db',$minutes_uploads);
		return TRUE;
	}

	public function delete_by_group_id($group_id){
		$this-> db-> where('group_id', $group_id);
		$this-> db-> delete('minutes_of_meeting_db');

		$this-> db-> where('group_id', $group_id);
		$this-> db-> delete('minutes_uploaded_files_db');
	}

	public function check_minutes_of_meeting($distcode,$type_of_minutes,$year,$quarter,$month){
		if($type_of_minutes=='yearly')
			$wc = " where type_of_minutes='$type_of_minutes' and distcode='$distcode' and year='$year' ";
		if($type_of_minutes=='quarterly')
			$wc = " where type_of_minutes='$type_of_minutes' and distcode='$distcode' and year='$year' and quarter=$quarter ";
		if($type_of_minutes=='monthly')
			$wc = " where type_of_minutes='$type_of_minutes' and distcode='$distcode' and year='$year' and month='$month' ";
		$query = "SELECT distcode, type_of_minutes, year, quarter, month from minutes_of_meeting_db $wc";
		//echo $query; exit();
		$query = $this-> db-> query($query);
		$result = $query->row_array();
		if ($result==true){
			$return = 'yes';
		}
		else{
			$return = 'no';
		}		 
		return $return;
	}

	public function minutes_of_meeting_filter($type_of_minutes, $year){
		$procode = isset($_REQUEST['procode'])?$_REQUEST['procode']:$_SESSION['Province'];
		if($this-> session-> District){
			$distcode = $this-> session-> District;
			$wc = getWC_Array($_SESSION["Province"], $distcode);
		}
		else{
			$wc = getWC_Array($_SESSION["Province"]);
		}
		//Code for Pagination Updated by Nouman
		$page = (int)(!isset($_GET["page"]) ? 1 : $_GET["page"]);
		if ($page <= 0)
			$page = 1;
		$per_page = 20;
		// Set how many records do you want to display per page.
		$startpoint = ($page * $per_page) - $per_page;
		$statement = "minutes_of_meeting_db";

		// if($distcode > 0){
		// 	$wc[] = " distcode = '$distcode' ";
		// }
		if($type_of_minutes != ""){
			$wc[] = " type_of_minutes = '$type_of_minutes' ";
		}
				
		if($year != ""){
			$wc[] = " year = '$year' ";
		}
		//print_r($wc);exit();
		// Change `records` according to your table name.
		//echo		
		$query="SELECT districtname(distcode) AS district, group_id, type_of_minutes, year, quarter, month, remarks FROM minutes_of_meeting_db " . (empty($wc) ? '' : ' WHERE ' . implode(" AND ", $wc)) . " ORDER BY year DESC, id DESC LIMIT {$per_page} OFFSET {$startpoint}";
		//exit();
		$result = $this -> db -> query($query);
		$result = $result -> result_array();
		$i = $startpoint;
		$resultJson = array();
		$tbody = '';
		foreach ($result as $row) {
			$i++;
			//$link = (isset($row['group_id']) && $row['group_id'] != '')?$row['group_id']: '';
			if($row['type_of_minutes']=='yearly'){
                $row['type_of_minutes'] = 'District Committee Notified';
            }
            if($row['type_of_minutes']=='quarterly'){
                $row['type_of_minutes'] = 'District Plan Available';
            }
            if($row['type_of_minutes']=='monthly'){
                $row['type_of_minutes'] = 'District Committee Functional';
            }
			if($row['quarter']>0)
               $row['quarter'] = 'Q'.$row['quarter'];
            else
                $row['quarter'] = '';
			$tbody .= '<tr id="row_'.$row['type_of_minutes'].'" class="DrilledDown">
							<td class="text-center">'.$i.'</td>
							<td class="text-center">'.$row['district'].'</td>
							<td class="text-left">'.$row['type_of_minutes'].'</td>
							<td class="text-center">'.$row['year'].'</td>
							<td class="text-center">'.$row['quarter'].'</td>
							<td class="text-center">'.monthname($row['month']).'</td>
							<td class="text-center">
								<a href="'.base_url().'communication/Minutes_of_meeting/minutes_of_meeting_view?group_id='.$row['group_id'].'" data-toggle="tooltip" title="Edit" class="btn btn-xs btn-default"><i class="fa fa-search"></i></a>
								<a data-original-title="Delete" href="javascript:void(0);" onclick="javascript:del_user(\''.$row['group_id'].'\');" data-toggle="tooltip" title="" class="btn btn-xs btn-danger" ><i class="fa fa-times"></i></a>
						  	</td>
		    			</tr>';
		}
		$resultJson["tbody"] = $tbody;
		$wc = implode(" AND ", $wc);
		//print_r($wc);exit();
		//$wc = getWC();
		$resultJson["paging"] = $this-> Common_model-> pagination($statement,$per_page,$page,$url = "?",$wc);
		return json_encode($resultJson,true);
	}
}
?>
