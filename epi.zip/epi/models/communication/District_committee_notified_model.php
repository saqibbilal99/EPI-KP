<?php
class District_committee_notified_model extends CI_Model {
	public function __construct() {
		parent::__construct();
		$this -> load -> model('Filter_model');
		$this -> load -> helper('epi_reports_helper');
		$this -> load -> helper('indicator_functions_helper');
		$this -> load -> model('Common_model');
	}
	
	//======= Function to Create Filters for Sepecific Reports Starts Here ===========//
	public function Create_Reporting_Filters($reportName) {
		$data = posted_Values();
		$wc	  = getWC_Array($data['procode'],$this -> session -> District,$data['tcode']);
		$newWC= WC_replacement($wc);
		//print_r($newWC); exit;				  
		$neWc = $newWC[0];
		$neWc1 = $newWC[1];
		$UserLevel = $this -> session -> UserLevel;
		if($UserLevel==4){
			unset($neWc1[2]);
		}
		$Caption = "Report";
		$subTitle = "District Report";
		$datArray = NULL;
		//$datArray['years'] = "";
		$datArray['yearsforminutes']= "";
		$link="District_committee_notified";
		if ($reportName == 'notified') {
			$Caption = "District Committee Notified Compliance";			
			// $datArray['month-from-to'] = "";
			//$datArray['years']= "";
			$datArray['yearsforminutes']= "";
		}
		
		//echo "<pre>"; print_r($datArray); exit;			 
		$datArray['listing_filters'] = $this -> Filter_model -> createListingFilter($datArray, $datArray, base_url() .$link.'/' . str_replace(" ", "_", $reportName) , $UserLevel, $Caption);
		//echo "<pre>"; print_r($datArray); exit;					 
		return $datArray;
	}	
	//------------------------------------------------------------------------------------------------//

	public function district_committee_notified($year){
		$procode = $_SESSION['Province'];
		$distcode = $this-> session-> District;
		if($this -> input -> post('export_excel'))
		{
			//if request is from excel
			header("Content-type: application/octet-stream");
			header("Content-Disposition: attachment; filename=".str_replace(" ","_",$subTitle).".xls");
			header("Pragma: no-cache");
			header("Expires: 0");
			//Excel Ending here
		}

		if(isset($distcode)){
			$query = "SELECT a.distcode, a.district, b.group_id from districts as a left outer join (SELECT distinct distcode, group_id from minutes_of_meeting_db where type_of_minutes='yearly' and year='$year' group by distcode, group_id) as b on a.distcode=b.distcode where a.procode='$procode' and a.distcode='$distcode' order by district ";
		}
		else{
			$query = "SELECT a.distcode, a.district, b.group_id from districts as a left outer join (SELECT distinct distcode, group_id from minutes_of_meeting_db where type_of_minutes='yearly' and year='$year' group by distcode, group_id) as b on a.distcode=b.distcode where a.procode='$procode' order by district ";
		}

		$minutes_result = $this -> db -> query($query);
		$data['minutes_result'] = $minutes_result -> result_array();
		$data['year'] = $year;
		$subTitle = "District Committee Notified Compliance Report";		
		$data['subtitle'] = $subTitle;
		$data['TopInfo'] = tableTopInfo($subTitle, '', '', $data['year']);
		return $data;
	}
}
?>
