<?php
class Dashboard_model extends CI_Controller {
	
}