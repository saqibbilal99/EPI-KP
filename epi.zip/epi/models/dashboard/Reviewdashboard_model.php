<?php
class Reviewdashboard_model extends CI_Model {

	
}
?>