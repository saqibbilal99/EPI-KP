<?php
class Coverage_ucwise_model extends CI_Model {
	//================ Constructor function Starts Here ==================//
	public function __construct() {
		parent::__construct();
		//$this -> load -> helper('my_functions_helper');
		$this -> load -> model('Filter_model');
		$this -> load -> helper('epi_reports_helper');
		$this -> load -> helper('indicator_functions_helper');
		$this -> load -> model('Common_model');
	}
	//====================== Constructor Function Ends Here ==========================//
	//--------------------------------------------------------------------------------//
	//======= Function to Create Filters for Sepecific Reports Starts Here ===========//
	public function vaccination_malefemale_coverage_uc_wise($code=NULL,$year=NULL,$data=NULL)
	{
		//print_r($_REQUEST);exit();
		//print_r($data); exit(); 
		if($this -> session -> federaluser == true){
			$fedDrilldown = $this -> session -> federaluser;
		}
		$start_year = substr($data['monthfrom'],0,4);
		$start_month = substr($data['monthfrom'],5,2);
		$end_year = substr($data['monthto'],0,4);
		$end_month = substr($data['monthto'],5,2);
		$in_out_coverage = $this-> input-> get_post('in_out_coverage');
		if(!isset($data["distcode"])){
			$data["distcode"] = ($this-> input-> get_post("distcode"))?$this->input-> get_post("distcode"):$this->session->District;
		}
		$data['procode'] = $_SESSION["Province"];
		$wc	  = getWC_Array($data['procode'],$data['distcode']); // function to get wc array
		$distcode=$data['distcode'];
		$whereFmonth = " fmonth BETWEEN '" . $data['monthfrom'] . "' AND '" . $data['monthto'] . "'";
		$criNames   = array(
			"BCG","HEP","OPV_O",
			"OPV_ON","OPV_TW","OPV_TH",
			"PEN_O","PEN_TW","PEN_TH",
			"PC_O","PC_TW","PC_TH",
			"IP_O","ROTA_ON","ROTA_TW",
			"MEA_O","FULLY_IMMUNIZED","MEA_TW","DTP_O","TCV_O","IP_TW"
		);
		$ttNames1 	= array("Total_TTPL1","Total_TTPL2","Total_TTPL3","Total_TTPL4","Total_TTPL5");
		$ttNames2 	= array("Total_TTNonPL1","Total_TTNonPL2","Total_TTNonPL3","Total_TTNonPL4","Total_TTNonPL5");
		if((isset($data['distcode']) && $data['distcode'] > 0) || (isset($data['tcode']) && $data['tcode'] > 0))
		{	
			if($data['typeWise']=='uc')
			{
				if($data["monthfrom"] && $data['monthto'])
				{
					$subTitle = 'Union Council-wise Monthly Vaccination of Children and Women(with Percentage)';
					$fmonthCondition = " and fmonth >= '".$data['monthfrom']."' and fmonth <= '".$data['monthto']."'";
					$monthly_ou_fmonthCondition = " and monthly_outuc_coverage.fmonth >= '".$data['monthfrom']."' and monthly_outuc_coverage.fmonth <= '".$data['monthto']."'";
					$tmp_new_borns_male = "round((getmonthlytarget_specificyearr(flcf1.uncode::text,$start_year,$start_month,$end_year,$end_month)::numeric*51)/100) as \"New Borns Male\",";
					$tmp_new_borns_female = "round((getmonthlytarget_specificyearr(flcf1.uncode::text,$start_year,$start_month,$end_year,$end_month)::numeric*49)/100) as \"New Borns FeMale\",";
					$tmp_new_borns_total = "round((getmonthlytarget_specificyearr(flcf1.uncode::text,$start_year,$start_month,$end_year,$end_month)::numeric*100)/100) as \"Total New Borns\",";
					$tmp_target_male_child = "round(((getmonthlytarget_specificyearrsurvivinginfants(flcf1.uncode::text,'unioncouncil'::text,$start_year,$start_month,$end_year,$end_month)::numeric)*51)/100) as \"Targeted_Male_Children\",";
					$tmp_target_female_child = "round(((getmonthlytarget_specificyearrsurvivinginfants(flcf1.uncode::text,'unioncouncil'::text,$start_year,$start_month,$end_year,$end_month)::numeric)*49)/100) as \"Targeted_Female_Children\",";
					$tmp_target_total_child = "round(((getmonthlytarget_specificyearrsurvivinginfants(flcf1.uncode::text,'unioncouncil'::text,$start_year,$start_month,$end_year,$end_month)::numeric)*100)/100) as \"Total_Targeted_Children\",";
					$tmp_target_woman = "round((getmonthly_plwomen_target_specificyears(flcf1.uncode::text,$start_year,$start_month,$end_year,$end_month)::numeric)) as \"Targeted_Women\",";
					$newbornMale = "COALESCE( NULLIF(round(round((getmonthlytarget_specificyearr(flcf1.uncode::text,$start_year,$start_month,$end_year,$end_month)::numeric*51)/100,0)),0) , 0 )";
					$newbornFemale = "COALESCE( NULLIF(round(round((getmonthlytarget_specificyearr(flcf1.uncode::text,$start_year,$start_month,$end_year,$end_month)::numeric*49)/100,0)),0) , 0 )";
					$targetMaleChildren = "COALESCE( NULLIF(((getmonthlytarget_specificyearrsurvivinginfants(flcf1.uncode::text,'unioncouncil'::text,$start_year,$start_month,$end_year,$end_month)::numeric)*51)/100,0) , 0 )";
					$targetFeMaleChildren = "COALESCE( NULLIF(((getmonthlytarget_specificyearrsurvivinginfants(flcf1.uncode::text,'unioncouncil'::text,$start_year,$start_month,$end_year,$end_month)::numeric)*49)/100,0) , 0 )";
					$targetWomen = "COALESCE( NULLIF(round((getmonthly_plwomen_target_specificyears(flcf1.uncode::text,$start_year,$start_month,$end_year,$end_month)::numeric),2),0) , 0 )";
				}
			}
		}
		$vacc_to = $this-> input-> get_post('vacc_to');
		$age_wise = $this-> input-> get_post('age_wise');
		
		if($vacc_to == 'total_children')
		{	
			$tmp = "$tmp_new_borns_total $tmp_target_total_child $tmp_target_woman";
		}
		elseif($vacc_to == 'gender')
		{
			$tmp = "$tmp_new_borns_male $tmp_new_borns_female $tmp_target_male_child $tmp_target_female_child $tmp_target_woman";
		}
		if((isset($data['distcode']) && $data['distcode'] > 0) || (isset($data['tcode']) && $data['tcode'] > 0))
		{
			if($data['typeWise']=='uc')
			{	//echo "uc"; exit();
				if($in_out_coverage == 'out_uc'){
					$queryForYearlyData="SELECT flcf1.uncode, unname(flcf1.uncode), $tmp ";					
				}
				else{
					$queryForYearlyData="SELECT flcf1.uncode, unname(flcf1.uncode), $tmp ";
				}
				for($i=1;$i<=sizeof($criNames);$i++)
				{
					$asValueCRI=$criNames[$i-1];
					switch ($age_wise) 
					{
						case 'all':
						
							if($in_out_coverage == 'in_uc'){
								if($start_year >= 2021){
									if($i=='17'){
										$m_cols_in = "sum(cri_r25_f17)";
										$m_cols_out="sum(oui_r25_f17)";
										$m_cols = "$m_cols_in + $m_cols_out";
										$f_cols_in = "sum(cri_r26_f17)";
										$f_cols_out="sum(oui_r26_f17)";
										$f_cols = "$f_cols_in + $f_cols_out";
									}else if($i=='19'){
										$m_cols_in = "sum(cri_r25_f19)";
										$m_cols_out="sum(oui_r25_f19)";
										$m_cols = "$m_cols_in + $m_cols_out";
										$f_cols_in = "sum(cri_r26_f19)";
										$f_cols_out="sum(oui_r26_f19)";
										$f_cols = "$f_cols_in + $f_cols_out";
									}else{
										$m_cols_in = "sum(cri_r1_f".$i.")+sum(cri_r3_f".$i.")+sum(cri_r5_f".$i.")+sum(cri_r7_f".$i.")+sum(cri_r9_f".$i.")+sum(cri_r11_f".$i.")+sum(cri_r13_f".$i.")+sum(cri_r15_f".$i.")+sum(cri_r17_f".$i.")+sum(cri_r19_f".$i.")+sum(cri_r21_f".$i.")+sum(cri_r23_f".$i.")";
										$m_cols = "$m_cols_in";
										$f_cols_in = "sum(cri_r2_f".$i.")+sum(cri_r4_f".$i.")+sum(cri_r6_f".$i.")+sum(cri_r8_f".$i.")+sum(cri_r10_f".$i.")+sum(cri_r12_f".$i.")+sum(cri_r14_f".$i.")+sum(cri_r16_f".$i.")+sum(cri_r18_f".$i.")+sum(cri_r20_f".$i.")+sum(cri_r22_f".$i.")+sum(cri_r24_f".$i.")";
										$f_cols = "$f_cols_in";
									}
									//other uc
									$ou_mcols ="sum(fm1)+sum(fm2)+sum(fm3)+sum(om1)+sum(om2)+sum(om3)+sum(mm1)+sum(mm2)+sum(mm3)+sum(hm1)+sum(hm2)+sum(hm3)";
									$ou_fcols = "sum(ff1)+sum(ff2)+sum(ff3)+sum(of1)+sum(of2) +sum(of3)+sum(mf1)+sum(mf2)+sum(mf3)+sum(hf1)+sum(hf2)+sum(hf3)";
								}else{
									if($i=='17'){
										$m_cols_in = "sum(cri_r25_f17)";
										$m_cols_out="sum(oui_r25_f17)";
										$m_cols = "$m_cols_in + $m_cols_out";
										$f_cols_in = "sum(cri_r26_f17)";
										$f_cols_out="sum(oui_r26_f17)";
										$f_cols = "$f_cols_in + $f_cols_out";
									}else if($i=='19'){
										$m_cols_in = "sum(cri_r25_f19)";
										$m_cols_out="sum(oui_r25_f19)";
										$m_cols = "$m_cols_in + $m_cols_out";
										$f_cols_in = "sum(cri_r26_f19)";
										$f_cols_out="sum(oui_r26_f19)";
										$f_cols = "$f_cols_in + $f_cols_out";
									}else{	
										$m_cols_in = "sum(cri_r1_f".$i.")+sum(cri_r3_f".$i.")+sum(cri_r5_f".$i.")+sum(cri_r7_f".$i.")+sum(cri_r9_f".$i.")+sum(cri_r11_f".$i.")+sum(cri_r13_f".$i.")+sum(cri_r15_f".$i.")+sum(cri_r17_f".$i.")+sum(cri_r19_f".$i.")+sum(cri_r21_f".$i.")+sum(cri_r23_f".$i.")";
										$m_cols_out = "sum(oui_r1_f".$i.")+sum(oui_r3_f".$i.")+sum(oui_r5_f".$i.")+sum(oui_r7_f".$i.")+sum(oui_r9_f".$i.")+sum(oui_r11_f".$i.")+sum(oui_r13_f".$i.")+sum(oui_r15_f".$i.")+sum(oui_r17_f".$i.")+sum(oui_r19_f".$i.")+sum(oui_r21_f".$i.")+sum(oui_r23_f".$i.")";
										$m_cols = "$m_cols_in + $m_cols_out";

										$f_cols_in = "sum(cri_r2_f".$i.")+sum(cri_r4_f".$i.")+sum(cri_r6_f".$i.")+sum(cri_r8_f".$i.")+sum(cri_r10_f".$i.")+sum(cri_r12_f".$i.")+sum(cri_r14_f".$i.")+sum(cri_r16_f".$i.")+sum(cri_r18_f".$i.")+sum(cri_r20_f".$i.")+sum(cri_r22_f".$i.")+sum(cri_r24_f".$i.")";
										$f_cols_out = "sum(oui_r2_f".$i.")+sum(oui_r4_f".$i.")+sum(oui_r6_f".$i.")+sum(oui_r8_f".$i.")+sum(oui_r10_f".$i.")+sum(oui_r12_f".$i.")+sum(oui_r14_f".$i.")+sum(oui_r16_f".$i.")+sum(oui_r18_f".$i.")+sum(oui_r20_f".$i.")+sum(oui_r22_f".$i.")+sum(oui_r24_f".$i.")";
										$f_cols = "$f_cols_in + $f_cols_out";
									}
								}
							}
							if($in_out_coverage == 'out_uc'){
								//echo "b";exit();
								if($i=='17'){
									$m_cols = "sum(oui_r25_f17)";
									$f_cols = "sum(oui_r26_f17)";
								}else if($i=='19'){
									$m_cols = "sum(oui_r25_f19)";
									$f_cols = "sum(oui_r26_f19)";
								}else{
									$m_cols = "sum(oui_r1_f".$i.")+sum(oui_r3_f".$i.")+sum(oui_r5_f".$i.")+sum(oui_r7_f".$i.")+sum(oui_r9_f".$i.")+sum(oui_r11_f".$i.")+sum(oui_r13_f".$i.")+sum(oui_r15_f".$i.")+sum(oui_r17_f".$i.")+sum(oui_r19_f".$i.")+sum(oui_r21_f".$i.")+sum(oui_r23_f".$i.")";
									$f_cols = "sum(oui_r2_f".$i.")+sum(oui_r4_f".$i.")+sum(oui_r6_f".$i.")+sum(oui_r8_f".$i.")+sum(oui_r10_f".$i.")+sum(oui_r12_f".$i.")+sum(oui_r14_f".$i.")+sum(oui_r16_f".$i.")+sum(oui_r18_f".$i.")+sum(oui_r20_f".$i.")+sum(oui_r22_f".$i.")+sum(oui_r24_f".$i.")";
								}
							}
							if($in_out_coverage == 'in_district'){
								//echo "c";exit();
								if($start_year >= 2021){
									if($i=='17'){
										$m_cols_in = "sum(cri_r25_f17)";
										$m_cols_out="sum(oui_r25_f17)";
										$m_cols = "$m_cols_in + $m_cols_out";
										$f_cols_in = "sum(cri_r26_f17)";
										$f_cols_out="sum(oui_r26_f17)";
										$f_cols = "$f_cols_in + $f_cols_out";
									}else if($i=='19'){
										$m_cols_in = "sum(cri_r25_f19)";
										$m_cols_out="sum(oui_r25_f19)";
										$m_cols = "$m_cols_in + $m_cols_out";
										$f_cols_in = "sum(cri_r26_f19)";
										$f_cols_out="sum(oui_r26_f19)";
										$f_cols = "$f_cols_in + $f_cols_out";
									}else{
										$m_cols_in = "sum(cri_r1_f".$i.")+sum(cri_r3_f".$i.")+sum(cri_r5_f".$i.")+sum(cri_r7_f".$i.")+sum(cri_r9_f".$i.")+sum(cri_r11_f".$i.")+sum(cri_r13_f".$i.")+sum(cri_r15_f".$i.")+sum(cri_r17_f".$i.")+sum(cri_r19_f".$i.")+sum(cri_r21_f".$i.")+sum(cri_r23_f".$i.")";
										//$m_cols_out = "sum(oui_r1_f".$i.")+sum(oui_r3_f".$i.")+sum(oui_r5_f".$i.")+sum(oui_r7_f".$i.")+sum(oui_r9_f".$i.")+sum(oui_r11_f".$i.")+sum(oui_r13_f".$i.")+sum(oui_r15_f".$i.")+sum(oui_r17_f".$i.")+sum(oui_r19_f".$i.")+sum(oui_r21_f".$i.")+sum(oui_r23_f".$i.")";
										//$m_cols = "$m_cols_in + $m_cols_out";
										$m_cols = "$m_cols_in";

										$f_cols_in = "sum(cri_r2_f".$i.")+sum(cri_r4_f".$i.")+sum(cri_r6_f".$i.")+sum(cri_r8_f".$i.")+sum(cri_r10_f".$i.")+sum(cri_r12_f".$i.")+sum(cri_r14_f".$i.")+sum(cri_r16_f".$i.")+sum(cri_r18_f".$i.")+sum(cri_r20_f".$i.")+sum(cri_r22_f".$i.")+sum(cri_r24_f".$i.")";
										//$f_cols_out = "sum(oui_r2_f".$i.")+sum(oui_r4_f".$i.")+sum(oui_r6_f".$i.")+sum(oui_r8_f".$i.")+sum(oui_r10_f".$i.")+sum(oui_r12_f".$i.")+sum(oui_r14_f".$i.")+sum(oui_r16_f".$i.")+sum(oui_r18_f".$i.")+sum(oui_r20_f".$i.")+sum(oui_r22_f".$i.")+sum(oui_r24_f".$i.")";
										//$f_cols = "$f_cols_in + $f_cols_out";
										$f_cols = "$f_cols_in";
									}
									
									//other uc
									$ou_mcols ="sum(fm1)+sum(fm2)+sum(fm3)+sum(om1)+sum(om2)+sum(om3)+sum(mm1)+sum(mm2)+sum(mm3)+sum(hm1)+sum(hm2)+sum(hm3)";
									$ou_fcols = "sum(ff1)+sum(ff2)+sum(ff3)+sum(of1)+sum(of2) +sum(of3)+sum(mf1)+sum(mf2)+sum(mf3)+sum(hf1)+sum(hf2)+sum(hf3)";
								}else{
									if($i=='17'){
										$m_cols_in = "sum(cri_r25_f17)";
										$m_cols_out="sum(oui_r25_f17)";
										$m_cols = "$m_cols_in + $m_cols_out";
										$f_cols_in = "sum(cri_r26_f17)";
										$f_cols_out="sum(oui_r26_f17)";
										$f_cols = "$f_cols_in + $f_cols_out";
									}else if($i=='19'){
										$m_cols_in = "sum(cri_r25_f19)";
										$m_cols_out="sum(oui_r25_f19)";
										$m_cols = "$m_cols_in + $m_cols_out";
										$f_cols_in = "sum(cri_r26_f19)";
										$f_cols_out="sum(oui_r26_f19)";
										$f_cols = "$f_cols_in + $f_cols_out";
									}else{
										$m_cols_in = "sum(cri_r1_f".$i.")+sum(cri_r3_f".$i.")+sum(cri_r5_f".$i.")+sum(cri_r7_f".$i.")+sum(cri_r9_f".$i.")+sum(cri_r11_f".$i.")+sum(cri_r13_f".$i.")+sum(cri_r15_f".$i.")+sum(cri_r17_f".$i.")+sum(cri_r19_f".$i.")+sum(cri_r21_f".$i.")+sum(cri_r23_f".$i.")";
										$m_cols_out = "sum(oui_r1_f".$i.")+sum(oui_r3_f".$i.")+sum(oui_r5_f".$i.")+sum(oui_r7_f".$i.")+sum(oui_r9_f".$i.")+sum(oui_r11_f".$i.")+sum(oui_r13_f".$i.")+sum(oui_r15_f".$i.")+sum(oui_r17_f".$i.")+sum(oui_r19_f".$i.")+sum(oui_r21_f".$i.")+sum(oui_r23_f".$i.")";
										$m_cols = "$m_cols_in + $m_cols_out";

										$f_cols_in = "sum(cri_r2_f".$i.")+sum(cri_r4_f".$i.")+sum(cri_r6_f".$i.")+sum(cri_r8_f".$i.")+sum(cri_r10_f".$i.")+sum(cri_r12_f".$i.")+sum(cri_r14_f".$i.")+sum(cri_r16_f".$i.")+sum(cri_r18_f".$i.")+sum(cri_r20_f".$i.")+sum(cri_r22_f".$i.")+sum(cri_r24_f".$i.")";
										$f_cols_out = "sum(oui_r2_f".$i.")+sum(oui_r4_f".$i.")+sum(oui_r6_f".$i.")+sum(oui_r8_f".$i.")+sum(oui_r10_f".$i.")+sum(oui_r12_f".$i.")+sum(oui_r14_f".$i.")+sum(oui_r16_f".$i.")+sum(oui_r18_f".$i.")+sum(oui_r20_f".$i.")+sum(oui_r22_f".$i.")+sum(oui_r24_f".$i.")";
										$f_cols = "$f_cols_in + $f_cols_out";
									}
								}
							}
							if($in_out_coverage == 'total_ucs'){
								//echo "c";exit();
								if($i=='17'){
									$m_cols_in = "sum(cri_r25_f17)";
									$m_cols_out="sum(oui_r25_f17)";
									$m_cols = "$m_cols_in + $m_cols_out";
									$f_cols_in = "sum(cri_r26_f17)";
									$f_cols_out="sum(oui_r26_f17)";
									$f_cols = "$f_cols_in + $f_cols_out";
								}else if($i=='19'){
									$m_cols_in = "sum(cri_r25_f19)";
									$m_cols_out="sum(oui_r25_f19)";
									$m_cols = "$m_cols_in + $m_cols_out";
									$f_cols_in = "sum(cri_r26_f19)";
									$f_cols_out="sum(oui_r26_f19)";
									$f_cols = "$f_cols_in + $f_cols_out";
								}else{
									$m_cols_in = "sum(cri_r1_f".$i.")+sum(cri_r3_f".$i.")+sum(cri_r5_f".$i.")+sum(cri_r7_f".$i.")+sum(cri_r9_f".$i.")+sum(cri_r11_f".$i.")+sum(cri_r13_f".$i.")+sum(cri_r15_f".$i.")+sum(cri_r17_f".$i.")+sum(cri_r19_f".$i.")+sum(cri_r21_f".$i.")+sum(cri_r23_f".$i.")";
									//$m_cols_out = "sum(oui_r1_f".$i.")+sum(oui_r3_f".$i.")+sum(oui_r5_f".$i.")+sum(oui_r7_f".$i.")+sum(oui_r9_f".$i.")+sum(oui_r11_f".$i.")+sum(oui_r13_f".$i.")+sum(oui_r15_f".$i.")+sum(oui_r17_f".$i.")+sum(oui_r19_f".$i.")+sum(oui_r21_f".$i.")+sum(oui_r23_f".$i.")";
									//$m_cols = "$m_cols_in + $m_cols_out";
									$m_cols = "$m_cols_in";

									$f_cols_in = "sum(cri_r2_f".$i.")+sum(cri_r4_f".$i.")+sum(cri_r6_f".$i.")+sum(cri_r8_f".$i.")+sum(cri_r10_f".$i.")+sum(cri_r12_f".$i.")+sum(cri_r14_f".$i.")+sum(cri_r16_f".$i.")+sum(cri_r18_f".$i.")+sum(cri_r20_f".$i.")+sum(cri_r22_f".$i.")+sum(cri_r24_f".$i.")";
									/* $f_cols_out = "sum(oui_r2_f".$i.")+sum(oui_r4_f".$i.")+sum(oui_r6_f".$i.")+sum(oui_r8_f".$i.")+sum(oui_r10_f".$i.")+sum(oui_r12_f".$i.")+sum(oui_r14_f".$i.")+sum(oui_r16_f".$i.")+sum(oui_r18_f".$i.")+sum(oui_r20_f".$i.")+sum(oui_r22_f".$i.")+sum(oui_r24_f".$i.")";
									$f_cols = "$f_cols_in + $f_cols_out"; */
									$f_cols = "$f_cols_in";
								}
								
							}
							$t_cols = "$m_cols + $f_cols";
							//other uc
							if($in_out_coverage == 'in_uc' || $in_out_coverage == 'in_district'){
								if($start_year >= 2021){
									$ou_tcols = "$ou_mcols + $ou_fcols";
								}else{
									$ou_tcols = "";
								}
							}	
							$show_pl_cba = TRUE;
							break;
						case '0to11':
							if($in_out_coverage == 'in_uc'){
								if($start_year >= 2021){
									if($i=='17'){
										$m_cols_in = "sum(cri_r25_f17)";
										$m_cols_out="sum(oui_r25_f17)";
										$m_cols = "$m_cols_in + $m_cols_out";
										$f_cols_in = "sum(cri_r26_f17)";
										$f_cols_out="sum(oui_r26_f17)";
										$f_cols = "$f_cols_in + $f_cols_out";
									}else if($i=='19'){
										$m_cols_in = "sum(cri_r25_f19)";
										$m_cols_out="sum(oui_r25_f19)";
										$m_cols = "$m_cols_in + $m_cols_out";
										$f_cols_in = "sum(cri_r26_f19)";
										$f_cols_out="sum(oui_r26_f19)";
										$f_cols = "$f_cols_in + $f_cols_out";
									}else{
										$m_cols_in = "sum(cri_r1_f".$i." + cri_r7_f".$i." + cri_r13_f".$i." + cri_r19_f".$i.")";
										$m_cols = "$m_cols_in";

										$f_cols_in = "sum(cri_r2_f".$i." + cri_r8_f".$i." + cri_r14_f".$i." + cri_r20_f".$i.")";
										$f_cols = "$f_cols_in";
									}
									//other uc
									$ou_mcols = "sum(fm1)+sum(om1)+sum(mm1)+sum(hm1)";
									$ou_fcols = "sum(ff1)+sum(of1)+sum(mf1)+sum(hf1)";
								}else{
									if($i=='17'){
										$m_cols_in = "sum(cri_r25_f17)";
										$m_cols_out="sum(oui_r25_f17)";
										$m_cols = "$m_cols_in + $m_cols_out";
										$f_cols_in = "sum(cri_r26_f17)";
										$f_cols_out="sum(oui_r26_f17)";
										$f_cols = "$f_cols_in + $f_cols_out";
									}else if($i=='19'){
										$m_cols_in = "sum(cri_r25_f19)";
										$m_cols_out="sum(oui_r25_f19)";
										$m_cols = "$m_cols_in + $m_cols_out";
										$f_cols_in = "sum(cri_r26_f19)";
										$f_cols_out="sum(oui_r26_f19)";
										$f_cols = "$f_cols_in + $f_cols_out";
									}else{
										$m_cols_in = "sum(cri_r1_f".$i." + cri_r7_f".$i." + cri_r13_f".$i." + cri_r19_f".$i.")";
										$m_cols_out = "sum(oui_r1_f".$i." + oui_r7_f".$i." + oui_r13_f".$i." + oui_r19_f".$i.")";
										$m_cols = "$m_cols_in + $m_cols_out";

										$f_cols_in = "sum(cri_r2_f".$i." + cri_r8_f".$i." + cri_r14_f".$i." + cri_r20_f".$i.")";
										$f_cols_out = "sum(oui_r2_f".$i." + oui_r8_f".$i." + oui_r14_f".$i." + oui_r20_f".$i.")";
										$f_cols = "$f_cols_in + $f_cols_out";
									}
								}
							}
							if($in_out_coverage == 'out_uc'){
								if($i=='17'){
									$m_cols = "sum(oui_r25_f17)";
									$f_cols = "sum(oui_r26_f17)";
								}else if($i=='19'){
									$m_cols = "sum(oui_r25_f19)";
									$f_cols = "sum(oui_r26_f19)";
								}else{
									$m_cols = "sum(oui_r1_f".$i." + oui_r7_f".$i." + oui_r13_f".$i." + oui_r19_f".$i.")";
									$f_cols = "sum(oui_r2_f".$i." + oui_r8_f".$i." + oui_r14_f".$i." + oui_r20_f".$i.")";
								}
							}
							if($in_out_coverage == 'in_district'){
								if($start_year >= 2021){
									if($i=='17'){
										$m_cols_in = "sum(cri_r25_f17)";
										$m_cols_out="sum(oui_r25_f17)";
										$m_cols = "$m_cols_in + $m_cols_out";
										$f_cols_in = "sum(cri_r26_f17)";
										$f_cols_out="sum(oui_r26_f17)";
										$f_cols = "$f_cols_in + $f_cols_out";
									}else if($i=='19'){
										$m_cols_in = "sum(cri_r25_f19)";
										$m_cols_out="sum(oui_r25_f19)";
										$m_cols = "$m_cols_in + $m_cols_out";
										$f_cols_in = "sum(cri_r26_f19)";
										$f_cols_out="sum(oui_r26_f19)";
										$f_cols = "$f_cols_in + $f_cols_out";
									}else{
										$m_cols_in = "sum(cri_r1_f".$i." + cri_r7_f".$i." + cri_r13_f".$i." + cri_r19_f".$i.")";
										//$m_cols_out = "sum(oui_r1_f".$i." + oui_r7_f".$i." + oui_r13_f".$i." + oui_r19_f".$i.")";
										//$m_cols = "$m_cols_in + $m_cols_out";
										$m_cols = "$m_cols_in";

										$f_cols_in = "sum(cri_r2_f".$i." + cri_r8_f".$i." + cri_r14_f".$i." + cri_r20_f".$i.")";
										//$f_cols_out = "sum(oui_r2_f".$i." + oui_r8_f".$i." + oui_r14_f".$i." + oui_r20_f".$i.")";
										//$f_cols = "$f_cols_in + $f_cols_out";
										$f_cols = "$f_cols_in";
									}
									//other uc
									$ou_mcols = "sum(fm1)+sum(om1)+sum(mm1)+sum(hm1)";
									$ou_fcols = "sum(ff1)+sum(of1)+sum(mf1)+sum(hf1)";
								}else{
									if($i=='17'){
										$m_cols_in = "sum(cri_r25_f17)";
										$m_cols_out="sum(oui_r25_f17)";
										$m_cols = "$m_cols_in + $m_cols_out";
										$f_cols_in = "sum(cri_r26_f17)";
										$f_cols_out="sum(oui_r26_f17)";
										$f_cols = "$f_cols_in + $f_cols_out";
									}else if($i=='19'){
										$m_cols_in = "sum(cri_r25_f19)";
										$m_cols_out="sum(oui_r25_f19)";
										$m_cols = "$m_cols_in + $m_cols_out";
										$f_cols_in = "sum(cri_r26_f19)";
										$f_cols_out="sum(oui_r26_f19)";
										$f_cols = "$f_cols_in + $f_cols_out";
									}else{
										$m_cols_in = "sum(cri_r1_f".$i." + cri_r7_f".$i." + cri_r13_f".$i." + cri_r19_f".$i.")";
										$m_cols_out = "sum(oui_r1_f".$i." + oui_r7_f".$i." + oui_r13_f".$i." + oui_r19_f".$i.")";
										$m_cols = "$m_cols_in + $m_cols_out";

										$f_cols_in = "sum(cri_r2_f".$i." + cri_r8_f".$i." + cri_r14_f".$i." + cri_r20_f".$i.")";
										$f_cols_out = "sum(oui_r2_f".$i." + oui_r8_f".$i." + oui_r14_f".$i." + oui_r20_f".$i.")";
										$f_cols = "$f_cols_in + $f_cols_out";
									}
								}
							}
							if($in_out_coverage == 'total_ucs'){
								if($i=='17'){
									$m_cols_in = "sum(cri_r25_f17)";
									$m_cols_out="sum(oui_r25_f17)";
									$m_cols = "$m_cols_in + $m_cols_out";
									$f_cols_in = "sum(cri_r26_f17)";
									$f_cols_out="sum(oui_r26_f17)";
									$f_cols = "$f_cols_in + $f_cols_out";
								}else if($i=='19'){
									$m_cols_in = "sum(cri_r25_f19)";
									$m_cols_out="sum(oui_r25_f19)";
									$m_cols = "$m_cols_in + $m_cols_out";
									$f_cols_in = "sum(cri_r26_f19)";
									$f_cols_out="sum(oui_r26_f19)";
									$f_cols = "$f_cols_in + $f_cols_out";
								}else{
									$m_cols_in = "sum(cri_r1_f".$i." + cri_r7_f".$i." + cri_r13_f".$i." + cri_r19_f".$i.")";
									/* $m_cols_out = "sum(oui_r1_f".$i." + oui_r7_f".$i." + oui_r13_f".$i." + oui_r19_f".$i.")";
									$m_cols = "$m_cols_in + $m_cols_out"; */
									$m_cols = "$m_cols_in";

									$f_cols_in = "sum(cri_r2_f".$i." + cri_r8_f".$i." + cri_r14_f".$i." + cri_r20_f".$i.")";
									/* $f_cols_out = "sum(oui_r2_f".$i." + oui_r8_f".$i." + oui_r14_f".$i." + oui_r20_f".$i.")";
									$f_cols = "$f_cols_in + $f_cols_out"; */
									$f_cols = "$f_cols_in";
								}
							}
							$t_cols = "$m_cols + $f_cols";
							//other uc
							if($in_out_coverage == 'in_uc' || $in_out_coverage == 'in_district'){
								if($start_year >= 2021){
									$ou_tcols = "$ou_mcols + $ou_fcols";
								}else{
									$ou_tcols = "";
								}
							}	
							$show_pl_cba = FALSE;
							break;
						case '12to23':
							if($in_out_coverage == 'in_uc'){
								if($start_year >= 2021){
									if($i=='17'){
										$m_cols_in = "sum(cri_r25_f17)";
										$m_cols_out="sum(oui_r25_f17)";
										$m_cols = "$m_cols_in + $m_cols_out";
										$f_cols_in = "sum(cri_r26_f17)";
										$f_cols_out="sum(oui_r26_f17)";
										$f_cols = "$f_cols_in + $f_cols_out";
									}else if($i=='19'){
										$m_cols_in = "sum(cri_r25_f19)";
										$m_cols_out="sum(oui_r25_f19)";
										$m_cols = "$m_cols_in + $m_cols_out";
										$f_cols_in = "sum(cri_r26_f19)";
										$f_cols_out="sum(oui_r26_f19)";
										$f_cols = "$f_cols_in + $f_cols_out";
									}else{
										$m_cols_in = "sum(cri_r3_f".$i." + cri_r9_f".$i." + cri_r15_f".$i." + cri_r21_f".$i.")";
										$m_cols = "$m_cols_in";

										$f_cols_in = "sum(cri_r4_f".$i." + cri_r10_f".$i." + cri_r16_f".$i." + cri_r22_f".$i.")";
										$f_cols = "$f_cols_in";
									}
									//other uc
									$ou_mcols = "sum(fm2)+sum(om2)+sum(mm2)+sum(hm2)";
									$ou_fcols = "sum(ff2)+sum(of2)+sum(mf2)+sum(hf2)";
								}else{
									if($i=='17'){
										$m_cols_in = "sum(cri_r25_f17)";
										$m_cols_out="sum(oui_r25_f17)"; 
										$m_cols = "$m_cols_in + $m_cols_out";
										$f_cols_in = "sum(cri_r26_f17)";
										$f_cols_out="sum(oui_r26_f17)";
										$f_cols = "$f_cols_in + $f_cols_out";
									}else if($i=='19'){
										$m_cols_in = "sum(cri_r25_f19)";
										$m_cols_out="sum(oui_r25_f19)";
										$m_cols = "$m_cols_in + $m_cols_out";
										$f_cols_in = "sum(cri_r26_f19)";
										$f_cols_out="sum(oui_r26_f19)";
										$f_cols = "$f_cols_in + $f_cols_out";
									}else{
										$m_cols_in = "sum(cri_r3_f".$i." + cri_r9_f".$i." + cri_r15_f".$i." + cri_r21_f".$i.")";
										$m_cols_out = "sum(oui_r3_f".$i." + oui_r9_f".$i." + oui_r15_f".$i." + oui_r21_f".$i.")";
										$m_cols = "$m_cols_in + $m_cols_out";

										$f_cols_in = "sum(cri_r4_f".$i." + cri_r10_f".$i." + cri_r16_f".$i." + cri_r22_f".$i.")";
										$f_cols_out = "sum(oui_r4_f".$i." + oui_r10_f".$i." + oui_r16_f".$i." + oui_r22_f".$i.")";
										$f_cols = "$f_cols_in + $f_cols_out";
									}
								}
							}
							if($in_out_coverage == 'out_uc'){
								if($i=='17'){
									$m_cols = "sum(oui_r25_f17)";
									$f_cols = "sum(oui_r26_f17)";
								}else if($i=='19'){
									$m_cols = "sum(oui_r25_f19)";
									$f_cols = "sum(oui_r26_f19)";
								}else{
									$m_cols = "sum(oui_r3_f".$i." + oui_r9_f".$i." + oui_r15_f".$i." + oui_r21_f".$i.")";
									$f_cols = "sum(oui_r4_f".$i." + oui_r10_f".$i." + oui_r16_f".$i." + oui_r22_f".$i.")";
								}
							}
							if($in_out_coverage == 'in_district'){
								if($start_year >= 2021){
									if($i=='17'){
										$m_cols_in = "sum(cri_r25_f17)";
										$m_cols_out="sum(oui_r25_f17)";
										$m_cols = "$m_cols_in + $m_cols_out";
										$f_cols_in = "sum(cri_r26_f17)";
										$f_cols_out="sum(oui_r26_f17)";
										$f_cols = "$f_cols_in + $f_cols_out";
									}else if($i=='19'){
										$m_cols_in = "sum(cri_r25_f19)";
										$m_cols_out="sum(oui_r25_f19)";
										$m_cols = "$m_cols_in + $m_cols_out";
										$f_cols_in = "sum(cri_r26_f19)";
										$f_cols_out="sum(oui_r26_f19)";
										$f_cols = "$f_cols_in + $f_cols_out";
									}else{
										$m_cols_in = "sum(cri_r3_f".$i." + cri_r9_f".$i." + cri_r15_f".$i." + cri_r21_f".$i.")";
										//$m_cols_out = "sum(oui_r3_f".$i." + oui_r9_f".$i." + oui_r15_f".$i." + oui_r21_f".$i.")";
										//$m_cols = "$m_cols_in + $m_cols_out";
										$m_cols = "$m_cols_in";

										$f_cols_in = "sum(cri_r4_f".$i." + cri_r10_f".$i." + cri_r16_f".$i." + cri_r22_f".$i.")";
										//$f_cols_out = "sum(oui_r4_f".$i." + oui_r10_f".$i." + oui_r16_f".$i." + oui_r22_f".$i.")";
										//$f_cols = "$f_cols_in + $f_cols_out";
										$f_cols = "$f_cols_in";
									}
									//other uc
									$ou_mcols = "sum(fm2)+sum(om2)+sum(mm2)+sum(hm2)";
									$ou_fcols = "sum(ff2)+sum(of2)+sum(mf2)+sum(hf2)";
								}else{
									if($i=='17'){
										$m_cols_in = "sum(cri_r25_f17)";
										$m_cols_out="sum(oui_r25_f17)";
										$m_cols = "$m_cols_in + $m_cols_out";
										$f_cols_in = "sum(cri_r26_f17)";
										$f_cols_out="sum(oui_r26_f17)";
										$f_cols = "$f_cols_in + $f_cols_out";
									}else if($i=='19'){
										$m_cols_in = "sum(cri_r25_f19)";
										$m_cols_out="sum(oui_r25_f19)";
										$m_cols = "$m_cols_in + $m_cols_out";
										$f_cols_in = "sum(cri_r26_f19)";
										$f_cols_out="sum(oui_r26_f19)";
										$f_cols = "$f_cols_in + $f_cols_out";
									}else{
										$m_cols_in = "sum(cri_r3_f".$i." + cri_r9_f".$i." + cri_r15_f".$i." + cri_r21_f".$i.")";
										$m_cols_out = "sum(oui_r3_f".$i." + oui_r9_f".$i." + oui_r15_f".$i." + oui_r21_f".$i.")";
										$m_cols = "$m_cols_in + $m_cols_out";

										$f_cols_in = "sum(cri_r4_f".$i." + cri_r10_f".$i." + cri_r16_f".$i." + cri_r22_f".$i.")";
										$f_cols_out = "sum(oui_r4_f".$i." + oui_r10_f".$i." + oui_r16_f".$i." + oui_r22_f".$i.")";
										$f_cols = "$f_cols_in + $f_cols_out";
									}
								}
							}
							if($in_out_coverage == 'total_ucs'){
								if($i=='17'){
									$m_cols_in = "sum(cri_r25_f17)";
									$m_cols_out="sum(oui_r25_f17)";
									$m_cols = "$m_cols_in + $m_cols_out";
									$f_cols_in = "sum(cri_r26_f17)";
									$f_cols_out="sum(oui_r26_f17)";
									$f_cols = "$f_cols_in + $f_cols_out";
								}else if($i=='19'){
									$m_cols_in = "sum(cri_r25_f19)";
									$m_cols_out="sum(oui_r25_f19)";
									$m_cols = "$m_cols_in + $m_cols_out";
									$f_cols_in = "sum(cri_r26_f19)";
									$f_cols_out="sum(oui_r26_f19)";
									$f_cols = "$f_cols_in + $f_cols_out";
								}else{
									$m_cols_in = "sum(cri_r3_f".$i." + cri_r9_f".$i." + cri_r15_f".$i." + cri_r21_f".$i.")";
									/* $m_cols_out = "sum(oui_r3_f".$i." + oui_r9_f".$i." + oui_r15_f".$i." + oui_r21_f".$i.")";
									$m_cols = "$m_cols_in + $m_cols_out"; */
									$m_cols = "$m_cols_in";

									$f_cols_in = "sum(cri_r4_f".$i." + cri_r10_f".$i." + cri_r16_f".$i." + cri_r22_f".$i.")";
									/* $f_cols_out = "sum(oui_r4_f".$i." + oui_r10_f".$i." + oui_r16_f".$i." + oui_r22_f".$i.")";
									$f_cols = "$f_cols_in + $f_cols_out"; */
									$f_cols = "$f_cols_in";
								}
							}
							$t_cols = "$m_cols + $f_cols";
							//other uc
							if($in_out_coverage == 'in_uc' || $in_out_coverage == 'in_district'){
								if($start_year >= 2021){
									$ou_tcols = "$ou_mcols + $ou_fcols";
								}else{
									$ou_tcols = "";
								}
							}	
							$show_pl_cba = FALSE;
							break;
						case 'under2':
							if($in_out_coverage == 'in_uc'){
								$m_cols = "sum(cri_r1_f".$i." + cri_r7_f".$i." + cri_r13_f".$i." + cri_r19_f".$i." + cri_r3_f".$i." + cri_r9_f".$i." + cri_r15_f".$i." + cri_r21_f".$i.")";
								$f_cols = "sum(cri_r2_f".$i." + cri_r8_f".$i." + cri_r14_f".$i." + cri_r20_f".$i." + cri_r4_f".$i." + cri_r10_f".$i." + cri_r16_f".$i." + cri_r22_f".$i.")";
							}
							if($in_out_coverage == 'out_uc'){
								$m_cols = "sum(oui_r1_f".$i." + oui_r7_f".$i." + oui_r13_f".$i." + oui_r19_f".$i." + oui_r3_f".$i." + oui_r9_f".$i." + oui_r15_f".$i." + oui_r21_f".$i.")";
								$f_cols = "sum(oui_r2_f".$i." + oui_r8_f".$i." + oui_r14_f".$i." + oui_r20_f".$i." + oui_r4_f".$i." + oui_r10_f".$i." + oui_r16_f".$i." + oui_r22_f".$i.")";
							}
							if($in_out_coverage == 'total_ucs' || $in_out_coverage == 'in_district'){
								$m_cols_in = "sum(cri_r1_f".$i." + cri_r7_f".$i." + cri_r13_f".$i." + cri_r19_f".$i." + cri_r3_f".$i." + cri_r9_f".$i." + cri_r15_f".$i." + cri_r21_f".$i.")";
								$m_cols_out = "sum(oui_r1_f".$i." + oui_r7_f".$i." + oui_r13_f".$i." + oui_r19_f".$i." + oui_r3_f".$i." + oui_r9_f".$i." + oui_r15_f".$i." + oui_r21_f".$i.")";
								$m_cols = "$m_cols_in + $m_cols_out";

								$f_cols_in = "sum(cri_r2_f".$i." + cri_r8_f".$i." + cri_r14_f".$i." + cri_r20_f".$i." + cri_r4_f".$i." + cri_r10_f".$i." + cri_r16_f".$i." + cri_r22_f".$i.")";
								$f_cols_out = "sum(oui_r2_f".$i." + oui_r8_f".$i." + oui_r14_f".$i." + oui_r20_f".$i." + oui_r4_f".$i." + oui_r10_f".$i." + oui_r16_f".$i." + oui_r22_f".$i.")";
								$f_cols = "$f_cols_in + $f_cols_out";
							}
							$t_cols = "$m_cols + $f_cols";
							$show_pl_cba = FALSE;
							break;
						case 'above2':
							if($in_out_coverage == 'in_uc'){
								if($start_year >= 2021){
									if($i=='17'){
										$m_cols_in = "sum(cri_r25_f17)";
										$m_cols_out="sum(oui_r25_f17)";
										$m_cols = "$m_cols_in + $m_cols_out";
										$f_cols_in = "sum(cri_r26_f17)";
										$f_cols_out="sum(oui_r26_f17)";
										$f_cols = "$f_cols_in + $f_cols_out";
									}else if($i=='19'){
										$m_cols_in = "sum(cri_r25_f19)";
										$m_cols_out="sum(oui_r25_f19)";
										$m_cols = "$m_cols_in + $m_cols_out";
										$f_cols_in = "sum(cri_r26_f19)";
										$f_cols_out="sum(oui_r26_f19)";
										$f_cols = "$f_cols_in + $f_cols_out";
									}else{
										$m_cols_in = "sum(cri_r5_f".$i." + cri_r11_f".$i." + cri_r17_f".$i." + cri_r23_f".$i.")";
										$m_cols = "$m_cols_in ";

										$f_cols_in = "sum(cri_r6_f".$i." + cri_r12_f".$i." + cri_r18_f".$i." + cri_r24_f".$i.")";
										$f_cols = "$f_cols_in ";
									}
									//other uc
									$ou_mcols = "sum(fm3)+sum(om3)+sum(mm3)+sum(hm3)";
									$ou_fcols = "sum(ff3)+sum(of3)+sum(mf3)+sum(hf3)";
								}else{
									if($i=='17'){
										$m_cols_in = "sum(cri_r25_f17)";
										$m_cols_out="sum(oui_r25_f17)";
										$m_cols = "$m_cols_in + $m_cols_out";
										$f_cols_in = "sum(cri_r26_f17)";
										$f_cols_out="sum(oui_r26_f17)";
										$f_cols = "$f_cols_in + $f_cols_out";
									}else if($i=='19'){
										$m_cols_in = "sum(cri_r25_f19)";
										$m_cols_out="sum(oui_r25_f19)";
										$m_cols = "$m_cols_in + $m_cols_out";
										$f_cols_in = "sum(cri_r26_f19)";
										$f_cols_out="sum(oui_r26_f19)";
										$f_cols = "$f_cols_in + $f_cols_out";
									}else{
										$m_cols_in = "sum(cri_r5_f".$i." + cri_r11_f".$i." + cri_r17_f".$i." + cri_r23_f".$i.")";
										$m_cols_out = "sum(oui_r5_f".$i." + oui_r11_f".$i." + oui_r17_f".$i." + oui_r23_f".$i.")";
										$m_cols = "$m_cols_in + $m_cols_out";

										$f_cols_in = "sum(cri_r6_f".$i." + cri_r12_f".$i." + cri_r18_f".$i." + cri_r24_f".$i.")";
										$f_cols_out = "sum(oui_r6_f".$i." + oui_r12_f".$i." + oui_r18_f".$i." + oui_r24_f".$i.")";
										$f_cols = "$f_cols_in + $f_cols_out";
									}
									//other uc
									$ou_mcols = "sum(fm3)+sum(om3)+sum(mm3)+sum(hm3)";
									$ou_fcols = "sum(ff3)+sum(of3)+sum(mf3)+sum(hf3)";
								}
							}
							if($in_out_coverage == 'out_uc'){
								if($i=='17'){
									$m_cols = "sum(oui_r25_f17)";
									$f_cols = "sum(oui_r26_f17)";
								}else if($i=='19'){
									$m_cols = "sum(oui_r25_f19)";
									$f_cols = "sum(oui_r26_f19)";
								}else{
									$m_cols = "sum(oui_r5_f".$i." + oui_r11_f".$i." + oui_r17_f".$i." + oui_r23_f".$i.")";
									$f_cols = "sum(oui_r6_f".$i." + oui_r12_f".$i." + oui_r18_f".$i." + oui_r24_f".$i.")";
								}
							}
							if($in_out_coverage == 'in_district'){
								if($start_year >= 2021){
									if($i=='17'){
										$m_cols_in = "sum(cri_r25_f17)";
										$m_cols_out="sum(oui_r25_f17)";
										$m_cols = "$m_cols_in + $m_cols_out";
										$f_cols_in = "sum(cri_r26_f17)";
										$f_cols_out="sum(oui_r26_f17)";
										$f_cols = "$f_cols_in + $f_cols_out";
									}else if($i=='19'){
										$m_cols_in = "sum(cri_r25_f19)";
										$m_cols_out="sum(oui_r25_f19)";
										$m_cols = "$m_cols_in + $m_cols_out";
										$f_cols_in = "sum(cri_r26_f19)";
										$f_cols_out="sum(oui_r26_f19)";
										$f_cols = "$f_cols_in + $f_cols_out";
									}else{
										$m_cols_in = "sum(cri_r5_f".$i." + cri_r11_f".$i." + cri_r17_f".$i." + cri_r23_f".$i.")";
										//$m_cols_out = "sum(oui_r5_f".$i." + oui_r11_f".$i." + oui_r17_f".$i." + oui_r23_f".$i.")";
										//$m_cols = "$m_cols_in + $m_cols_out";
										$m_cols = "$m_cols_in ";

										$f_cols_in = "sum(cri_r6_f".$i." + cri_r12_f".$i." + cri_r18_f".$i." + cri_r24_f".$i.")";
										//$f_cols_out = "sum(oui_r6_f".$i." + oui_r12_f".$i." + oui_r18_f".$i." + oui_r24_f".$i.")";
										//$f_cols = "$f_cols_in + $f_cols_out";
										$f_cols = "$f_cols_in ";
									}
									//other uc
									$ou_mcols = "sum(fm3)+sum(om3)+sum(mm3)+sum(hm3)";
									$ou_fcols = "sum(ff3)+sum(of3)+sum(mf3)+sum(hf3)";
								}else{
									if($i=='17'){
										$m_cols_in = "sum(cri_r25_f17)";
										$m_cols_out="sum(oui_r25_f17)";
										$m_cols = "$m_cols_in + $m_cols_out";
										$f_cols_in = "sum(cri_r26_f17)";
										$f_cols_out="sum(oui_r26_f17)";
										$f_cols = "$f_cols_in + $f_cols_out";
									}else if($i=='19'){
										$m_cols_in = "sum(cri_r25_f19)";
										$m_cols_out="sum(oui_r25_f19)";
										$m_cols = "$m_cols_in + $m_cols_out";
										$f_cols_in = "sum(cri_r26_f19)";
										$f_cols_out="sum(oui_r26_f19)";
										$f_cols = "$f_cols_in + $f_cols_out";
									}else{
										$m_cols_in = "sum(cri_r5_f".$i." + cri_r11_f".$i." + cri_r17_f".$i." + cri_r23_f".$i.")";
										$m_cols_out = "sum(oui_r5_f".$i." + oui_r11_f".$i." + oui_r17_f".$i." + oui_r23_f".$i.")";
										$m_cols = "$m_cols_in + $m_cols_out";

										$f_cols_in = "sum(cri_r6_f".$i." + cri_r12_f".$i." + cri_r18_f".$i." + cri_r24_f".$i.")";
										$f_cols_out = "sum(oui_r6_f".$i." + oui_r12_f".$i." + oui_r18_f".$i." + oui_r24_f".$i.")";
										$f_cols = "$f_cols_in + $f_cols_out";
									}
									//other uc
									$ou_mcols = "sum(fm3)+sum(om3)+sum(mm3)+sum(hm3)";
									$ou_fcols = "sum(ff3)+sum(of3)+sum(mf3)+sum(hf3)";
								}
							}
							if($in_out_coverage == 'total_ucs'){
								if($i=='17'){
									$m_cols_in = "sum(cri_r25_f17)";
									$m_cols_out="sum(oui_r25_f17)";
									$m_cols = "$m_cols_in + $m_cols_out";
									$f_cols_in = "sum(cri_r26_f17)";
									$f_cols_out="sum(oui_r26_f17)";
									$f_cols = "$f_cols_in + $f_cols_out";
								}else if($i=='19'){
									$m_cols_in = "sum(cri_r25_f19)";
									$m_cols_out="sum(oui_r25_f19)";
									$m_cols = "$m_cols_in + $m_cols_out";
									$f_cols_in = "sum(cri_r26_f19)";
									$f_cols_out="sum(oui_r26_f19)";
									$f_cols = "$f_cols_in + $f_cols_out";
								}else{
									$m_cols_in = "sum(cri_r5_f".$i." + cri_r11_f".$i." + cri_r17_f".$i." + cri_r23_f".$i.")";
									/* $m_cols_out = "sum(oui_r5_f".$i." + oui_r11_f".$i." + oui_r17_f".$i." + oui_r23_f".$i.")";
									$m_cols = "$m_cols_in + $m_cols_out"; */
									$m_cols = "$m_cols_in";

									$f_cols_in = "sum(cri_r6_f".$i." + cri_r12_f".$i." + cri_r18_f".$i." + cri_r24_f".$i.")";
									/* $f_cols_out = "sum(oui_r6_f".$i." + oui_r12_f".$i." + oui_r18_f".$i." + oui_r24_f".$i.")";
									$f_cols = "$f_cols_in + $f_cols_out"; */
									$f_cols = "$f_cols_in";
								}
							}
							$t_cols = "$m_cols + $f_cols";
							//other uc
							if($in_out_coverage == 'in_uc' || $in_out_coverage == 'in_district'){
								if($start_year >= 2021){
									$ou_tcols = "$ou_mcols + $ou_fcols";
								}else{
									$ou_tcols = "";
								}
							}
							$show_pl_cba = FALSE;
							break;
						default:
							# code...
							break;
					}
					if($i >=1 && $i <= 3)
					{
						if($in_out_coverage == 'in_uc' || $in_out_coverage == 'in_district'){
							if($vacc_to == 'gender' && $age_wise == 'all'){
								if($i==1){
									$coverage_detail_m='coalesce(sum(coverage_bcg_m_all_genderwise),0)';
									$coverage_detail_f='coalesce(sum(coverage_bcg_f_all_genderwise),0)';
								}else if($i==2){
									$coverage_detail_m='coalesce(sum(coverage_hepb_m_all_genderwise),0)';
									$coverage_detail_f='coalesce(sum(coverage_hepb_f_all_genderwise),0)';
								}else if($i==3){
									$coverage_detail_m='coalesce(sum(coverage_opv_0_m_all_genderwise),0)';
									$coverage_detail_f='coalesce(sum(coverage_opv_0_f_all_genderwise),0)';
								}
							}else if($vacc_to == 'gender' && $age_wise == '0to11'){
								if($i==1){
									$coverage_detail_m='coalesce(sum(coverage_bcg_m_0_11_genderwise),0)';
									$coverage_detail_f='coalesce(sum(coverage_bcg_f_0_11_genderwise),0)';
								}else if($i==2){
									$coverage_detail_m='coalesce(sum(coverage_hepb_m_0_11_genderwise),0)';
									$coverage_detail_f='coalesce(sum(coverage_hepb_f_0_11_genderwise),0)';
								}else if($i==3){
									$coverage_detail_m='coalesce(sum(coverage_opv_0_m_0_11_genderwise),0)';
									$coverage_detail_f='coalesce(sum(coverage_opv_0_f_0_11_genderwise),0)';
								}
							}else if($vacc_to == 'gender' && $age_wise == '12to23'){
								if($i==1){
									$coverage_detail_m='coalesce(sum(coverage_bcg_m_12_23_genderwise),0)';
									$coverage_detail_f='coalesce(sum(coverage_bcg_f_12_23_genderwise),0)';
								}else if($i==2){
									$coverage_detail_m='coalesce(sum(coverage_hepb_m_12_23_genderwise),0)';
									$coverage_detail_f='coalesce(sum(coverage_hepb_f_12_23_genderwise),0)';
								}else if($i==3){
									$coverage_detail_m='coalesce(sum(coverage_opv_0_m_12_23_genderwise),0)';
									$coverage_detail_f='coalesce(sum(coverage_opv_0_f_12_23_genderwise),0)';
								}
							}else if($vacc_to == 'gender' && $age_wise == 'above2'){
								if($i==1){
									$coverage_detail_m='coalesce(sum(coverage_bcg_m_above_2_years_genderwise),0)';
									$coverage_detail_f='coalesce(sum(coverage_bcg_f_above_2_years_genderwise),0)';
								}else if($i==2){
									$coverage_detail_m='coalesce(sum(coverage_hepb_m_above_2_years_genderwise),0)';
									$coverage_detail_f='coalesce(sum(coverage_hepb_f_above_2_years_genderwise),0)';
								}else if($i==3){
									$coverage_detail_m='coalesce(sum(coverage_opv_0_m_above_2_years_genderwise),0)';
									$coverage_detail_f='coalesce(sum(coverage_opv_0_f_above_2_years_genderwise),0)';
								}
							}else if($vacc_to == 'total_children' && $age_wise == 'all'){
								if($i==1){
									$coverage_detail_total='coalesce(sum(coverage_bcg_total_all_totalchildren),0)';
								}else if($i==2){
									$coverage_detail_total='coalesce(sum(coverage_hepb_total_all_totalchildren),0)';
								}else if($i==3){
									$coverage_detail_total='coalesce(sum(coverage_opv_0_total_all_totalchildren),0)';
								}
							}else if($vacc_to == 'total_children' && $age_wise == '0to11'){
								if($i==1){
									$coverage_detail_total='coalesce(sum(coverage_bcg_total_0_11_totalchildren),0)';
								}else if($i==2){
									$coverage_detail_total='coalesce(sum(coverage_hepb_total_0_11_totalchildren),0)';
								}else if($i==3){
									$coverage_detail_total='coalesce(sum(coverage_opv_0_total_0_11_totalchildren),0)';
								}
							}else if($vacc_to == 'total_children' && $age_wise == '12to23'){
								if($i==1){
									$coverage_detail_total='coalesce(sum(coverage_bcg_total_12_23_totalchildren),0)';
								}else if($i==2){
									$coverage_detail_total='coalesce(sum(coverage_hepb_total_12_23_totalchildren),0)';
								}else if($i==3){
									$coverage_detail_total='coalesce(sum(coverage_opv_0_total_12_23_totalchildren),0)';
								}
							}else if($vacc_to == 'total_children' && $age_wise == 'above2'){
								if($i==1){
									$coverage_detail_total='coalesce(sum(coverage_bcg_total_above_2_years_totalchildren),0)';
								}else if($i==2){
									$coverage_detail_total='coalesce(sum(coverage_hepb_total_above_2_years_totalchildren),0)';
								}else if($i==3){
									$coverage_detail_total='coalesce(sum(coverage_opv_0_total_above_2_years_totalchildren),0)';
								}
							}
							if($vacc_to == 'gender')
							{
								if($start_year >= 2021){
									//other uc
									if($i ==1){
										$ou_mcols_att ="+(select coalesce($ou_mcols,0) from monthly_outuc_coverage where monthly_outuc_coverage.uncode=fac_mvrf_db.uncode $monthly_ou_fmonthCondition and monthly_outuc_coverage.item_id='2' and monthly_outuc_coverage.antigen='0')";
										$ou_fcols_att ="+(select coalesce($ou_fcols,0) from monthly_outuc_coverage where monthly_outuc_coverage.uncode=fac_mvrf_db.uncode $monthly_ou_fmonthCondition and monthly_outuc_coverage.item_id='2' and monthly_outuc_coverage.antigen='0')";
									}else if($i==3){
										$ou_mcols_att ="+(select coalesce($ou_mcols,0) from monthly_outuc_coverage where monthly_outuc_coverage.uncode=fac_mvrf_db.uncode $monthly_ou_fmonthCondition and monthly_outuc_coverage.item_id='15' and monthly_outuc_coverage.antigen='0')";
										$ou_fcols_att ="+(select coalesce($ou_fcols,0) from monthly_outuc_coverage where monthly_outuc_coverage.uncode=fac_mvrf_db.uncode $monthly_ou_fmonthCondition and monthly_outuc_coverage.item_id='15' and monthly_outuc_coverage.antigen='0')";
									}else{
										$ou_mcols_att="";
										$ou_fcols_att="";
									}
								}else{
									$ou_mcols_att="";
									$ou_fcols_att="";
								}
								$queryForYearlyData .= "
								(select $coverage_detail_m from coverage_report_details where coverage_report_details.coverage_uncode_all_totalchildren=flcf1.uncode $fmonthCondition  ) as M$asValueCRI,
								(select CASE WHEN $newbornMale = 0 THEN 0 ELSE round(($coverage_detail_m*100)/NULLIF($newbornMale,0)) END from coverage_report_details where coverage_report_details.coverage_uncode_all_totalchildren=flcf1.uncode $fmonthCondition group by coverage_report_details.coverage_uncode_all_totalchildren ) as percM$asValueCRI,
								(select $coverage_detail_f from coverage_report_details where coverage_report_details.coverage_uncode_all_totalchildren=flcf1.uncode $fmonthCondition) as F$asValueCRI,
								(select CASE WHEN $newbornFemale = 0 THEN 0 ELSE round(($coverage_detail_f*100)/NULLIF($newbornFemale,0)) END from coverage_report_details where coverage_report_details.coverage_uncode_all_totalchildren=flcf1.uncode $fmonthCondition group by coverage_report_details.coverage_uncode_all_totalchildren) as percF$asValueCRI,
								";
							}
							elseif($vacc_to == 'total_children')
							{
								if($start_year >= 2021){
									//other uc
									if($i ==1){
										$ou_tcols_att ="+(select coalesce($ou_tcols,0) from monthly_outuc_coverage where monthly_outuc_coverage.uncode=fac_mvrf_db.uncode $monthly_ou_fmonthCondition and monthly_outuc_coverage.item_id='2' and monthly_outuc_coverage.antigen='0')";
									}else if($i==3){
										$ou_tcols_att ="+(select coalesce($ou_tcols,0) from monthly_outuc_coverage where monthly_outuc_coverage.uncode=fac_mvrf_db.uncode $monthly_ou_fmonthCondition and monthly_outuc_coverage.item_id='15' and monthly_outuc_coverage.antigen='0')";
									}else{
										$ou_tcols_att="";
									}
								}else{
									$ou_tcols_att="";
								}
								$queryForYearlyData .= "
								(select $coverage_detail_total from coverage_report_details where coverage_report_details.coverage_uncode_all_totalchildren=flcf1.uncode $fmonthCondition  ) as T$asValueCRI,
								(select CASE WHEN $newbornMale > 0 OR $newbornFemale > 0 THEN round(($coverage_detail_total*100)/(NULLIF($newbornFemale,0) + NULLIF($newbornMale,0))) ELSE 0 END from coverage_report_details where coverage_report_details.coverage_uncode_all_totalchildren=flcf1.uncode $fmonthCondition group by coverage_report_details.coverage_uncode_all_totalchildren ) as percT$asValueCRI,
								";
							}
							
						}
						else{
							if($in_out_coverage == 'total_ucs'){
								if($vacc_to == 'gender' && $age_wise == 'all'){
									if($i==1){
										$coverage_detail_m='coalesce(sum(own_bcg_m_all_genderwise),0)';
										$coverage_detail_f='coalesce(sum(own_bcg_f_all_genderwise),0)';
									}else if($i==2){
										$coverage_detail_m='coalesce(sum(own_hepb_m_all_genderwise),0)';
										$coverage_detail_f='coalesce(sum(own_hepb_f_all_genderwise),0)';
									}else if($i==3){
										$coverage_detail_m='coalesce(sum(own_opv_0_m_all_genderwise),0)';
										$coverage_detail_f='coalesce(sum(own_opv_0_f_all_genderwise),0)';
									}
								}else if($vacc_to == 'gender' && $age_wise == '0to11'){
									if($i==1){
										$coverage_detail_m='coalesce(sum(own_bcg_m_0_11_genderwise),0)';
										$coverage_detail_f='coalesce(sum(own_bcg_f_0_11_genderwise),0)';
									}else if($i==2){
										$coverage_detail_m='coalesce(sum(own_hepb_m_0_11_genderwise),0)';
										$coverage_detail_f='coalesce(sum(own_hepb_f_0_11_genderwise),0)';
									}else if($i==3){
										$coverage_detail_m='coalesce(sum(own_opv_0_m_0_11_genderwise),0)';
										$coverage_detail_f='coalesce(sum(own_opv_0_f_0_11_genderwise),0)';
									}
								}else if($vacc_to == 'gender' && $age_wise == '12to23'){
									if($i==1){
										$coverage_detail_m='coalesce(sum(own_bcg_m_12_23_genderwise),0)';
										$coverage_detail_f='coalesce(sum(own_bcg_f_12_23_genderwise),0)';
									}else if($i==2){
										$coverage_detail_m='coalesce(sum(own_hepb_m_12_23_genderwise),0)';
										$coverage_detail_f='coalesce(sum(own_hepb_f_12_23_genderwise),0)';
									}else if($i==3){
										$coverage_detail_m='coalesce(sum(own_opv_0_m_12_23_genderwise),0)';
										$coverage_detail_f='coalesce(sum(own_opv_0_f_12_23_genderwise),0)';
									}
								}else if($vacc_to == 'gender' && $age_wise == 'above2'){
									if($i==1){
										$coverage_detail_m='coalesce(sum(own_bcg_m_above_2_years_genderwise),0)';
										$coverage_detail_f='coalesce(sum(own_bcg_f_above_2_years_genderwise),0)';
									}else if($i==2){
										$coverage_detail_m='coalesce(sum(own_hepb_m_above_2_years_genderwise),0)';
										$coverage_detail_f='coalesce(sum(own_hepb_f_above_2_years_genderwise),0)';
									}else if($i==3){
										$coverage_detail_m='coalesce(sum(own_opv_0_m_above_2_years_genderwise),0)';
										$coverage_detail_f='coalesce(sum(own_opv_0_f_above_2_years_genderwise),0)';
									}
								}else if($vacc_to == 'total_children' && $age_wise == 'all'){
									if($i==1){
										$coverage_detail_total='coalesce(sum(own_bcg_total_all_totalchildren),0)';
									}else if($i==2){
										$coverage_detail_total='coalesce(sum(own_hepb_total_all_totalchildren),0)';
									}else if($i==3){
										$coverage_detail_total='coalesce(sum(own_opv_0_total_all_totalchildren),0)';
									}
								}else if($vacc_to == 'total_children' && $age_wise == '0to11'){
									if($i==1){
										$coverage_detail_total='coalesce(sum(own_bcg_total_0_11_totalchildren),0)';
									}else if($i==2){
										$coverage_detail_total='coalesce(sum(own_hepb_total_0_11_totalchildren),0)';
									}else if($i==3){
										$coverage_detail_total='coalesce(sum(own_opv_0_total_0_11_totalchildren),0)';
									}
								}else if($vacc_to == 'total_children' && $age_wise == '12to23'){
									if($i==1){
										$coverage_detail_total='coalesce(sum(own_bcg_total_12_23_totalchildren),0)';
									}else if($i==2){
										$coverage_detail_total='coalesce(sum(own_hepb_total_12_23_totalchildren),0)';
									}else if($i==3){
										$coverage_detail_total='coalesce(sum(own_opv_0_total_12_23_totalchildren),0)';
									}
								}else if($vacc_to == 'total_children' && $age_wise == 'above2'){
									if($i==1){
										$coverage_detail_total='coalesce(sum(own_bcg_total_above_2_years_totalchildren),0)';
									}else if($i==2){
										$coverage_detail_total='coalesce(sum(own_hepb_total_above_2_years_totalchildren),0)';
									}else if($i==3){
										$coverage_detail_total='coalesce(sum(own_opv_0_total_above_2_years_totalchildren),0)';
									}
								}
							}else{
								if($vacc_to == 'gender' && $age_wise == 'all'){
									if($i==1){
										$coverage_detail_m='coalesce(sum(others_bcg_m_all_genderwise),0)';
										$coverage_detail_f='coalesce(sum(others_bcg_f_all_genderwise),0)';
									}else if($i==2){
										$coverage_detail_m='coalesce(sum(others_hepb_m_all_genderwise),0)';
										$coverage_detail_f='coalesce(sum(others_hepb_f_all_genderwise),0)';
									}else if($i==3){
										$coverage_detail_m='coalesce(sum(others_opv_0_m_all_genderwise),0)';
										$coverage_detail_f='coalesce(sum(others_opv_0_f_all_genderwise),0)';
									}
								}else if($vacc_to == 'gender' && $age_wise == '0to11'){
									if($i==1){
										$coverage_detail_m='coalesce(sum(others_bcg_m_0_11_genderwise),0)';
										$coverage_detail_f='coalesce(sum(others_bcg_f_0_11_genderwise),0)';
									}else if($i==2){
										$coverage_detail_m='coalesce(sum(others_hepb_m_0_11_genderwise),0)';
										$coverage_detail_f='coalesce(sum(others_hepb_f_0_11_genderwise),0)';
									}else if($i==3){
										$coverage_detail_m='coalesce(sum(others_opv_0_m_0_11_genderwise),0)';
										$coverage_detail_f='coalesce(sum(others_opv_0_f_0_11_genderwise),0)';
									}
								}else if($vacc_to == 'gender' && $age_wise == '12to23'){
									if($i==1){
										$coverage_detail_m='coalesce(sum(others_bcg_m_12_23_genderwise),0)';
										$coverage_detail_f='coalesce(sum(others_bcg_f_12_23_genderwise),0)';
									}else if($i==2){
										$coverage_detail_m='coalesce(sum(others_hepb_m_12_23_genderwise),0)';
										$coverage_detail_f='coalesce(sum(others_hepb_f_12_23_genderwise),0)';
									}else if($i==3){
										$coverage_detail_m='coalesce(sum(others_opv_0_m_12_23_genderwise),0)';
										$coverage_detail_f='coalesce(sum(others_opv_0_f_12_23_genderwise),0)';
									}
								}else if($vacc_to == 'gender' && $age_wise == 'above2'){
									if($i==1){
										$coverage_detail_m='coalesce(sum(others_bcg_m_above_2_years_genderwise),0)';
										$coverage_detail_f='coalesce(sum(others_bcg_f_above_2_years_genderwise),0)';
									}else if($i==2){
										$coverage_detail_m='coalesce(sum(others_hepb_m_above_2_years_genderwise),0)';
										$coverage_detail_f='coalesce(sum(others_hepb_f_above_2_years_genderwise),0)';
									}else if($i==3){
										$coverage_detail_m='coalesce(sum(others_opv_0_m_above_2_years_genderwise),0)';
										$coverage_detail_f='coalesce(sum(others_opv_0_f_above_2_years_genderwise),0)';
									}
								}else if($vacc_to == 'total_children' && $age_wise == 'all'){
									if($i==1){
										$coverage_detail_total='coalesce(sum(others_bcg_total_all_totalchildren),0)';
									}else if($i==2){
										$coverage_detail_total='coalesce(sum(others_hepb_total_all_totalchildren),0)';
									}else if($i==3){
										$coverage_detail_total='coalesce(sum(others_opv_0_total_all_totalchildren),0)';
									}
								}else if($vacc_to == 'total_children' && $age_wise == '0to11'){
									if($i==1){
										$coverage_detail_total='coalesce(sum(others_bcg_total_0_11_totalchildren),0)';
									}else if($i==2){
										$coverage_detail_total='coalesce(sum(others_hepb_total_0_11_totalchildren),0)';
									}else if($i==3){
										$coverage_detail_total='coalesce(sum(others_opv_0_total_0_11_totalchildren),0)';
									}
								}else if($vacc_to == 'total_children' && $age_wise == '12to23'){
									if($i==1){
										$coverage_detail_total='coalesce(sum(others_bcg_total_12_23_totalchildren),0)';
									}else if($i==2){
										$coverage_detail_total='coalesce(sum(others_hepb_total_12_23_totalchildren),0)';
									}else if($i==3){
										$coverage_detail_total='coalesce(sum(others_opv_0_total_12_23_totalchildren),0)';
									}
								}else if($vacc_to == 'total_children' && $age_wise == 'above2'){
									if($i==1){
										$coverage_detail_total='coalesce(sum(others_bcg_total_above_2_years_totalchildren),0)';
									}else if($i==2){
										$coverage_detail_total='coalesce(sum(others_hepb_total_above_2_years_totalchildren),0)';
									}else if($i==3){
										$coverage_detail_total='coalesce(sum(others_opv_0_total_above_2_years_totalchildren),0)';
									}
								}
							}
							if($vacc_to == 'gender')
							{
								$queryForYearlyData .= "
								(select $coverage_detail_m from coverage_report_details where coverage_report_details.coverage_uncode_all_totalchildren=flcf1.uncode $fmonthCondition) as M$asValueCRI,
								(select CASE WHEN $newbornMale = 0 THEN 0 ELSE round(($coverage_detail_m*100)/NULLIF($newbornMale,0)) END from coverage_report_details where coverage_report_details.coverage_uncode_all_totalchildren=flcf1.uncode $fmonthCondition group by coverage_report_details.coverage_uncode_all_totalchildren ) as percM$asValueCRI,
								(select $coverage_detail_f from coverage_report_details where coverage_report_details.coverage_uncode_all_totalchildren=flcf1.uncode $fmonthCondition) as F$asValueCRI,
								(select CASE WHEN $newbornFemale = 0 THEN 0 ELSE round(($coverage_detail_f*100)/NULLIF($newbornFemale,0)) END from coverage_report_details where coverage_report_details.coverage_uncode_all_totalchildren=flcf1.uncode $fmonthCondition group by coverage_report_details.coverage_uncode_all_totalchildren) as percF$asValueCRI,
								";
							}
							elseif($vacc_to == 'total_children')
							{
								$queryForYearlyData .= "
								(select $coverage_detail_total from coverage_report_details where coverage_report_details.coverage_uncode_all_totalchildren=flcf1.uncode $fmonthCondition ) as T$asValueCRI,
								(select CASE WHEN $newbornMale > 0 OR $newbornFemale > 0 THEN round(($coverage_detail_total*100)/(NULLIF($newbornFemale,0) + NULLIF($newbornMale,0))) ELSE 0 END from coverage_report_details where coverage_report_details.coverage_uncode_all_totalchildren=flcf1.uncode $fmonthCondition group by coverage_report_details.coverage_uncode_all_totalchildren) as percT$asValueCRI,
								";
							}
						}						
					}
					else
					{
						if($in_out_coverage == 'in_uc' || $in_out_coverage == 'in_district'){
							if($vacc_to == 'gender' && $age_wise == 'all'){
								if($i==4){
									$coverage_detail_m='coalesce(sum(coverage_opv_i_m_all_genderwise),0)';
									$coverage_detail_f='coalesce(sum(coverage_opv_i_f_all_genderwise),0)';
								}else if($i==5){
									$coverage_detail_m='coalesce(sum(coverage_opv_ii_m_all_genderwise),0)';
									$coverage_detail_f='coalesce(sum(coverage_opv_ii_f_all_genderwise),0)';
								}else if($i==6){
									$coverage_detail_m='coalesce(sum(coverage_opv_iii_m_all_genderwise),0)';
									$coverage_detail_f='coalesce(sum(coverage_opv_iii_f_all_genderwise),0)';
								}else if($i==7){
									$coverage_detail_m='coalesce(sum(coverage_pentavalent_i_m_all_genderwise),0)';
									$coverage_detail_f='coalesce(sum(coverage_pentavalent_i_f_all_genderwise),0)';
								}else if($i==8){
									$coverage_detail_m='coalesce(sum(coverage_pentavalent_ii_m_all_genderwise),0)';
									$coverage_detail_f='coalesce(sum(coverage_pentavalent_ii_f_all_genderwise),0)';
								}else if($i==9){
									$coverage_detail_m='coalesce(sum(coverage_pentavalent_iii_m_all_genderwise),0)';
									$coverage_detail_f='coalesce(sum(coverage_pentavalent_iii_f_all_genderwise),0)';
								}else if($i==10){
									$coverage_detail_m='coalesce(sum(coverage_pcv10_i_m_all_genderwise),0)';
									$coverage_detail_f='coalesce(sum(coverage_pcv10_i_f_all_genderwise),0)';
								}else if($i==11){
									$coverage_detail_m='coalesce(sum(coverage_pcv10_ii_m_all_genderwise),0)';
									$coverage_detail_f='coalesce(sum(coverage_pcv10_ii_f_all_genderwise),0)';
								}else if($i==12){
									$coverage_detail_m='coalesce(sum(coverage_pcv10_iii_m_all_genderwise),0)';
									$coverage_detail_f='coalesce(sum(coverage_pcv10_iii_f_all_genderwise),0)';
								}else if($i==13){
									$coverage_detail_m='coalesce(sum(coverage_ipv_i_m_all_genderwise),0)';
									$coverage_detail_f='coalesce(sum(coverage_ipv_i_f_all_genderwise),0)';
								}else if($i==14){
									$coverage_detail_m='coalesce(sum(coverage_rota_i_m_all_genderwise),0)';
									$coverage_detail_f='coalesce(sum(coverage_rota_i_f_all_genderwise),0)';
								}else if($i==15){
									$coverage_detail_m='coalesce(sum(coverage_rota_ii_m_all_genderwise),0)';
									$coverage_detail_f='coalesce(sum(coverage_rota_ii_f_all_genderwise),0)';
								}else if($i==16){
									$coverage_detail_m='coalesce(sum(coverage_mr_i_m_all_genderwise),0)';
									$coverage_detail_f='coalesce(sum(coverage_mr_i_f_all_genderwise),0)';
								}else if($i==17){
									$coverage_detail_m='coalesce(sum(coverage_fully_immunized_m_all_genderwise),0)';
									$coverage_detail_f='coalesce(sum(coverage_fully_immunized_f_all_genderwise),0)';
								}else if($i==18){
									$coverage_detail_m='coalesce(sum(coverage_mr_ii_m_all_genderwise),0)';
									$coverage_detail_f='coalesce(sum(coverage_mr_ii_f_all_genderwise),0)';
								}else if($i==19){
									$coverage_detail_m='coalesce(sum(coverage_dtp_m_all_genderwise),0)';
									$coverage_detail_f='coalesce(sum(coverage_dtp_f_all_genderwise),0)';
								}else if($i==20){
									$coverage_detail_m='coalesce(sum(coverage_tcv_m_all_genderwise),0)';
									$coverage_detail_f='coalesce(sum(coverage_tcv_f_all_genderwise),0)';
								}else if($i==21){
									$coverage_detail_m='coalesce(sum(coverage_ipv_ii_m_all_genderwise),0)';
									$coverage_detail_f='coalesce(sum(coverage_ipv_ii_f_all_genderwise),0)';
								}
							}else if($vacc_to == 'gender' && $age_wise == '0to11'){
								if($i==4){
									$coverage_detail_m='coalesce(sum(coverage_opv_i_m_0_11_genderwise),0)';
									$coverage_detail_f='coalesce(sum(coverage_opv_i_f_0_11_genderwise),0)';
								}else if($i==5){
									$coverage_detail_m='coalesce(sum(coverage_opv_ii_m_0_11_genderwise),0)';
									$coverage_detail_f='coalesce(sum(coverage_opv_ii_f_0_11_genderwise),0)';
								}else if($i==6){
									$coverage_detail_m='coalesce(sum(coverage_opv_iii_m_0_11_genderwise),0)';
									$coverage_detail_f='coalesce(sum(coverage_opv_iii_f_0_11_genderwise),0)';
								}else if($i==7){
									$coverage_detail_m='coalesce(sum(coverage_pentavalent_i_m_0_11_genderwise),0)';
									$coverage_detail_f='coalesce(sum(coverage_pentavalent_i_f_0_11_genderwise),0)';
								}else if($i==8){
									$coverage_detail_m='coalesce(sum(coverage_pentavalent_ii_m_0_11_genderwise),0)';
									$coverage_detail_f='coalesce(sum(coverage_pentavalent_ii_f_0_11_genderwise),0)';
								}else if($i==9){
									$coverage_detail_m='coalesce(sum(coverage_pentavalent_iii_m_0_11_genderwise),0)';
									$coverage_detail_f='coalesce(sum(coverage_pentavalent_iii_f_0_11_genderwise),0)';
								}else if($i==10){
									$coverage_detail_m='coalesce(sum(coverage_pcv10_i_m_0_11_genderwise),0)';
									$coverage_detail_f='coalesce(sum(coverage_pcv10_i_f_0_11_genderwise),0)';
								}else if($i==11){
									$coverage_detail_m='coalesce(sum(coverage_pcv10_ii_m_0_11_genderwise),0)';
									$coverage_detail_f='coalesce(sum(coverage_pcv10_ii_f_0_11_genderwise),0)';
								}else if($i==12){
									$coverage_detail_m='coalesce(sum(coverage_pcv10_iii_m_0_11_genderwise),0)';
									$coverage_detail_f='coalesce(sum(coverage_pcv10_iii_f_0_11_genderwise),0)';
								}else if($i==13){
									$coverage_detail_m='coalesce(sum(coverage_ipv_i_m_0_11_genderwise),0)';
									$coverage_detail_f='coalesce(sum(coverage_ipv_i_f_0_11_genderwise),0)';
								}else if($i==14){
									$coverage_detail_m='coalesce(sum(coverage_rota_i_m_0_11_genderwise),0)';
									$coverage_detail_f='coalesce(sum(coverage_rota_i_f_0_11_genderwise),0)';
								}else if($i==15){
									$coverage_detail_m='coalesce(sum(coverage_rota_ii_m_0_11_genderwise),0)';
									$coverage_detail_f='coalesce(sum(coverage_rota_ii_f_0_11_genderwise),0)';
								}else if($i==16){
									$coverage_detail_m='coalesce(sum(coverage_mr_i_m_0_11_genderwise),0)';
									$coverage_detail_f='coalesce(sum(coverage_mr_i_f_0_11_genderwise),0)';
								}else if($i==17){
									$coverage_detail_m='coalesce(sum(coverage_fully_immunized_m_0_11_genderwise),0)';
									$coverage_detail_f='coalesce(sum(coverage_fully_immunized_f_0_11_genderwise),0)';
								}else if($i==18){
									$coverage_detail_m='coalesce(sum(coverage_mr_ii_m_0_11_genderwise),0)';
									$coverage_detail_f='coalesce(sum(coverage_mr_ii_f_0_11_genderwise),0)';
								}else if($i==19){
									$coverage_detail_m='coalesce(sum(coverage_dtp_m_0_11_genderwise),0)';
									$coverage_detail_f='coalesce(sum(coverage_dtp_f_0_11_genderwise),0)';
								}else if($i==20){
									$coverage_detail_m='coalesce(sum(coverage_tcv_m_0_11_genderwise),0)';
									$coverage_detail_f='coalesce(sum(coverage_tcv_f_0_11_genderwise),0)';
								}else if($i==21){
									$coverage_detail_m='coalesce(sum(coverage_ipv_ii_m_0_11_genderwise),0)';
									$coverage_detail_f='coalesce(sum(coverage_ipv_ii_f_0_11_genderwise),0)';
								}
							}else if($vacc_to == 'gender' && $age_wise == '12to23'){
								if($i==4){
									$coverage_detail_m='coalesce(sum(coverage_opv_i_m_12_23_genderwise),0)';
									$coverage_detail_f='coalesce(sum(coverage_opv_i_f_12_23_genderwise),0)';
								}else if($i==5){
									$coverage_detail_m='coalesce(sum(coverage_opv_ii_m_12_23_genderwise),0)';
									$coverage_detail_f='coalesce(sum(coverage_opv_ii_f_12_23_genderwise),0)';
								}else if($i==6){
									$coverage_detail_m='coalesce(sum(coverage_opv_iii_m_12_23_genderwise),0)';
									$coverage_detail_f='coalesce(sum(coverage_opv_iii_f_12_23_genderwise),0)';
								}else if($i==7){
									$coverage_detail_m='coalesce(sum(coverage_pentavalent_i_m_12_23_genderwise),0)';
									$coverage_detail_f='coalesce(sum(coverage_pentavalent_i_f_12_23_genderwise),0)';
								}else if($i==8){
									$coverage_detail_m='coalesce(sum(coverage_pentavalent_ii_m_12_23_genderwise),0)';
									$coverage_detail_f='coalesce(sum(coverage_pentavalent_ii_f_12_23_genderwise),0)';
								}else if($i==9){
									$coverage_detail_m='coalesce(sum(coverage_pentavalent_iii_m_12_23_genderwise),0)';
									$coverage_detail_f='coalesce(sum(coverage_pentavalent_iii_f_12_23_genderwise),0)';
								}else if($i==10){
									$coverage_detail_m='coalesce(sum(coverage_pcv10_i_m_12_23_genderwise),0)';
									$coverage_detail_f='coverage_pcv10_i_f_12_23_genderwise),0)';
								}else if($i==11){
									$coverage_detail_m='coalesce(sum(coverage_pcv10_ii_m_12_23_genderwise),0)';
									$coverage_detail_f='coalesce(sum(coverage_pcv10_ii_f_12_23_genderwise),0)';
								}else if($i==12){
									$coverage_detail_m='coalesce(sum(coverage_pcv10_iii_m_12_23_genderwise),0)';
									$coverage_detail_f='coalesce(sum(coverage_pcv10_iii_f_12_23_genderwise),0)';
								}else if($i==13){
									$coverage_detail_m='coalesce(sum(coverage_ipv_i_m_12_23_genderwise),0)';
									$coverage_detail_f='coalesce(sum(coverage_ipv_i_f_12_23_genderwise),0)';
								}else if($i==14){
									$coverage_detail_m='coalesce(sum(coverage_rota_i_m_12_23_genderwise),0)';
									$coverage_detail_f='coalesce(sum(coverage_rota_i_f_12_23_genderwise),0)';
								}else if($i==15){
									$coverage_detail_m='coalesce(sum(coverage_rota_ii_m_12_23_genderwise),0)';
									$coverage_detail_f='coalesce(sum(coverage_rota_ii_f_12_23_genderwise),0)';
								}else if($i==16){
									$coverage_detail_m='coalesce(sum(coverage_mr_i_m_12_23_genderwise),0)';
									$coverage_detail_f='coalesce(sum(coverage_mr_i_f_12_23_genderwise),0)';
								}else if($i==17){
									$coverage_detail_m='coalesce(sum(coverage_fully_immunized_m_12_23_genderwise),0)';
									$coverage_detail_f='coalesce(sum(coverage_fully_immunized_f_12_23_genderwise),0)';
								}else if($i==18){
									$coverage_detail_m='coalesce(sum(coverage_mr_ii_m_12_23_genderwise),0)';
									$coverage_detail_f='coalesce(sum(coverage_mr_ii_f_12_23_genderwise),0)';
								}else if($i==19){
									$coverage_detail_m='coalesce(sum(coverage_dtp_m_12_23_genderwise),0)';
									$coverage_detail_f='coalesce(sum(coverage_dtp_f_12_23_genderwise),0)';
								}else if($i==20){
									$coverage_detail_m='coalesce(sum(coverage_tcv_m_12_23_genderwise),0)';
									$coverage_detail_f='coalesce(sum(coverage_tcv_f_12_23_genderwise),0)';
								}else if($i==21){
									$coverage_detail_m='coalesce(sum(coverage_ipv_ii_m_12_23_genderwise),0)';
									$coverage_detail_f='coalesce(sum(coverage_ipv_ii_f_12_23_genderwise),0)';
								}
							}else if($vacc_to == 'gender' && $age_wise == 'above2'){
								if($i==4){
									$coverage_detail_m='coalesce(sum(coverage_opv_i_m_above_2_years_genderwise),0)';
									$coverage_detail_f='coalesce(sum(coverage_opv_i_f_above_2_years_genderwise),0)';
								}else if($i==5){
									$coverage_detail_m='coalesce(sum(coverage_opv_ii_m_above_2_years_genderwise),0)';
									$coverage_detail_f='coalesce(sum(coverage_opv_ii_f_above_2_years_genderwise),0)';
								}else if($i==6){
									$coverage_detail_m='coalesce(sum(coverage_opv_iii_m_above_2_years_genderwise),0)';
									$coverage_detail_f='coalesce(sum(coverage_opv_iii_f_above_2_years_genderwise),0)';
								}else if($i==7){
									$coverage_detail_m='coalesce(sum(coverage_pentavalent_i_m_above_2_years_genderwise),0)';
									$coverage_detail_f='coalesce(sum(coverage_pentavalent_i_f_above_2_years_genderwise),0)';
								}else if($i==8){
									$coverage_detail_m='coalesce(sum(coverage_pentavalent_ii_m_above_2_years_genderwise),0)';
									$coverage_detail_f='coalesce(sum(coverage_pentavalent_ii_f_above_2_years_genderwise),0)';
								}else if($i==9){
									$coverage_detail_m='coalesce(sum(coverage_pentavalent_iii_m_above_2_years_genderwise),0)';
									$coverage_detail_f='coalesce(sum(coverage_pentavalent_iii_f_above_2_years_genderwise),0)';
								}else if($i==10){
									$coverage_detail_m='coalesce(sum(coverage_pcv10_i_m_above_2_years_genderwise),0)';
									$coverage_detail_f='coalesce(sum(coverage_pcv10_i_f_above_2_years_genderwise),0)';
								}else if($i==11){
									$coverage_detail_m='coalesce(sum(coverage_pcv10_ii_m_above_2_years_genderwise),0)';
									$coverage_detail_f='coalesce(sum(coverage_pcv10_ii_f_above_2_years_genderwise),0)';
								}else if($i==12){
									$coverage_detail_m='coalesce(sum(coverage_pcv10_iii_m_above_2_years_genderwise),0)';
									$coverage_detail_f='coalesce(sum(coverage_pcv10_iii_f_above_2_years_genderwise),0)';
								}else if($i==13){
									$coverage_detail_m='coalesce(sum(coverage_ipv_i_m_above_2_years_genderwise),0)';
									$coverage_detail_f='coalesce(sum(coverage_ipv_i_f_above_2_years_genderwise),0)';
								}else if($i==14){
									$coverage_detail_m='coalesce(sum(coverage_rota_i_m_above_2_years_genderwise),0)';
									$coverage_detail_f='coalesce(sum(coverage_rota_i_f_above_2_years_genderwise),0)';
								}else if($i==15){
									$coverage_detail_m='coalesce(sum(coverage_rota_ii_m_above_2_years_genderwise),0)';
									$coverage_detail_f='coalesce(sum(coverage_rota_ii_f_above_2_years_genderwise),0)';
								}else if($i==16){
									$coverage_detail_m='coalesce(sum(coverage_mr_i_m_above_2_years_genderwise),0)';
									$coverage_detail_f='coalesce(sum(coverage_mr_i_f_above_2_years_genderwise),0)';
								}else if($i==17){
									$coverage_detail_m='coalesce(sum(coverage_fully_immunized_m_above_2_years_genderwise),0)';
									$coverage_detail_f='coalesce(sum(coverage_fully_immunized_f_above_2_years_genderwise),0)';
								}else if($i==18){
									$coverage_detail_m='coalesce(sum(coverage_mr_ii_m_above_2_years_genderwise),0)';
									$coverage_detail_f='coalesce(sum(coverage_mr_ii_f_above_2_years_genderwise),0)';
								}else if($i==19){
									$coverage_detail_m='coalesce(sum(coverage_dtp_m_above_2_years_genderwise),0)';
									$coverage_detail_f='coalesce(sum(coverage_dtp_f_above_2_years_genderwise),0)';
								}else if($i==20){
									$coverage_detail_m='coalesce(sum(coverage_tcv_m_above_2_years_genderwise),0)';
									$coverage_detail_f='coalesce(sum(coverage_tcv_f_above_2_years_genderwise),0)';
								}else if($i==21){
									$coverage_detail_m='coalesce(sum(coverage_ipv_ii_m_above_2_years_genderwise),0)';
									$coverage_detail_f='coalesce(sum(coverage_ipv_ii_f_above_2_years_genderwise),0)';
								}
							}else if($vacc_to == 'total_children' && $age_wise == 'all'){
								if($i==4){
									$coverage_detail_total='coalesce(sum(coverage_opv_i_total_all_totalchildren),0)';
								}else if($i==5){
									$coverage_detail_total='coalesce(sum(coverage_opv_ii_total_all_totalchildren),0)';
								}else if($i==6){
									$coverage_detail_total='coalesce(sum(coverage_opv_iii_total_all_totalchildren),0)';
								}else if($i==7){
									$coverage_detail_total='coalesce(sum(coverage_pentavalent_i_total_all_totalchildren),0)';
								}else if($i==8){
									$coverage_detail_total='coalesce(sum(coverage_pentavalent_ii_total_all_totalchildren),0)';
								}else if($i==9){
									$coverage_detail_total='coalesce(sum(coverage_pentavalent_iii_total_all_totalchildren),0)';
								}else if($i==10){
									$coverage_detail_total='coalesce(sum(coverage_pcv10_i_total_all_totalchildren),0)';
								}else if($i==11){
									$coverage_detail_total='coalesce(sum(coverage_pcv10_ii_total_all_totalchildren),0)';
								}else if($i==12){
									$coverage_detail_total='coalesce(sum(coverage_pcv10_iii_total_all_totalchildren),0)';
								}else if($i==13){
									$coverage_detail_total='coalesce(sum(coverage_ipv_i_total_all_totalchildren),0)';
								}else if($i==14){
									$coverage_detail_total='coalesce(sum(coverage_rota_i_total_all_totalchildren),0)';
								}else if($i==15){
									$coverage_detail_total='coalesce(sum(coverage_rota_ii_total_all_totalchildren),0)';
								}else if($i==16){
									$coverage_detail_total='coalesce(sum(coverage_mr_i_total_all_totalchildren),0)';
								}else if($i==17){
									$coverage_detail_total='coalesce(sum(coverage_fully_immunized_total_all_totalchildren),0)';
								}else if($i==18){
									$coverage_detail_total='coalesce(sum(coverage_mr_ii_total_all_totalchildren),0)';
								}else if($i==19){
									$coverage_detail_total='coalesce(sum(coverage_dtp_total_all_totalchildren),0)';
								}else if($i==20){
									$coverage_detail_total='coalesce(sum(coverage_tcv_total_all_totalchildren),0)';
								}else if($i==21){
									$coverage_detail_total='coalesce(sum(coverage_ipv_ii_total_all_totalchildren),0)';
								}
							}else if($vacc_to == 'total_children' && $age_wise == '0to11'){
								if($i==4){
									$coverage_detail_total='coalesce(sum(coverage_opv_i_total_0_11_totalchildren),0)';
								}else if($i==5){
									$coverage_detail_total='coalesce(sum(coverage_opv_ii_total_0_11_totalchildren),0)';
								}else if($i==6){
									$coverage_detail_total='coalesce(sum(coverage_opv_iii_total_0_11_totalchildren),0)';
								}else if($i==7){
									$coverage_detail_total='coalesce(sum(coverage_pentavalent_i_total_0_11_totalchildren),0)';
								}else if($i==8){
									$coverage_detail_total='coalesce(sum(coverage_pentavalent_ii_total_0_11_totalchildren),0)';
								}else if($i==9){
									$coverage_detail_total='coalesce(sum(coverage_pentavalent_iii_total_0_11_totalchildren),0)';
								}else if($i==10){
									$coverage_detail_total='coalesce(sum(coverage_pcv10_i_total_0_11_totalchildren),0)';
								}else if($i==11){
									$coverage_detail_total='coalesce(sum(coverage_pcv10_ii_total_0_11_totalchildren),0)';
								}else if($i==12){
									$coverage_detail_total='coalesce(sum(coverage_pcv10_iii_total_0_11_totalchildren),0)';
								}else if($i==13){
									$coverage_detail_total='coalesce(sum(coverage_ipv_i_total_0_11_totalchildren),0)';
								}else if($i==14){
									$coverage_detail_total='coalesce(sum(coverage_rota_i_total_0_11_totalchildren),0)';
								}else if($i==15){
									$coverage_detail_total='coalesce(sum(coverage_rota_ii_total_0_11_totalchildren),0)';
								}else if($i==16){
									$coverage_detail_total='coalesce(sum(coverage_mr_i_total_0_11_totalchildren),0)';
								}else if($i==17){
									$coverage_detail_total='coalesce(sum(coverage_fully_immunized_total_0_11_totalchildren),0)';
								}else if($i==18){
									$coverage_detail_total='coalesce(sum(coverage_mr_ii_total_0_11_totalchildren),0)';
								}else if($i==19){
									$coverage_detail_total='coalesce(sum(coverage_dtp_total_0_11_totalchildren),0)';
								}else if($i==20){
									$coverage_detail_total='coalesce(sum(coverage_tcv_total_0_11_totalchildren),0)';
								}else if($i==21){
									$coverage_detail_total='coalesce(sum(coverage_ipv_ii_total_0_11_totalchildren),0)';
								}
							}else if($vacc_to == 'total_children' && $age_wise == '12to23'){
								if($i==4){
									$coverage_detail_total='coalesce(sum(coverage_opv_i_total_12_23_totalchildren),0)';
								}else if($i==5){
									$coverage_detail_total='coalesce(sum(coverage_opv_ii_total_12_23_totalchildren),0)';
								}else if($i==6){
									$coverage_detail_total='coalesce(sum(coverage_opv_iii_total_12_23_totalchildren),0)';
								}else if($i==7){
									$coverage_detail_total='coalesce(sum(coverage_pentavalent_i_total_12_23_totalchildren),0)';
								}else if($i==8){
									$coverage_detail_total='coalesce(sum(coverage_pentavalent_ii_total_12_23_totalchildren),0)';
								}else if($i==9){
									$coverage_detail_total='coalesce(sum(coverage_pentavalent_iii_total_12_23_totalchildren),0)';
								}else if($i==10){
									$coverage_detail_total='coalesce(sum(coverage_pcv10_i_total_12_23_totalchildren),0)';
								}else if($i==11){
									$coverage_detail_total='coalesce(sum(coverage_pcv10_ii_total_12_23_totalchildren),0)';
								}else if($i==12){
									$coverage_detail_total='coalesce(sum(coverage_pcv10_iii_total_12_23_totalchildren),0)';
								}else if($i==13){
									$coverage_detail_total='coalesce(sum(coverage_ipv_i_total_12_23_totalchildren),0)';
								}else if($i==14){
									$coverage_detail_total='coalesce(sum(coverage_rota_i_total_12_23_totalchildren),0)';
								}else if($i==15){
									$coverage_detail_total='coalesce(sum(coverage_rota_ii_total_12_23_totalchildren),0)';
								}else if($i==16){
									$coverage_detail_total='coalesce(sum(coverage_mr_i_total_12_23_totalchildren),0)';
								}else if($i==17){
									$coverage_detail_total='coalesce(sum(coverage_fully_immunized_total_12_23_totalchildren),0)';
								}else if($i==18){
									$coverage_detail_total='coalesce(sum(coverage_mr_ii_total_12_23_totalchildren),0)';
								}else if($i==19){
									$coverage_detail_total='coalesce(sum(coverage_dtp_total_12_23_totalchildren),0)';
								}else if($i==20){
									$coverage_detail_total='coalesce(sum(coverage_tcv_total_12_23_totalchildren),0)';
								}else if($i==21){
									$coverage_detail_total='coalesce(sum(coverage_ipv_ii_total_12_23_totalchildren),0)';
								}
							}else if($vacc_to == 'total_children' && $age_wise == 'above2'){
								if($i==4){
									$coverage_detail_total='coalesce(sum(coverage_opv_i_total_above_2_years_totalchildren),0)';
								}else if($i==5){
									$coverage_detail_total='coalesce(sum(coverage_opv_ii_total_above_2_years_totalchildren),0)';
								}else if($i==6){
									$coverage_detail_total='coalesce(sum(coverage_opv_iii_total_above_2_years_totalchildren),0)';
								}else if($i==7){
									$coverage_detail_total='coalesce(sum(coverage_pentavalent_i_total_above_2_years_totalchildren),0)';
								}else if($i==8){
									$coverage_detail_total='coalesce(sum(coverage_pentavalent_ii_total_above_2_years_totalchildren),0)';
								}else if($i==9){
									$coverage_detail_total='coalesce(sum(coverage_pentavalent_iii_total_above_2_years_totalchildren),0)';
								}else if($i==10){
									$coverage_detail_total='coalesce(sum(coverage_pcv10_i_total_above_2_years_totalchildren),0)';
								}else if($i==11){
									$coverage_detail_total='coalesce(sum(coverage_pcv10_ii_total_above_2_years_totalchildren),0)';
								}else if($i==12){
									$coverage_detail_total='coalesce(sum(coverage_pcv10_iii_total_above_2_years_totalchildren),0)';
								}else if($i==13){
									$coverage_detail_total='coalesce(sum(coverage_ipv_i_total_above_2_years_totalchildren),0)';
								}else if($i==14){
									$coverage_detail_total='coalesce(sum(coverage_rota_i_total_above_2_years_totalchildren),0)';
								}else if($i==15){
									$coverage_detail_total='coalesce(sum(coverage_rota_ii_total_above_2_years_totalchildren),0)';
								}else if($i==16){
									$coverage_detail_total='coalesce(sum(coverage_mr_i_total_above_2_years_totalchildren),0)';
								}else if($i==17){
									$coverage_detail_total='coalesce(sum(coverage_fully_immunized_total_above_2_years_totalchildren),0)';
								}else if($i==18){
									$coverage_detail_total='coalesce(sum(coverage_mr_ii_total_above_2_years_totalchildren),0)';
								}else if($i==19){
									$coverage_detail_total='coalesce(sum(coverage_dtp_total_above_2_years_totalchildren),0)';
								}else if($i==20){
									$coverage_detail_total='coalesce(sum(coverage_tcv_total_above_2_years_totalchildren),0)';
								}else if($i==21){
									$coverage_detail_total='coalesce(sum(coverage_ipv_ii_total_above_2_years_totalchildren),0)';
								}
							}
							if($vacc_to == 'gender')
							{
								if($start_year >= 2021){
									//other uc
									if($i ==4){
										$ou_mcols_att ="+(select coalesce($ou_mcols,0) from monthly_outuc_coverage where monthly_outuc_coverage.uncode=fac_mvrf_db.uncode $monthly_ou_fmonthCondition and monthly_outuc_coverage.item_id='15' and monthly_outuc_coverage.antigen='1')";
										$ou_fcols_att ="+(select coalesce($ou_fcols,0) from monthly_outuc_coverage where monthly_outuc_coverage.uncode=fac_mvrf_db.uncode $monthly_ou_fmonthCondition and monthly_outuc_coverage.item_id='15' and monthly_outuc_coverage.antigen='1')";
									}else if($i==5){
										$ou_mcols_att ="+(select coalesce($ou_mcols,0) from monthly_outuc_coverage where monthly_outuc_coverage.uncode=fac_mvrf_db.uncode $monthly_ou_fmonthCondition and monthly_outuc_coverage.item_id='15' and monthly_outuc_coverage.antigen='2')";
										$ou_fcols_att ="+(select coalesce($ou_fcols,0) from monthly_outuc_coverage where monthly_outuc_coverage.uncode=fac_mvrf_db.uncode $monthly_ou_fmonthCondition and monthly_outuc_coverage.item_id='15' and monthly_outuc_coverage.antigen='2')";
									}else if($i==6){
										$ou_mcols_att ="+(select coalesce($ou_mcols,0) from monthly_outuc_coverage where monthly_outuc_coverage.uncode=fac_mvrf_db.uncode $monthly_ou_fmonthCondition and monthly_outuc_coverage.item_id='15' and monthly_outuc_coverage.antigen='3')";
										$ou_fcols_att ="+(select coalesce($ou_fcols,0) from monthly_outuc_coverage where monthly_outuc_coverage.uncode=fac_mvrf_db.uncode $monthly_ou_fmonthCondition and monthly_outuc_coverage.item_id='15' and monthly_outuc_coverage.antigen='3')";
									}else if($i==7){
										$ou_mcols_att ="+(select coalesce($ou_mcols,0) from monthly_outuc_coverage where monthly_outuc_coverage.uncode=fac_mvrf_db.uncode $monthly_ou_fmonthCondition and monthly_outuc_coverage.item_id='3' and monthly_outuc_coverage.antigen='1')";
										$ou_fcols_att ="+(select coalesce($ou_fcols,0) from monthly_outuc_coverage where monthly_outuc_coverage.uncode=fac_mvrf_db.uncode $monthly_ou_fmonthCondition and monthly_outuc_coverage.item_id='3' and monthly_outuc_coverage.antigen='1')";
									}else if($i==8){
										$ou_mcols_att ="+(select coalesce($ou_mcols,0) from monthly_outuc_coverage where monthly_outuc_coverage.uncode=fac_mvrf_db.uncode $monthly_ou_fmonthCondition and monthly_outuc_coverage.item_id='3' and monthly_outuc_coverage.antigen='2')";
										$ou_fcols_att ="+(select coalesce($ou_fcols,0) from monthly_outuc_coverage where monthly_outuc_coverage.uncode=fac_mvrf_db.uncode $monthly_ou_fmonthCondition and monthly_outuc_coverage.item_id='3' and monthly_outuc_coverage.antigen='2')";
									}else if($i==9){
										$ou_mcols_att ="+(select coalesce($ou_mcols,0) from monthly_outuc_coverage where monthly_outuc_coverage.uncode=fac_mvrf_db.uncode $monthly_ou_fmonthCondition and monthly_outuc_coverage.item_id='3' and monthly_outuc_coverage.antigen='3')";
										$ou_fcols_att ="+(select coalesce($ou_fcols,0) from monthly_outuc_coverage where monthly_outuc_coverage.uncode=fac_mvrf_db.uncode $monthly_ou_fmonthCondition and monthly_outuc_coverage.item_id='3' and monthly_outuc_coverage.antigen='3')";
									}else if($i==10){
										$ou_mcols_att ="+(select coalesce($ou_mcols,0) from monthly_outuc_coverage where monthly_outuc_coverage.uncode=fac_mvrf_db.uncode $monthly_ou_fmonthCondition and monthly_outuc_coverage.item_id='4' and monthly_outuc_coverage.antigen='1')";
										$ou_fcols_att ="+(select coalesce($ou_fcols,0) from monthly_outuc_coverage where monthly_outuc_coverage.uncode=fac_mvrf_db.uncode $monthly_ou_fmonthCondition and monthly_outuc_coverage.item_id='4' and monthly_outuc_coverage.antigen='1')";
									}else if($i==11){
										$ou_mcols_att ="+(select coalesce($ou_mcols,0) from monthly_outuc_coverage where monthly_outuc_coverage.uncode=fac_mvrf_db.uncode $monthly_ou_fmonthCondition and monthly_outuc_coverage.item_id='4' and monthly_outuc_coverage.antigen='2')";
										$ou_fcols_att ="+(select coalesce($ou_fcols,0) from monthly_outuc_coverage where monthly_outuc_coverage.uncode=fac_mvrf_db.uncode $monthly_ou_fmonthCondition and monthly_outuc_coverage.item_id='4' and monthly_outuc_coverage.antigen='2')";
									}else if($i==12){
										$ou_mcols_att ="+(select coalesce($ou_mcols,0) from monthly_outuc_coverage where monthly_outuc_coverage.uncode=fac_mvrf_db.uncode $monthly_ou_fmonthCondition and monthly_outuc_coverage.item_id='4' and monthly_outuc_coverage.antigen='3')";
										$ou_fcols_att ="+(select coalesce($ou_fcols,0) from monthly_outuc_coverage where monthly_outuc_coverage.uncode=fac_mvrf_db.uncode $monthly_ou_fmonthCondition and monthly_outuc_coverage.item_id='4' and monthly_outuc_coverage.antigen='3')";
									}else if($i==13){
										$ou_mcols_att ="+(select coalesce($ou_mcols,0) from monthly_outuc_coverage where monthly_outuc_coverage.uncode=fac_mvrf_db.uncode $monthly_ou_fmonthCondition and monthly_outuc_coverage.item_id='17' and monthly_outuc_coverage.antigen='1')";
										$ou_fcols_att ="+(select coalesce($ou_fcols,0) from monthly_outuc_coverage where monthly_outuc_coverage.uncode=fac_mvrf_db.uncode $monthly_ou_fmonthCondition and monthly_outuc_coverage.item_id='17' and monthly_outuc_coverage.antigen='1')";
									}else if($i==14){
										$ou_mcols_att ="+(select coalesce($ou_mcols,0) from monthly_outuc_coverage where monthly_outuc_coverage.uncode=fac_mvrf_db.uncode $monthly_ou_fmonthCondition and monthly_outuc_coverage.item_id='19' and monthly_outuc_coverage.antigen='1')";
										$ou_fcols_att ="+(select coalesce($ou_fcols,0) from monthly_outuc_coverage where monthly_outuc_coverage.uncode=fac_mvrf_db.uncode $monthly_ou_fmonthCondition and monthly_outuc_coverage.item_id='19' and monthly_outuc_coverage.antigen='1')";
									}else if($i==15){
										$ou_mcols_att ="+(select coalesce($ou_mcols,0) from monthly_outuc_coverage where monthly_outuc_coverage.uncode=fac_mvrf_db.uncode $monthly_ou_fmonthCondition and monthly_outuc_coverage.item_id='19' and monthly_outuc_coverage.antigen='2')";
										$ou_fcols_att ="+(select coalesce($ou_fcols,0) from monthly_outuc_coverage where monthly_outuc_coverage.uncode=fac_mvrf_db.uncode $monthly_ou_fmonthCondition and monthly_outuc_coverage.item_id='19' and monthly_outuc_coverage.antigen='2')";
									}else if($i==16){
										$ou_mcols_att ="+(select coalesce($ou_mcols,0) from monthly_outuc_coverage where monthly_outuc_coverage.uncode=fac_mvrf_db.uncode $monthly_ou_fmonthCondition and monthly_outuc_coverage.item_id='5' and monthly_outuc_coverage.antigen='1')";
										$ou_fcols_att ="+(select coalesce($ou_fcols,0) from monthly_outuc_coverage where monthly_outuc_coverage.uncode=fac_mvrf_db.uncode $monthly_ou_fmonthCondition and monthly_outuc_coverage.item_id='5' and monthly_outuc_coverage.antigen='1')";
									}else if($i==18){
										$ou_mcols_att ="+(select coalesce($ou_mcols,0) from monthly_outuc_coverage where monthly_outuc_coverage.uncode=fac_mvrf_db.uncode $monthly_ou_fmonthCondition and monthly_outuc_coverage.item_id='5' and monthly_outuc_coverage.antigen='2')";
										$ou_fcols_att ="+(select coalesce($ou_fcols,0) from monthly_outuc_coverage where monthly_outuc_coverage.uncode=fac_mvrf_db.uncode $monthly_ou_fmonthCondition and monthly_outuc_coverage.item_id='5' and monthly_outuc_coverage.antigen='2')";
									}else if($i==20){
										$ou_mcols_att ="+(select coalesce($ou_mcols,0) from monthly_outuc_coverage where monthly_outuc_coverage.uncode=fac_mvrf_db.uncode $monthly_ou_fmonthCondition and monthly_outuc_coverage.item_id='36' and monthly_outuc_coverage.antigen='1')";
										$ou_fcols_att ="+(select coalesce($ou_fcols,0) from monthly_outuc_coverage where monthly_outuc_coverage.uncode=fac_mvrf_db.uncode $monthly_ou_fmonthCondition and monthly_outuc_coverage.item_id='36' and monthly_outuc_coverage.antigen='1')";
									}else if($i==21){
										$ou_mcols_att ="+(select coalesce($ou_mcols,0) from monthly_outuc_coverage where monthly_outuc_coverage.uncode=fac_mvrf_db.uncode $monthly_ou_fmonthCondition and monthly_outuc_coverage.item_id='17' and monthly_outuc_coverage.antigen='2')";
										$ou_fcols_att ="+(select coalesce($ou_fcols,0) from monthly_outuc_coverage where monthly_outuc_coverage.uncode=fac_mvrf_db.uncode $monthly_ou_fmonthCondition and monthly_outuc_coverage.item_id='17' and monthly_outuc_coverage.antigen='2')";
									}else{
										$ou_mcols_att="";
										$ou_fcols_att="";
									}
								}else{
									$ou_mcols_att="";
									$ou_fcols_att="";
								}
								$queryForYearlyData .= "
								(select $coverage_detail_m from coverage_report_details where coverage_report_details.coverage_uncode_all_totalchildren=flcf1.uncode $fmonthCondition ) as M$asValueCRI,
								(select CASE WHEN $targetMaleChildren = 0 THEN 0 ELSE round(($coverage_detail_m*100)/NULLIF($targetMaleChildren,0)) END from coverage_report_details where coverage_report_details.coverage_uncode_all_totalchildren=flcf1.uncode $fmonthCondition group by coverage_report_details.coverage_uncode_all_totalchildren) as percM$asValueCRI,
								(select $coverage_detail_f from coverage_report_details where coverage_report_details.coverage_uncode_all_totalchildren=flcf1.uncode $fmonthCondition ) as F$asValueCRI,
								(select CASE WHEN $targetFeMaleChildren = 0 THEN 0 ELSE round(($coverage_detail_f*100)/NULLIF($targetFeMaleChildren,0)) END from coverage_report_details where coverage_report_details.coverage_uncode_all_totalchildren=flcf1.uncode $fmonthCondition group by coverage_report_details.coverage_uncode_all_totalchildren) as percF$asValueCRI,";
							}
							elseif($vacc_to == 'total_children')
							{
								if($start_year >= 2021){
									//other uc
									if($i ==4){
										$ou_tcols_att ="+(select coalesce($ou_tcols,0) from monthly_outuc_coverage where monthly_outuc_coverage.uncode=fac_mvrf_db.uncode $monthly_ou_fmonthCondition and monthly_outuc_coverage.item_id='15' and monthly_outuc_coverage.antigen='1')";
									}else if($i==5){
										$ou_tcols_att ="+(select coalesce($ou_tcols,0) from monthly_outuc_coverage where monthly_outuc_coverage.uncode=fac_mvrf_db.uncode $monthly_ou_fmonthCondition and monthly_outuc_coverage.item_id='15' and monthly_outuc_coverage.antigen='2')";
									}else if($i==6){
										$ou_tcols_att ="+(select coalesce($ou_tcols,0) from monthly_outuc_coverage where monthly_outuc_coverage.uncode=fac_mvrf_db.uncode $monthly_ou_fmonthCondition and monthly_outuc_coverage.item_id='15' and monthly_outuc_coverage.antigen='3')";
									}else if($i==7){
										$ou_tcols_att ="+(select coalesce($ou_tcols,0) from monthly_outuc_coverage where monthly_outuc_coverage.uncode=fac_mvrf_db.uncode $monthly_ou_fmonthCondition and monthly_outuc_coverage.item_id='3' and monthly_outuc_coverage.antigen='1')";
									}else if($i==8){
										$ou_tcols_att ="+(select coalesce($ou_tcols,0) from monthly_outuc_coverage where monthly_outuc_coverage.uncode=fac_mvrf_db.uncode $monthly_ou_fmonthCondition and monthly_outuc_coverage.item_id='3' and monthly_outuc_coverage.antigen='2')";
									}else if($i==9){
										$ou_tcols_att ="+(select coalesce($ou_tcols,0) from monthly_outuc_coverage where monthly_outuc_coverage.uncode=fac_mvrf_db.uncode $monthly_ou_fmonthCondition and monthly_outuc_coverage.item_id='3' and monthly_outuc_coverage.antigen='3')";
									}else if($i==10){
										$ou_tcols_att ="+(select coalesce($ou_tcols,0) from monthly_outuc_coverage where monthly_outuc_coverage.uncode=fac_mvrf_db.uncode $monthly_ou_fmonthCondition and monthly_outuc_coverage.item_id='4' and monthly_outuc_coverage.antigen='1')";
									}else if($i==11){
										$ou_tcols_att ="+(select coalesce($ou_tcols,0) from monthly_outuc_coverage where monthly_outuc_coverage.uncode=fac_mvrf_db.uncode $monthly_ou_fmonthCondition and monthly_outuc_coverage.item_id='4' and monthly_outuc_coverage.antigen='2')";
									}else if($i==12){
										$ou_tcols_att ="+(select coalesce($ou_tcols,0) from monthly_outuc_coverage where monthly_outuc_coverage.uncode=fac_mvrf_db.uncode $monthly_ou_fmonthCondition and monthly_outuc_coverage.item_id='4' and monthly_outuc_coverage.antigen='3')";
									}else if($i==13){
										$ou_tcols_att ="+(select coalesce($ou_tcols,0) from monthly_outuc_coverage where monthly_outuc_coverage.uncode=fac_mvrf_db.uncode $monthly_ou_fmonthCondition and monthly_outuc_coverage.item_id='17' and monthly_outuc_coverage.antigen='1')";
									}else if($i==14){
										$ou_tcols_att ="+(select coalesce($ou_tcols,0) from monthly_outuc_coverage where monthly_outuc_coverage.uncode=fac_mvrf_db.uncode $monthly_ou_fmonthCondition and monthly_outuc_coverage.item_id='19' and monthly_outuc_coverage.antigen='1')";
									}else if($i==15){
										$ou_tcols_att ="+(select coalesce($ou_tcols,0) from monthly_outuc_coverage where monthly_outuc_coverage.uncode=fac_mvrf_db.uncode $monthly_ou_fmonthCondition and monthly_outuc_coverage.item_id='19' and monthly_outuc_coverage.antigen='2')";
									}else if($i==16){
										$ou_tcols_att ="+(select coalesce($ou_tcols,0) from monthly_outuc_coverage where monthly_outuc_coverage.uncode=fac_mvrf_db.uncode $monthly_ou_fmonthCondition and monthly_outuc_coverage.item_id='5' and monthly_outuc_coverage.antigen='1')";
									}else if($i==18){
										$ou_tcols_att ="+(select coalesce($ou_tcols,0) from monthly_outuc_coverage where monthly_outuc_coverage.uncode=fac_mvrf_db.uncode $monthly_ou_fmonthCondition and monthly_outuc_coverage.item_id='5' and monthly_outuc_coverage.antigen='2')";
									}else if($i==20){
										$ou_tcols_att ="+(select coalesce($ou_tcols,0) from monthly_outuc_coverage where monthly_outuc_coverage.uncode=fac_mvrf_db.uncode $monthly_ou_fmonthCondition and monthly_outuc_coverage.item_id='36' and monthly_outuc_coverage.antigen='1')";
									}else if($i==21){
										$ou_tcols_att ="+(select coalesce($ou_tcols,0) from monthly_outuc_coverage where monthly_outuc_coverage.uncode=fac_mvrf_db.uncode $monthly_ou_fmonthCondition and monthly_outuc_coverage.item_id='17' and monthly_outuc_coverage.antigen='2')";
									}else{
										$ou_tcols_att="";
									}
								}else{
									$ou_tcols_att="";
								}
								$queryForYearlyData .= "
								(select $coverage_detail_total from coverage_report_details where coverage_report_details.coverage_uncode_all_totalchildren=flcf1.uncode $fmonthCondition ) as T$asValueCRI,
								(select CASE WHEN $targetMaleChildren > 0 OR $targetFeMaleChildren > 0 THEN round(($coverage_detail_total*100)/(NULLIF($targetFeMaleChildren,0) + NULLIF($targetMaleChildren,0))) ELSE 0 END from coverage_report_details where coverage_report_details.coverage_uncode_all_totalchildren=flcf1.uncode $fmonthCondition group by coverage_report_details.coverage_uncode_all_totalchildren) as percT$asValueCRI,";
							}							
						}
						else
						{ 
							if($in_out_coverage == 'total_ucs'){
								if($vacc_to == 'gender' && $age_wise == 'all'){
									if($i==4){
										$coverage_detail_m='coalesce(sum(own_opv_i_m_all_genderwise),0)';
										$coverage_detail_f='coalesce(sum(own_opv_i_f_all_genderwise),0)';
									}else if($i==5){
										$coverage_detail_m='coalesce(sum(own_opv_ii_m_all_genderwise),0)';
										$coverage_detail_f='coalesce(sum(own_opv_ii_f_all_genderwise),0)';
									}else if($i==6){
										$coverage_detail_m='coalesce(sum(own_opv_iii_m_all_genderwise),0)';
										$coverage_detail_f='coalesce(sum(own_opv_iii_f_all_genderwise),0)';
									}else if($i==7){
										$coverage_detail_m='coalesce(sum(own_pentavalent_i_m_all_genderwise),0)';
										$coverage_detail_f='coalesce(sum(own_pentavalent_i_f_all_genderwise),0)';
									}else if($i==8){
										$coverage_detail_m='coalesce(sum(own_pentavalent_ii_m_all_genderwise),0)';
										$coverage_detail_f='coalesce(sum(own_pentavalent_ii_f_all_genderwise),0)';
									}else if($i==9){
										$coverage_detail_m='coalesce(sum(own_pentavalent_iii_m_all_genderwise),0)';
										$coverage_detail_f='coalesce(sum(own_pentavalent_iii_f_all_genderwise),0)';
									}else if($i==10){
										$coverage_detail_m='coalesce(sum(own_pcv10_i_m_all_genderwise),0)';
										$coverage_detail_f='coalesce(sum(own_pcv10_i_f_all_genderwise),0)';
									}else if($i==11){
										$coverage_detail_m='coalesce(sum(own_pcv10_ii_m_all_genderwise),0)';
										$coverage_detail_f='coalesce(sum(own_pcv10_ii_f_all_genderwise),0)';
									}else if($i==12){
										$coverage_detail_m='coalesce(sum(own_pcv10_iii_m_all_genderwise),0)';
										$coverage_detail_f='coalesce(sum(own_pcv10_iii_f_all_genderwise),0)';
									}else if($i==13){
										$coverage_detail_m='coalesce(sum(own_ipv_i_m_all_genderwise),0)';
										$coverage_detail_f='coalesce(sum(own_ipv_i_f_all_genderwise),0)';
									}else if($i==14){
										$coverage_detail_m='coalesce(sum(own_rota_i_m_all_genderwise),0)';
										$coverage_detail_f='coalesce(sum(own_rota_i_f_all_genderwise),0)';
									}else if($i==15){
										$coverage_detail_m='coalesce(sum(own_rota_ii_m_all_genderwise),0)';
										$coverage_detail_f='coalesce(sum(own_rota_ii_f_all_genderwise),0)';
									}else if($i==16){
										$coverage_detail_m='coalesce(sum(own_mr_i_m_all_genderwise),0)';
										$coverage_detail_f='coalesce(sum(own_mr_i_f_all_genderwise),0)';
									}else if($i==17){
										$coverage_detail_m='coalesce(sum(own_fully_immunized_m_all_genderwise),0)';
										$coverage_detail_f='coalesce(sum(own_fully_immunized_f_all_genderwise),0)';
									}else if($i==18){
										$coverage_detail_m='coalesce(sum(own_mr_ii_m_all_genderwise),0)';
										$coverage_detail_f='coalesce(sum(own_mr_ii_f_all_genderwise),0)';
									}else if($i==19){
										$coverage_detail_m='coalesce(sum(own_dtp_m_all_genderwise),0)';
										$coverage_detail_f='coalesce(sum(own_dtp_f_all_genderwise),0)';
									}else if($i==20){
										$coverage_detail_m='coalesce(sum(own_tcv_m_all_genderwise),0)';
										$coverage_detail_f='coalesce(sum(own_tcv_f_all_genderwise),0)';
									}else if($i==21){
										$coverage_detail_m='coalesce(sum(own_ipv_ii_m_all_genderwise),0)';
										$coverage_detail_f='coalesce(sum(own_ipv_ii_f_all_genderwise),0)';
									}
								}else if($vacc_to == 'gender' && $age_wise == '0to11'){
									if($i==4){
										$coverage_detail_m='coalesce(sum(own_opv_i_m_0_11_genderwise),0)';
										$coverage_detail_f='coalesce(sum(own_opv_i_f_0_11_genderwise),0)';
									}else if($i==5){
										$coverage_detail_m='coalesce(sum(own_opv_ii_m_0_11_genderwise),0)';
										$coverage_detail_f='coalesce(sum(own_opv_ii_f_0_11_genderwise),0)';
									}else if($i==6){
										$coverage_detail_m='coalesce(sum(own_opv_iii_m_0_11_genderwise),0)';
										$coverage_detail_f='coalesce(sum(own_opv_iii_f_0_11_genderwise),0)';
									}else if($i==7){
										$coverage_detail_m='coalesce(sum(own_pentavalent_i_m_0_11_genderwise),0)';
										$coverage_detail_f='coalesce(sum(own_pentavalent_i_f_0_11_genderwise),0)';
									}else if($i==8){
										$coverage_detail_m='coalesce(sum(own_pentavalent_ii_m_0_11_genderwise),0)';
										$coverage_detail_f='coalesce(sum(own_pentavalent_ii_f_0_11_genderwise),0)';
									}else if($i==9){
										$coverage_detail_m='coalesce(sum(own_pentavalent_iii_m_0_11_genderwise),0)';
										$coverage_detail_f='coalesce(sum(own_pentavalent_iii_f_0_11_genderwise),0)';
									}else if($i==10){
										$coverage_detail_m='coalesce(sum(own_pcv10_i_m_0_11_genderwise),0)';
										$coverage_detail_f='coalesce(sum(own_pcv10_i_f_0_11_genderwise),0)';
									}else if($i==11){
										$coverage_detail_m='coalesce(sum(own_pcv10_ii_m_0_11_genderwise),0)';
										$coverage_detail_f='coalesce(sum(own_pcv10_ii_f_0_11_genderwise),0)';
									}else if($i==12){
										$coverage_detail_m='coalesce(sum(own_pcv10_iii_m_0_11_genderwise),0)';
										$coverage_detail_f='coalesce(sum(own_pcv10_iii_f_0_11_genderwise),0)';
									}else if($i==13){
										$coverage_detail_m='coalesce(sum(own_ipv_i_m_0_11_genderwise),0)';
										$coverage_detail_f='coalesce(sum(own_ipv_i_f_0_11_genderwise),0)';
									}else if($i==14){
										$coverage_detail_m='coalesce(sum(own_rota_i_m_0_11_genderwise),0)';
										$coverage_detail_f='coalesce(sum(own_rota_i_f_0_11_genderwise),0)';
									}else if($i==15){
										$coverage_detail_m='coalesce(sum(own_rota_ii_m_0_11_genderwise),0)';
										$coverage_detail_f='coalesce(sum(own_rota_ii_f_0_11_genderwise),0)';
									}else if($i==16){
										$coverage_detail_m='coalesce(sum(own_mr_i_m_0_11_genderwise),0)';
										$coverage_detail_f='coalesce(sum(own_mr_i_f_0_11_genderwise),0)';
									}else if($i==17){
										$coverage_detail_m='coalesce(sum(own_fully_immunized_m_0_11_genderwise),0)';
										$coverage_detail_f='coalesce(sum(own_fully_immunized_f_0_11_genderwise),0)';
									}else if($i==18){
										$coverage_detail_m='coalesce(sum(own_mr_ii_m_0_11_genderwise),0)';
										$coverage_detail_f='coalesce(sum(own_mr_ii_f_0_11_genderwise),0)';
									}else if($i==19){
										$coverage_detail_m='coalesce(sum(own_dtp_m_0_11_genderwise),0)';
										$coverage_detail_f='coalesce(sum(own_dtp_f_0_11_genderwise),0)';
									}else if($i==20){
										$coverage_detail_m='coalesce(sum(own_tcv_m_0_11_genderwise),0)';
										$coverage_detail_f='coalesce(sum(own_tcv_f_0_11_genderwise),0)';
									}else if($i==21){
										$coverage_detail_m='coalesce(sum(own_ipv_ii_m_0_11_genderwise),0)';
										$coverage_detail_f='coalesce(sum(own_ipv_ii_f_0_11_genderwise),0)';
									}
								}else if($vacc_to == 'gender' && $age_wise == '12to23'){
									if($i==4){
										$coverage_detail_m='coalesce(sum(own_opv_i_m_12_23_genderwise),0)';
										$coverage_detail_f='coalesce(sum(own_opv_i_f_12_23_genderwise),0)';
									}else if($i==5){
										$coverage_detail_m='coalesce(sum(own_opv_ii_m_12_23_genderwise),0)';
										$coverage_detail_f='coalesce(sum(own_opv_ii_f_12_23_genderwise),0)';
									}else if($i==6){
										$coverage_detail_m='coalesce(sum(own_opv_iii_m_12_23_genderwise),0)';
										$coverage_detail_f='coalesce(sum(own_opv_iii_f_12_23_genderwise),0)';
									}else if($i==7){
										$coverage_detail_m='coalesce(sum(own_pentavalent_i_m_12_23_genderwise),0)';
										$coverage_detail_f='coalesce(sum(own_pentavalent_i_f_12_23_genderwise),0)';
									}else if($i==8){
										$coverage_detail_m='coalesce(sum(own_pentavalent_ii_m_12_23_genderwise),0)';
										$coverage_detail_f='coalesce(sum(own_pentavalent_ii_f_12_23_genderwise),0)';
									}else if($i==9){
										$coverage_detail_m='coalesce(sum(own_pentavalent_iii_m_12_23_genderwise),0)';
										$coverage_detail_f='coalesce(sum(own_pentavalent_iii_f_12_23_genderwise),0)';
									}else if($i==10){
										$coverage_detail_m='coalesce(sum(own_pcv10_i_m_12_23_genderwise),0)';
										$coverage_detail_f='own_pcv10_i_f_12_23_genderwise),0)';
									}else if($i==11){
										$coverage_detail_m='coalesce(sum(own_pcv10_ii_m_12_23_genderwise),0)';
										$coverage_detail_f='coalesce(sum(own_pcv10_ii_f_12_23_genderwise),0)';
									}else if($i==12){
										$coverage_detail_m='coalesce(sum(own_pcv10_iii_m_12_23_genderwise),0)';
										$coverage_detail_f='coalesce(sum(own_pcv10_iii_f_12_23_genderwise),0)';
									}else if($i==13){
										$coverage_detail_m='coalesce(sum(own_ipv_i_m_12_23_genderwise),0)';
										$coverage_detail_f='coalesce(sum(own_ipv_i_f_12_23_genderwise),0)';
									}else if($i==14){
										$coverage_detail_m='coalesce(sum(own_rota_i_m_12_23_genderwise),0)';
										$coverage_detail_f='coalesce(sum(own_rota_i_f_12_23_genderwise),0)';
									}else if($i==15){
										$coverage_detail_m='coalesce(sum(own_rota_ii_m_12_23_genderwise),0)';
										$coverage_detail_f='coalesce(sum(own_rota_ii_f_12_23_genderwise),0)';
									}else if($i==16){
										$coverage_detail_m='coalesce(sum(own_mr_i_m_12_23_genderwise),0)';
										$coverage_detail_f='coalesce(sum(own_mr_i_f_12_23_genderwise),0)';
									}else if($i==17){
										$coverage_detail_m='coalesce(sum(own_fully_immunized_m_12_23_genderwise),0)';
										$coverage_detail_f='coalesce(sum(own_fully_immunized_f_12_23_genderwise),0)';
									}else if($i==18){
										$coverage_detail_m='coalesce(sum(own_mr_ii_m_12_23_genderwise),0)';
										$coverage_detail_f='coalesce(sum(own_mr_ii_f_12_23_genderwise),0)';
									}else if($i==19){
										$coverage_detail_m='coalesce(sum(own_dtp_m_12_23_genderwise),0)';
										$coverage_detail_f='coalesce(sum(own_dtp_f_12_23_genderwise),0)';
									}else if($i==20){
										$coverage_detail_m='coalesce(sum(own_tcv_m_12_23_genderwise),0)';
										$coverage_detail_f='coalesce(sum(own_tcv_f_12_23_genderwise),0)';
									}else if($i==21){
										$coverage_detail_m='coalesce(sum(own_ipv_ii_m_12_23_genderwise),0)';
										$coverage_detail_f='coalesce(sum(own_ipv_ii_f_12_23_genderwise),0)';
									}
								}else if($vacc_to == 'gender' && $age_wise == 'above2'){
									if($i==4){
										$coverage_detail_m='coalesce(sum(own_opv_i_m_above_2_years_genderwise),0)';
										$coverage_detail_f='coalesce(sum(own_opv_i_f_above_2_years_genderwise),0)';
									}else if($i==5){
										$coverage_detail_m='coalesce(sum(own_opv_ii_m_above_2_years_genderwise),0)';
										$coverage_detail_f='coalesce(sum(own_opv_ii_f_above_2_years_genderwise),0)';
									}else if($i==6){
										$coverage_detail_m='coalesce(sum(own_opv_iii_m_above_2_years_genderwise),0)';
										$coverage_detail_f='coalesce(sum(own_opv_iii_f_above_2_years_genderwise),0)';
									}else if($i==7){
										$coverage_detail_m='coalesce(sum(own_pentavalent_i_m_above_2_years_genderwise),0)';
										$coverage_detail_f='coalesce(sum(own_pentavalent_i_f_above_2_years_genderwise),0)';
									}else if($i==8){
										$coverage_detail_m='coalesce(sum(own_pentavalent_ii_m_above_2_years_genderwise),0)';
										$coverage_detail_f='coalesce(sum(own_pentavalent_ii_f_above_2_years_genderwise),0)';
									}else if($i==9){
										$coverage_detail_m='coalesce(sum(own_pentavalent_iii_m_above_2_years_genderwise),0)';
										$coverage_detail_f='coalesce(sum(own_pentavalent_iii_f_above_2_years_genderwise),0)';
									}else if($i==10){
										$coverage_detail_m='coalesce(sum(own_pcv10_i_m_above_2_years_genderwise),0)';
										$coverage_detail_f='coalesce(sum(own_pcv10_i_f_above_2_years_genderwise),0)';
									}else if($i==11){
										$coverage_detail_m='coalesce(sum(own_pcv10_ii_m_above_2_years_genderwise),0)';
										$coverage_detail_f='coalesce(sum(own_pcv10_ii_f_above_2_years_genderwise),0)';
									}else if($i==12){
										$coverage_detail_m='coalesce(sum(own_pcv10_iii_m_above_2_years_genderwise),0)';
										$coverage_detail_f='coalesce(sum(own_pcv10_iii_f_above_2_years_genderwise),0)';
									}else if($i==13){
										$coverage_detail_m='coalesce(sum(own_ipv_i_m_above_2_years_genderwise),0)';
										$coverage_detail_f='coalesce(sum(own_ipv_i_f_above_2_years_genderwise),0)';
									}else if($i==14){
										$coverage_detail_m='coalesce(sum(own_rota_i_m_above_2_years_genderwise),0)';
										$coverage_detail_f='coalesce(sum(own_rota_i_f_above_2_years_genderwise),0)';
									}else if($i==15){
										$coverage_detail_m='coalesce(sum(own_rota_ii_m_above_2_years_genderwise),0)';
										$coverage_detail_f='coalesce(sum(own_rota_ii_f_above_2_years_genderwise),0)';
									}else if($i==16){
										$coverage_detail_m='coalesce(sum(own_mr_i_m_above_2_years_genderwise),0)';
										$coverage_detail_f='coalesce(sum(own_mr_i_f_above_2_years_genderwise),0)';
									}else if($i==17){
										$coverage_detail_m='coalesce(sum(own_fully_immunized_m_above_2_years_genderwise),0)';
										$coverage_detail_f='coalesce(sum(own_fully_immunized_f_above_2_years_genderwise),0)';
									}else if($i==18){
										$coverage_detail_m='coalesce(sum(own_mr_ii_m_above_2_years_genderwise),0)';
										$coverage_detail_f='coalesce(sum(own_mr_ii_f_above_2_years_genderwise),0)';
									}else if($i==19){
										$coverage_detail_m='coalesce(sum(own_dtp_m_above_2_years_genderwise),0)';
										$coverage_detail_f='coalesce(sum(own_dtp_f_above_2_years_genderwise),0)';
									}else if($i==20){
										$coverage_detail_m='coalesce(sum(own_tcv_m_above_2_years_genderwise),0)';
										$coverage_detail_f='coalesce(sum(own_tcv_f_above_2_years_genderwise),0)';
									}else if($i==21){
										$coverage_detail_m='coalesce(sum(own_ipv_ii_m_above_2_years_genderwise),0)';
										$coverage_detail_f='coalesce(sum(own_ipv_ii_f_above_2_years_genderwise),0)';
									}
								}else if($vacc_to == 'total_children' && $age_wise == 'all'){
									if($i==4){
										$coverage_detail_total='coalesce(sum(own_opv_i_total_all_totalchildren),0)';
									}else if($i==5){
										$coverage_detail_total='coalesce(sum(own_opv_ii_total_all_totalchildren),0)';
									}else if($i==6){
										$coverage_detail_total='coalesce(sum(own_opv_iii_total_all_totalchildren),0)';
									}else if($i==7){
										$coverage_detail_total='coalesce(sum(own_pentavalent_i_total_all_totalchildren),0)';
									}else if($i==8){
										$coverage_detail_total='coalesce(sum(own_pentavalent_ii_total_all_totalchildren),0)';
									}else if($i==9){
										$coverage_detail_total='coalesce(sum(own_pentavalent_iii_total_all_totalchildren),0)';
									}else if($i==10){
										$coverage_detail_total='coalesce(sum(own_pcv10_i_total_all_totalchildren),0)';
									}else if($i==11){
										$coverage_detail_total='coalesce(sum(own_pcv10_ii_total_all_totalchildren),0)';
									}else if($i==12){
										$coverage_detail_total='coalesce(sum(own_pcv10_iii_total_all_totalchildren),0)';
									}else if($i==13){
										$coverage_detail_total='coalesce(sum(own_ipv_i_total_all_totalchildren),0)';
									}else if($i==14){
										$coverage_detail_total='coalesce(sum(own_rota_i_total_all_totalchildren),0)';
									}else if($i==15){
										$coverage_detail_total='coalesce(sum(own_rota_ii_total_all_totalchildren),0)';
									}else if($i==16){
										$coverage_detail_total='coalesce(sum(own_mr_i_total_all_totalchildren),0)';
									}else if($i==17){
										$coverage_detail_total='coalesce(sum(own_fully_immunized_total_all_totalchildren),0)';
									}else if($i==18){
										$coverage_detail_total='coalesce(sum(own_mr_ii_total_all_totalchildren),0)';
									}else if($i==19){
										$coverage_detail_total='coalesce(sum(own_dtp_total_all_totalchildren),0)';
									}else if($i==20){
										$coverage_detail_total='coalesce(sum(own_tcv_total_all_totalchildren),0)';
									}else if($i==21){
										$coverage_detail_total='coalesce(sum(own_ipv_ii_total_all_totalchildren),0)';
									}
								}else if($vacc_to == 'total_children' && $age_wise == '0to11'){
									if($i==4){
										$coverage_detail_total='coalesce(sum(own_opv_i_total_0_11_totalchildren),0)';
									}else if($i==5){
										$coverage_detail_total='coalesce(sum(own_opv_ii_total_0_11_totalchildren),0)';
									}else if($i==6){
										$coverage_detail_total='coalesce(sum(own_opv_iii_total_0_11_totalchildren),0)';
									}else if($i==7){
										$coverage_detail_total='coalesce(sum(own_pentavalent_i_total_0_11_totalchildren),0)';
									}else if($i==8){
										$coverage_detail_total='coalesce(sum(own_pentavalent_ii_total_0_11_totalchildren),0)';
									}else if($i==9){
										$coverage_detail_total='coalesce(sum(own_pentavalent_iii_total_0_11_totalchildren),0)';
									}else if($i==10){
										$coverage_detail_total='coalesce(sum(own_pcv10_i_total_0_11_totalchildren),0)';
									}else if($i==11){
										$coverage_detail_total='coalesce(sum(own_pcv10_ii_total_0_11_totalchildren),0)';
									}else if($i==12){
										$coverage_detail_total='coalesce(sum(own_pcv10_iii_total_0_11_totalchildren),0)';
									}else if($i==13){
										$coverage_detail_total='coalesce(sum(own_ipv_i_total_0_11_totalchildren),0)';
									}else if($i==14){
										$coverage_detail_total='coalesce(sum(own_rota_i_total_0_11_totalchildren),0)';
									}else if($i==15){
										$coverage_detail_total='coalesce(sum(own_rota_ii_total_0_11_totalchildren),0)';
									}else if($i==16){
										$coverage_detail_total='coalesce(sum(own_mr_i_total_0_11_totalchildren),0)';
									}else if($i==17){
										$coverage_detail_total='coalesce(sum(own_fully_immunized_total_0_11_totalchildren),0)';
									}else if($i==18){
										$coverage_detail_total='coalesce(sum(own_mr_ii_total_0_11_totalchildren),0)';
									}else if($i==19){
										$coverage_detail_total='coalesce(sum(own_dtp_total_0_11_totalchildren),0)';
									}else if($i==20){
										$coverage_detail_total='coalesce(sum(own_tcv_total_0_11_totalchildren),0)';
									}else if($i==21){
										$coverage_detail_total='coalesce(sum(own_ipv_ii_total_0_11_totalchildren),0)';
									}
								}else if($vacc_to == 'total_children' && $age_wise == '12to23'){
									if($i==4){
										$coverage_detail_total='coalesce(sum(own_opv_i_total_12_23_totalchildren),0)';
									}else if($i==5){
										$coverage_detail_total='coalesce(sum(own_opv_ii_total_12_23_totalchildren),0)';
									}else if($i==6){
										$coverage_detail_total='coalesce(sum(own_opv_iii_total_12_23_totalchildren),0)';
									}else if($i==7){
										$coverage_detail_total='coalesce(sum(own_pentavalent_i_total_12_23_totalchildren),0)';
									}else if($i==8){
										$coverage_detail_total='coalesce(sum(own_pentavalent_ii_total_12_23_totalchildren),0)';
									}else if($i==9){
										$coverage_detail_total='coalesce(sum(own_pentavalent_iii_total_12_23_totalchildren),0)';
									}else if($i==10){
										$coverage_detail_total='coalesce(sum(own_pcv10_i_total_12_23_totalchildren),0)';
									}else if($i==11){
										$coverage_detail_total='coalesce(sum(own_pcv10_ii_total_12_23_totalchildren),0)';
									}else if($i==12){
										$coverage_detail_total='coalesce(sum(own_pcv10_iii_total_12_23_totalchildren),0)';
									}else if($i==13){
										$coverage_detail_total='coalesce(sum(own_ipv_i_total_12_23_totalchildren),0)';
									}else if($i==14){
										$coverage_detail_total='coalesce(sum(own_rota_i_total_12_23_totalchildren),0)';
									}else if($i==15){
										$coverage_detail_total='coalesce(sum(own_rota_ii_total_12_23_totalchildren),0)';
									}else if($i==16){
										$coverage_detail_total='coalesce(sum(own_mr_i_total_12_23_totalchildren),0)';
									}else if($i==17){
										$coverage_detail_total='coalesce(sum(own_fully_immunized_total_12_23_totalchildren),0)';
									}else if($i==18){
										$coverage_detail_total='coalesce(sum(own_mr_ii_total_12_23_totalchildren),0)';
									}else if($i==19){
										$coverage_detail_total='coalesce(sum(own_dtp_total_12_23_totalchildren),0)';
									}else if($i==20){
										$coverage_detail_total='coalesce(sum(own_tcv_total_12_23_totalchildren),0)';
									}else if($i==21){
										$coverage_detail_total='coalesce(sum(own_ipv_ii_total_12_23_totalchildren),0)';
									}
								}else if($vacc_to == 'total_children' && $age_wise == 'above2'){
									if($i==4){
										$coverage_detail_total='coalesce(sum(own_opv_i_total_above_2_years_totalchildren),0)';
									}else if($i==5){
										$coverage_detail_total='coalesce(sum(own_opv_ii_total_above_2_years_totalchildren),0)';
									}else if($i==6){
										$coverage_detail_total='coalesce(sum(own_opv_iii_total_above_2_years_totalchildren),0)';
									}else if($i==7){
										$coverage_detail_total='coalesce(sum(own_pentavalent_i_total_above_2_years_totalchildren),0)';
									}else if($i==8){
										$coverage_detail_total='coalesce(sum(own_pentavalent_ii_total_above_2_years_totalchildren),0)';
									}else if($i==9){
										$coverage_detail_total='coalesce(sum(own_pentavalent_iii_total_above_2_years_totalchildren),0)';
									}else if($i==10){
										$coverage_detail_total='coalesce(sum(own_pcv10_i_total_above_2_years_totalchildren),0)';
									}else if($i==11){
										$coverage_detail_total='coalesce(sum(own_pcv10_ii_total_above_2_years_totalchildren),0)';
									}else if($i==12){
										$coverage_detail_total='coalesce(sum(own_pcv10_iii_total_above_2_years_totalchildren),0)';
									}else if($i==13){
										$coverage_detail_total='coalesce(sum(own_ipv_i_total_above_2_years_totalchildren),0)';
									}else if($i==14){
										$coverage_detail_total='coalesce(sum(own_rota_i_total_above_2_years_totalchildren),0)';
									}else if($i==15){
										$coverage_detail_total='coalesce(sum(own_rota_ii_total_above_2_years_totalchildren),0)';
									}else if($i==16){
										$coverage_detail_total='coalesce(sum(own_mr_i_total_above_2_years_totalchildren),0)';
									}else if($i==17){
										$coverage_detail_total='coalesce(sum(own_fully_immunized_total_above_2_years_totalchildren),0)';
									}else if($i==18){
										$coverage_detail_total='coalesce(sum(own_mr_ii_total_above_2_years_totalchildren),0)';
									}else if($i==19){
										$coverage_detail_total='coalesce(sum(own_dtp_total_above_2_years_totalchildren),0)';
									}else if($i==20){
										$coverage_detail_total='coalesce(sum(own_tcv_total_above_2_years_totalchildren),0)';
									}else if($i==21){
										$coverage_detail_total='coalesce(sum(own_ipv_ii_total_above_2_years_totalchildren),0)';
									}
								}
							}else{
								if($vacc_to == 'gender' && $age_wise == 'all'){
									if($i==4){
										$coverage_detail_m='coalesce(sum(others_opv_i_m_all_genderwise),0)';
										$coverage_detail_f='coalesce(sum(others_opv_i_f_all_genderwise),0)';
									}else if($i==5){
										$coverage_detail_m='coalesce(sum(others_opv_ii_m_all_genderwise),0)';
										$coverage_detail_f='coalesce(sum(others_opv_ii_f_all_genderwise),0)';
									}else if($i==6){
										$coverage_detail_m='coalesce(sum(others_opv_iii_m_all_genderwise),0)';
										$coverage_detail_f='coalesce(sum(others_opv_iii_f_all_genderwise),0)';
									}else if($i==7){
										$coverage_detail_m='coalesce(sum(others_pentavalent_i_m_all_genderwise),0)';
										$coverage_detail_f='coalesce(sum(others_pentavalent_i_f_all_genderwise),0)';
									}else if($i==8){
										$coverage_detail_m='coalesce(sum(others_pentavalent_ii_m_all_genderwise),0)';
										$coverage_detail_f='coalesce(sum(others_pentavalent_ii_f_all_genderwise),0)';
									}else if($i==9){
										$coverage_detail_m='coalesce(sum(others_pentavalent_iii_m_all_genderwise),0)';
										$coverage_detail_f='coalesce(sum(others_pentavalent_iii_f_all_genderwise),0)';
									}else if($i==10){
										$coverage_detail_m='coalesce(sum(others_pcv10_i_m_all_genderwise),0)';
										$coverage_detail_f='coalesce(sum(others_pcv10_i_f_all_genderwise),0)';
									}else if($i==11){
										$coverage_detail_m='coalesce(sum(others_pcv10_ii_m_all_genderwise),0)';
										$coverage_detail_f='coalesce(sum(others_pcv10_ii_f_all_genderwise),0)';
									}else if($i==12){
										$coverage_detail_m='coalesce(sum(others_pcv10_iii_m_all_genderwise),0)';
										$coverage_detail_f='coalesce(sum(others_pcv10_iii_f_all_genderwise),0)';
									}else if($i==13){
										$coverage_detail_m='coalesce(sum(others_ipv_i_m_all_genderwise),0)';
										$coverage_detail_f='coalesce(sum(others_ipv_i_f_all_genderwise),0)';
									}else if($i==14){
										$coverage_detail_m='coalesce(sum(others_rota_i_m_all_genderwise),0)';
										$coverage_detail_f='coalesce(sum(others_rota_i_f_all_genderwise),0)';
									}else if($i==15){
										$coverage_detail_m='coalesce(sum(others_rota_ii_m_all_genderwise),0)';
										$coverage_detail_f='coalesce(sum(others_rota_ii_f_all_genderwise),0)';
									}else if($i==16){
										$coverage_detail_m='coalesce(sum(others_mr_i_m_all_genderwise),0)';
										$coverage_detail_f='coalesce(sum(others_mr_i_f_all_genderwise),0)';
									}else if($i==17){
										$coverage_detail_m='coalesce(sum(others_fully_immunized_m_all_genderwise),0)';
										$coverage_detail_f='coalesce(sum(others_fully_immunized_f_all_genderwise),0)';
									}else if($i==18){
										$coverage_detail_m='coalesce(sum(others_mr_ii_m_all_genderwise),0)';
										$coverage_detail_f='coalesce(sum(others_mr_ii_f_all_genderwise),0)';
									}else if($i==19){
										$coverage_detail_m='coalesce(sum(others_dtp_m_all_genderwise),0)';
										$coverage_detail_f='coalesce(sum(others_dtp_f_all_genderwise),0)';
									}else if($i==20){
										$coverage_detail_m='coalesce(sum(others_tcv_m_all_genderwise),0)';
										$coverage_detail_f='coalesce(sum(others_tcv_f_all_genderwise),0)';
									}else if($i==21){
										$coverage_detail_m='coalesce(sum(others_ipv_ii_m_all_genderwise),0)';
										$coverage_detail_f='coalesce(sum(others_ipv_ii_f_all_genderwise),0)';
									}
								}else if($vacc_to == 'gender' && $age_wise == '0to11'){
									if($i==4){
										$coverage_detail_m='coalesce(sum(others_opv_i_m_0_11_genderwise),0)';
										$coverage_detail_f='coalesce(sum(others_opv_i_f_0_11_genderwise),0)';
									}else if($i==5){
										$coverage_detail_m='coalesce(sum(others_opv_ii_m_0_11_genderwise),0)';
										$coverage_detail_f='coalesce(sum(others_opv_ii_f_0_11_genderwise),0)';
									}else if($i==6){
										$coverage_detail_m='coalesce(sum(others_opv_iii_m_0_11_genderwise),0)';
										$coverage_detail_f='coalesce(sum(others_opv_iii_f_0_11_genderwise),0)';
									}else if($i==7){
										$coverage_detail_m='coalesce(sum(others_pentavalent_i_m_0_11_genderwise),0)';
										$coverage_detail_f='coalesce(sum(others_pentavalent_i_f_0_11_genderwise),0)';
									}else if($i==8){
										$coverage_detail_m='coalesce(sum(others_pentavalent_ii_m_0_11_genderwise),0)';
										$coverage_detail_f='coalesce(sum(others_pentavalent_ii_f_0_11_genderwise),0)';
									}else if($i==9){
										$coverage_detail_m='coalesce(sum(others_pentavalent_iii_m_0_11_genderwise),0)';
										$coverage_detail_f='coalesce(sum(others_pentavalent_iii_f_0_11_genderwise),0)';
									}else if($i==10){
										$coverage_detail_m='coalesce(sum(others_pcv10_i_m_0_11_genderwise),0)';
										$coverage_detail_f='coalesce(sum(others_pcv10_i_f_0_11_genderwise),0)';
									}else if($i==11){
										$coverage_detail_m='coalesce(sum(others_pcv10_ii_m_0_11_genderwise),0)';
										$coverage_detail_f='coalesce(sum(others_pcv10_ii_f_0_11_genderwise),0)';
									}else if($i==12){
										$coverage_detail_m='coalesce(sum(others_pcv10_iii_m_0_11_genderwise),0)';
										$coverage_detail_f='coalesce(sum(others_pcv10_iii_f_0_11_genderwise),0)';
									}else if($i==13){
										$coverage_detail_m='coalesce(sum(others_ipv_i_m_0_11_genderwise),0)';
										$coverage_detail_f='coalesce(sum(others_ipv_i_f_0_11_genderwise),0)';
									}else if($i==14){
										$coverage_detail_m='coalesce(sum(others_rota_i_m_0_11_genderwise),0)';
										$coverage_detail_f='coalesce(sum(others_rota_i_f_0_11_genderwise),0)';
									}else if($i==15){
										$coverage_detail_m='coalesce(sum(others_rota_ii_m_0_11_genderwise),0)';
										$coverage_detail_f='coalesce(sum(others_rota_ii_f_0_11_genderwise),0)';
									}else if($i==16){
										$coverage_detail_m='coalesce(sum(others_mr_i_m_0_11_genderwise),0)';
										$coverage_detail_f='coalesce(sum(others_mr_i_f_0_11_genderwise),0)';
									}else if($i==17){
										$coverage_detail_m='coalesce(sum(others_fully_immunized_m_0_11_genderwise),0)';
										$coverage_detail_f='coalesce(sum(others_fully_immunized_f_0_11_genderwise),0)';
									}else if($i==18){
										$coverage_detail_m='coalesce(sum(others_mr_ii_m_0_11_genderwise),0)';
										$coverage_detail_f='coalesce(sum(others_mr_ii_f_0_11_genderwise),0)';
									}else if($i==19){
										$coverage_detail_m='coalesce(sum(others_dtp_m_0_11_genderwise),0)';
										$coverage_detail_f='coalesce(sum(others_dtp_f_0_11_genderwise),0)';
									}else if($i==20){
										$coverage_detail_m='coalesce(sum(others_tcv_m_0_11_genderwise),0)';
										$coverage_detail_f='coalesce(sum(others_tcv_f_0_11_genderwise),0)';
									}else if($i==21){
										$coverage_detail_m='coalesce(sum(others_ipv_ii_m_0_11_genderwise),0)';
										$coverage_detail_f='coalesce(sum(others_ipv_ii_f_0_11_genderwise),0)';
									}
								}else if($vacc_to == 'gender' && $age_wise == '12to23'){
									if($i==4){
										$coverage_detail_m='coalesce(sum(others_opv_i_m_12_23_genderwise),0)';
										$coverage_detail_f='coalesce(sum(others_opv_i_f_12_23_genderwise),0)';
									}else if($i==5){
										$coverage_detail_m='coalesce(sum(others_opv_ii_m_12_23_genderwise),0)';
										$coverage_detail_f='coalesce(sum(others_opv_ii_f_12_23_genderwise),0)';
									}else if($i==6){
										$coverage_detail_m='coalesce(sum(others_opv_iii_m_12_23_genderwise),0)';
										$coverage_detail_f='coalesce(sum(others_opv_iii_f_12_23_genderwise),0)';
									}else if($i==7){
										$coverage_detail_m='coalesce(sum(others_pentavalent_i_m_12_23_genderwise),0)';
										$coverage_detail_f='coalesce(sum(others_pentavalent_i_f_12_23_genderwise),0)';
									}else if($i==8){
										$coverage_detail_m='coalesce(sum(others_pentavalent_ii_m_12_23_genderwise),0)';
										$coverage_detail_f='coalesce(sum(others_pentavalent_ii_f_12_23_genderwise),0)';
									}else if($i==9){
										$coverage_detail_m='coalesce(sum(others_pentavalent_iii_m_12_23_genderwise),0)';
										$coverage_detail_f='coalesce(sum(others_pentavalent_iii_f_12_23_genderwise),0)';
									}else if($i==10){
										$coverage_detail_m='coalesce(sum(others_pcv10_i_m_12_23_genderwise),0)';
										$coverage_detail_f='others_pcv10_i_f_12_23_genderwise),0)';
									}else if($i==11){
										$coverage_detail_m='coalesce(sum(others_pcv10_ii_m_12_23_genderwise),0)';
										$coverage_detail_f='coalesce(sum(others_pcv10_ii_f_12_23_genderwise),0)';
									}else if($i==12){
										$coverage_detail_m='coalesce(sum(others_pcv10_iii_m_12_23_genderwise),0)';
										$coverage_detail_f='coalesce(sum(others_pcv10_iii_f_12_23_genderwise),0)';
									}else if($i==13){
										$coverage_detail_m='coalesce(sum(others_ipv_i_m_12_23_genderwise),0)';
										$coverage_detail_f='coalesce(sum(others_ipv_i_f_12_23_genderwise),0)';
									}else if($i==14){
										$coverage_detail_m='coalesce(sum(others_rota_i_m_12_23_genderwise),0)';
										$coverage_detail_f='coalesce(sum(others_rota_i_f_12_23_genderwise),0)';
									}else if($i==15){
										$coverage_detail_m='coalesce(sum(others_rota_ii_m_12_23_genderwise),0)';
										$coverage_detail_f='coalesce(sum(others_rota_ii_f_12_23_genderwise),0)';
									}else if($i==16){
										$coverage_detail_m='coalesce(sum(others_mr_i_m_12_23_genderwise),0)';
										$coverage_detail_f='coalesce(sum(others_mr_i_f_12_23_genderwise),0)';
									}else if($i==17){
										$coverage_detail_m='coalesce(sum(others_fully_immunized_m_12_23_genderwise),0)';
										$coverage_detail_f='coalesce(sum(others_fully_immunized_f_12_23_genderwise),0)';
									}else if($i==18){
										$coverage_detail_m='coalesce(sum(others_mr_ii_m_12_23_genderwise),0)';
										$coverage_detail_f='coalesce(sum(others_mr_ii_f_12_23_genderwise),0)';
									}else if($i==19){
										$coverage_detail_m='coalesce(sum(others_dtp_m_12_23_genderwise),0)';
										$coverage_detail_f='coalesce(sum(others_dtp_f_12_23_genderwise),0)';
									}else if($i==20){
										$coverage_detail_m='coalesce(sum(others_tcv_m_12_23_genderwise),0)';
										$coverage_detail_f='coalesce(sum(others_tcv_f_12_23_genderwise),0)';
									}else if($i==21){
										$coverage_detail_m='coalesce(sum(others_ipv_ii_m_12_23_genderwise),0)';
										$coverage_detail_f='coalesce(sum(others_ipv_ii_f_12_23_genderwise),0)';
									}
								}else if($vacc_to == 'gender' && $age_wise == 'above2'){
									if($i==4){
										$coverage_detail_m='coalesce(sum(others_opv_i_m_above_2_years_genderwise),0)';
										$coverage_detail_f='coalesce(sum(others_opv_i_f_above_2_years_genderwise),0)';
									}else if($i==5){
										$coverage_detail_m='coalesce(sum(others_opv_ii_m_above_2_years_genderwise),0)';
										$coverage_detail_f='coalesce(sum(others_opv_ii_f_above_2_years_genderwise),0)';
									}else if($i==6){
										$coverage_detail_m='coalesce(sum(others_opv_iii_m_above_2_years_genderwise),0)';
										$coverage_detail_f='coalesce(sum(others_opv_iii_f_above_2_years_genderwise),0)';
									}else if($i==7){
										$coverage_detail_m='coalesce(sum(others_pentavalent_i_m_above_2_years_genderwise),0)';
										$coverage_detail_f='coalesce(sum(others_pentavalent_i_f_above_2_years_genderwise),0)';
									}else if($i==8){
										$coverage_detail_m='coalesce(sum(others_pentavalent_ii_m_above_2_years_genderwise),0)';
										$coverage_detail_f='coalesce(sum(others_pentavalent_ii_f_above_2_years_genderwise),0)';
									}else if($i==9){
										$coverage_detail_m='coalesce(sum(others_pentavalent_iii_m_above_2_years_genderwise),0)';
										$coverage_detail_f='coalesce(sum(others_pentavalent_iii_f_above_2_years_genderwise),0)';
									}else if($i==10){
										$coverage_detail_m='coalesce(sum(others_pcv10_i_m_above_2_years_genderwise),0)';
										$coverage_detail_f='coalesce(sum(others_pcv10_i_f_above_2_years_genderwise),0)';
									}else if($i==11){
										$coverage_detail_m='coalesce(sum(others_pcv10_ii_m_above_2_years_genderwise),0)';
										$coverage_detail_f='coalesce(sum(others_pcv10_ii_f_above_2_years_genderwise),0)';
									}else if($i==12){
										$coverage_detail_m='coalesce(sum(others_pcv10_iii_m_above_2_years_genderwise),0)';
										$coverage_detail_f='coalesce(sum(others_pcv10_iii_f_above_2_years_genderwise),0)';
									}else if($i==13){
										$coverage_detail_m='coalesce(sum(others_ipv_i_m_above_2_years_genderwise),0)';
										$coverage_detail_f='coalesce(sum(others_ipv_i_f_above_2_years_genderwise),0)';
									}else if($i==14){
										$coverage_detail_m='coalesce(sum(others_rota_i_m_above_2_years_genderwise),0)';
										$coverage_detail_f='coalesce(sum(others_rota_i_f_above_2_years_genderwise),0)';
									}else if($i==15){
										$coverage_detail_m='coalesce(sum(others_rota_ii_m_above_2_years_genderwise),0)';
										$coverage_detail_f='coalesce(sum(others_rota_ii_f_above_2_years_genderwise),0)';
									}else if($i==16){
										$coverage_detail_m='coalesce(sum(others_mr_i_m_above_2_years_genderwise),0)';
										$coverage_detail_f='coalesce(sum(others_mr_i_f_above_2_years_genderwise),0)';
									}else if($i==17){
										$coverage_detail_m='coalesce(sum(others_fully_immunized_m_above_2_years_genderwise),0)';
										$coverage_detail_f='coalesce(sum(others_fully_immunized_f_above_2_years_genderwise),0)';
									}else if($i==18){
										$coverage_detail_m='coalesce(sum(others_mr_ii_m_above_2_years_genderwise),0)';
										$coverage_detail_f='coalesce(sum(others_mr_ii_f_above_2_years_genderwise),0)';
									}else if($i==19){
										$coverage_detail_m='coalesce(sum(others_dtp_m_above_2_years_genderwise),0)';
										$coverage_detail_f='coalesce(sum(others_dtp_f_above_2_years_genderwise),0)';
									}else if($i==20){
										$coverage_detail_m='coalesce(sum(others_tcv_m_above_2_years_genderwise),0)';
										$coverage_detail_f='coalesce(sum(others_tcv_f_above_2_years_genderwise),0)';
									}else if($i==21){
										$coverage_detail_m='coalesce(sum(others_ipv_ii_m_above_2_years_genderwise),0)';
										$coverage_detail_f='coalesce(sum(others_ipv_ii_f_above_2_years_genderwise),0)';
									}
								}else if($vacc_to == 'total_children' && $age_wise == 'all'){
									if($i==4){
										$coverage_detail_total='coalesce(sum(others_opv_i_total_all_totalchildren),0)';
									}else if($i==5){
										$coverage_detail_total='coalesce(sum(others_opv_ii_total_all_totalchildren),0)';
									}else if($i==6){
										$coverage_detail_total='coalesce(sum(others_opv_iii_total_all_totalchildren),0)';
									}else if($i==7){
										$coverage_detail_total='coalesce(sum(others_pentavalent_i_total_all_totalchildren),0)';
									}else if($i==8){
										$coverage_detail_total='coalesce(sum(others_pentavalent_ii_total_all_totalchildren),0)';
									}else if($i==9){
										$coverage_detail_total='coalesce(sum(others_pentavalent_iii_total_all_totalchildren),0)';
									}else if($i==10){
										$coverage_detail_total='coalesce(sum(others_pcv10_i_total_all_totalchildren),0)';
									}else if($i==11){
										$coverage_detail_total='coalesce(sum(others_pcv10_ii_total_all_totalchildren),0)';
									}else if($i==12){
										$coverage_detail_total='coalesce(sum(others_pcv10_iii_total_all_totalchildren),0)';
									}else if($i==13){
										$coverage_detail_total='coalesce(sum(others_ipv_i_total_all_totalchildren),0)';
									}else if($i==14){
										$coverage_detail_total='coalesce(sum(others_rota_i_total_all_totalchildren),0)';
									}else if($i==15){
										$coverage_detail_total='coalesce(sum(others_rota_ii_total_all_totalchildren),0)';
									}else if($i==16){
										$coverage_detail_total='coalesce(sum(others_mr_i_total_all_totalchildren),0)';
									}else if($i==17){
										$coverage_detail_total='coalesce(sum(others_fully_immunized_total_all_totalchildren),0)';
									}else if($i==18){
										$coverage_detail_total='coalesce(sum(others_mr_ii_total_all_totalchildren),0)';
									}else if($i==19){
										$coverage_detail_total='coalesce(sum(others_dtp_total_all_totalchildren),0)';
									}else if($i==20){
										$coverage_detail_total='coalesce(sum(others_tcv_total_all_totalchildren),0)';
									}else if($i==21){
										$coverage_detail_total='coalesce(sum(others_ipv_ii_total_all_totalchildren),0)';
									}
								}else if($vacc_to == 'total_children' && $age_wise == '0to11'){
									if($i==4){
										$coverage_detail_total='coalesce(sum(others_opv_i_total_0_11_totalchildren),0)';
									}else if($i==5){
										$coverage_detail_total='coalesce(sum(others_opv_ii_total_0_11_totalchildren),0)';
									}else if($i==6){
										$coverage_detail_total='coalesce(sum(others_opv_iii_total_0_11_totalchildren),0)';
									}else if($i==7){
										$coverage_detail_total='coalesce(sum(others_pentavalent_i_total_0_11_totalchildren),0)';
									}else if($i==8){
										$coverage_detail_total='coalesce(sum(others_pentavalent_ii_total_0_11_totalchildren),0)';
									}else if($i==9){
										$coverage_detail_total='coalesce(sum(others_pentavalent_iii_total_0_11_totalchildren),0)';
									}else if($i==10){
										$coverage_detail_total='coalesce(sum(others_pcv10_i_total_0_11_totalchildren),0)';
									}else if($i==11){
										$coverage_detail_total='coalesce(sum(others_pcv10_ii_total_0_11_totalchildren),0)';
									}else if($i==12){
										$coverage_detail_total='coalesce(sum(others_pcv10_iii_total_0_11_totalchildren),0)';
									}else if($i==13){
										$coverage_detail_total='coalesce(sum(others_ipv_i_total_0_11_totalchildren),0)';
									}else if($i==14){
										$coverage_detail_total='coalesce(sum(others_rota_i_total_0_11_totalchildren),0)';
									}else if($i==15){
										$coverage_detail_total='coalesce(sum(others_rota_ii_total_0_11_totalchildren),0)';
									}else if($i==16){
										$coverage_detail_total='coalesce(sum(others_mr_i_total_0_11_totalchildren),0)';
									}else if($i==17){
										$coverage_detail_total='coalesce(sum(others_fully_immunized_total_0_11_totalchildren),0)';
									}else if($i==18){
										$coverage_detail_total='coalesce(sum(others_mr_ii_total_0_11_totalchildren),0)';
									}else if($i==19){
										$coverage_detail_total='coalesce(sum(others_dtp_total_0_11_totalchildren),0)';
									}else if($i==20){
										$coverage_detail_total='coalesce(sum(others_tcv_total_0_11_totalchildren),0)';
									}else if($i==21){
										$coverage_detail_total='coalesce(sum(others_ipv_ii_total_0_11_totalchildren),0)';
									}
								}else if($vacc_to == 'total_children' && $age_wise == '12to23'){
									if($i==4){
										$coverage_detail_total='coalesce(sum(others_opv_i_total_12_23_totalchildren),0)';
									}else if($i==5){
										$coverage_detail_total='coalesce(sum(others_opv_ii_total_12_23_totalchildren),0)';
									}else if($i==6){
										$coverage_detail_total='coalesce(sum(others_opv_iii_total_12_23_totalchildren),0)';
									}else if($i==7){
										$coverage_detail_total='coalesce(sum(others_pentavalent_i_total_12_23_totalchildren),0)';
									}else if($i==8){
										$coverage_detail_total='coalesce(sum(others_pentavalent_ii_total_12_23_totalchildren),0)';
									}else if($i==9){
										$coverage_detail_total='coalesce(sum(others_pentavalent_iii_total_12_23_totalchildren),0)';
									}else if($i==10){
										$coverage_detail_total='coalesce(sum(others_pcv10_i_total_12_23_totalchildren),0)';
									}else if($i==11){
										$coverage_detail_total='coalesce(sum(others_pcv10_ii_total_12_23_totalchildren),0)';
									}else if($i==12){
										$coverage_detail_total='coalesce(sum(others_pcv10_iii_total_12_23_totalchildren),0)';
									}else if($i==13){
										$coverage_detail_total='coalesce(sum(others_ipv_i_total_12_23_totalchildren),0)';
									}else if($i==14){
										$coverage_detail_total='coalesce(sum(others_rota_i_total_12_23_totalchildren),0)';
									}else if($i==15){
										$coverage_detail_total='coalesce(sum(others_rota_ii_total_12_23_totalchildren),0)';
									}else if($i==16){
										$coverage_detail_total='coalesce(sum(others_mr_i_total_12_23_totalchildren),0)';
									}else if($i==17){
										$coverage_detail_total='coalesce(sum(others_fully_immunized_total_12_23_totalchildren),0)';
									}else if($i==18){
										$coverage_detail_total='coalesce(sum(others_mr_ii_total_12_23_totalchildren),0)';
									}else if($i==19){
										$coverage_detail_total='coalesce(sum(others_dtp_total_12_23_totalchildren),0)';
									}else if($i==20){
										$coverage_detail_total='coalesce(sum(others_tcv_total_12_23_totalchildren),0)';
									}else if($i==21){
										$coverage_detail_total='coalesce(sum(others_ipv_ii_total_12_23_totalchildren),0)';
									}
								}else if($vacc_to == 'total_children' && $age_wise == 'above2'){
									if($i==4){
										$coverage_detail_total='coalesce(sum(others_opv_i_total_above_2_years_totalchildren),0)';
									}else if($i==5){
										$coverage_detail_total='coalesce(sum(others_opv_ii_total_above_2_years_totalchildren),0)';
									}else if($i==6){
										$coverage_detail_total='coalesce(sum(others_opv_iii_total_above_2_years_totalchildren),0)';
									}else if($i==7){
										$coverage_detail_total='coalesce(sum(others_pentavalent_i_total_above_2_years_totalchildren),0)';
									}else if($i==8){
										$coverage_detail_total='coalesce(sum(others_pentavalent_ii_total_above_2_years_totalchildren),0)';
									}else if($i==9){
										$coverage_detail_total='coalesce(sum(others_pentavalent_iii_total_above_2_years_totalchildren),0)';
									}else if($i==10){
										$coverage_detail_total='coalesce(sum(others_pcv10_i_total_above_2_years_totalchildren),0)';
									}else if($i==11){
										$coverage_detail_total='coalesce(sum(others_pcv10_ii_total_above_2_years_totalchildren),0)';
									}else if($i==12){
										$coverage_detail_total='coalesce(sum(others_pcv10_iii_total_above_2_years_totalchildren),0)';
									}else if($i==13){
										$coverage_detail_total='coalesce(sum(others_ipv_i_total_above_2_years_totalchildren),0)';
									}else if($i==14){
										$coverage_detail_total='coalesce(sum(others_rota_i_total_above_2_years_totalchildren),0)';
									}else if($i==15){
										$coverage_detail_total='coalesce(sum(others_rota_ii_total_above_2_years_totalchildren),0)';
									}else if($i==16){
										$coverage_detail_total='coalesce(sum(others_mr_i_total_above_2_years_totalchildren),0)';
									}else if($i==17){
										$coverage_detail_total='coalesce(sum(others_fully_immunized_total_above_2_years_totalchildren),0)';
									}else if($i==18){
										$coverage_detail_total='coalesce(sum(others_mr_ii_total_above_2_years_totalchildren),0)';
									}else if($i==19){
										$coverage_detail_total='coalesce(sum(others_dtp_total_above_2_years_totalchildren),0)';
									}else if($i==20){
										$coverage_detail_total='coalesce(sum(others_tcv_total_above_2_years_totalchildren),0)';
									}else if($i==21){
										$coverage_detail_total='coalesce(sum(others_ipv_ii_total_above_2_years_totalchildren),0)';
									}
								}
							}
							if($vacc_to == 'gender')
							{
								$queryForYearlyData .= "
								(select $coverage_detail_m from coverage_report_details where coverage_report_details.coverage_uncode_all_totalchildren=flcf1.uncode $fmonthCondition) as M$asValueCRI,
								(select CASE WHEN $targetMaleChildren = 0 THEN 0 ELSE round(($coverage_detail_m*100)/NULLIF($targetMaleChildren,0)) END from coverage_report_details where coverage_report_details.coverage_uncode_all_totalchildren=flcf1.uncode $fmonthCondition group by coverage_report_details.coverage_uncode_all_totalchildren) as percM$asValueCRI,
								(select $coverage_detail_f from coverage_report_details where coverage_report_details.coverage_uncode_all_totalchildren=flcf1.uncode $fmonthCondition) as F$asValueCRI,
								(select CASE WHEN $targetFeMaleChildren = 0 THEN 0 ELSE round(($coverage_detail_f*100)/NULLIF($targetFeMaleChildren,0)) END from coverage_report_details where coverage_report_details.coverage_uncode_all_totalchildren=flcf1.uncode $fmonthCondition group by coverage_report_details.coverage_uncode_all_totalchildren) as percF$asValueCRI,";
							}
							elseif($vacc_to == 'total_children')
							{
								$queryForYearlyData .= "
								(select $coverage_detail_total from coverage_report_details where coverage_report_details.coverage_uncode_all_totalchildren=flcf1.uncode $fmonthCondition) as T$asValueCRI,
								(select CASE WHEN $targetMaleChildren > 0 OR $targetFeMaleChildren > 0 THEN round(($coverage_detail_total*100)/(NULLIF($targetFeMaleChildren,0) + NULLIF($targetMaleChildren,0))) ELSE 0 END from coverage_report_details where coverage_report_details.coverage_uncode_all_totalchildren=flcf1.uncode $fmonthCondition group by coverage_report_details.coverage_uncode_all_totalchildren) as percT$asValueCRI,";
							}
						}
					}
				}
				if($show_pl_cba)
				{
					if($in_out_coverage == 'in_uc'){
						for($k=1;$k<=sizeof($ttNames1);$k++)
						{
							$asValueTT1=$ttNames1[$k-1];
							if($k >=1 && $k<=2)
							{	
								if($vacc_to == 'gender' && $age_wise == 'all'){
									if($k==1){
										$coverage_detail_total='coalesce(sum(coverage_tt_pregnant_women_i_doses_all_genderwise),0)';
									}else if($k==2){
										$coverage_detail_total='coalesce(sum(coverage_tt_pregnant_women_ii_doses_all_genderwise),0)';
									}
								}else if($vacc_to == 'total_children' && $age_wise == 'all'){
									if($k==1){
										$coverage_detail_total='coalesce(sum(coverage_tt_pregnant_women_i_doses_all_totalchildren),0)';
									}else if($k==2){
										$coverage_detail_total='coalesce(sum(coverage_tt_pregnant_women_ii_doses_all_totalchildren),0)';
									}
								}
								if($start_year >= 2021){
									if($k==1){
										$ou_tcols_att ="+(select coalesce(sum(fp)+sum(op)+sum(mp)+sum(hp),0) from monthly_outuc_coverage where monthly_outuc_coverage.uncode=fac_mvrf_db.uncode $monthly_ou_fmonthCondition and monthly_outuc_coverage.item_id='6' and monthly_outuc_coverage.antigen='1')";
									}else if($k==2){
										$ou_tcols_att ="+(select coalesce(sum(fp)+sum(op)+sum(mp)+sum(hp),0) from monthly_outuc_coverage where monthly_outuc_coverage.uncode=fac_mvrf_db.uncode $monthly_ou_fmonthCondition and monthly_outuc_coverage.item_id='6' and monthly_outuc_coverage.antigen='2')";
									}else{
										$ou_tcols_att ="";
									}
								}else{
									$ou_tcols_att ="";
								}
								$queryForYearlyData .= "
									(select $coverage_detail_total from coverage_report_details where coverage_report_details.coverage_uncode_all_totalchildren=flcf1.uncode $fmonthCondition) as PW$asValueTT1 ,
									(select CASE WHEN $targetWomen = 0 THEN 0 ELSE round(($coverage_detail_total*100)/NULLIF($targetWomen,0)) END from coverage_report_details where coverage_report_details.coverage_uncode_all_totalchildren=flcf1.uncode $fmonthCondition group by coverage_report_details.coverage_uncode_all_totalchildren) as PWperc$asValueTT1 ,";
							}
							else
							{
								if($vacc_to == 'gender' && $age_wise == 'all'){
									if($k==3){
										$coverage_detail_total='coalesce(sum(coverage_tt_pregnant_women_iii_all_genderwise),0)';
									}else if($k==4){
										$coverage_detail_total='coalesce(sum(coverage_tt_pregnant_women_iv_all_genderwise),0)';
									}else if($k==5){
										$coverage_detail_total='coalesce(sum(coverage_tt_pregnant_women_v_all_genderwise),0)';
									}
								}else if($vacc_to == 'total_children' && $age_wise == 'all'){
									if($k==3){
										$coverage_detail_total='coalesce(sum(coverage_tt_pregnant_women_iii_all_totalchildren),0)';
									}else if($k==4){
										$coverage_detail_total='coalesce(sum(coverage_tt_pregnant_women_iv_all_totalchildren),0)';
									}else if($k==5){
										$coverage_detail_total='coalesce(sum(coverage_tt_pregnant_women_v_all_totalchildren),0)';
									}
								}
								if($start_year >= 2021){
									if($k==3){
										$ou_tcols_att ="+(select coalesce(sum(fp)+sum(op)+sum(mp)+sum(hp),0) from monthly_outuc_coverage where monthly_outuc_coverage.uncode=fac_mvrf_db.uncode $monthly_ou_fmonthCondition and monthly_outuc_coverage.item_id='6' and monthly_outuc_coverage.antigen='3')";
									}else if($k==4){
										$ou_tcols_att ="+(select coalesce(sum(fp)+sum(op)+sum(mp)+sum(hp),0) from monthly_outuc_coverage where monthly_outuc_coverage.uncode=fac_mvrf_db.uncode $monthly_ou_fmonthCondition and monthly_outuc_coverage.item_id='6' and monthly_outuc_coverage.antigen='4')";
									}else if($k==5){
										$ou_tcols_att ="+(select coalesce(sum(fp)+sum(op)+sum(mp)+sum(hp),0) from monthly_outuc_coverage where monthly_outuc_coverage.uncode=fac_mvrf_db.uncode $monthly_ou_fmonthCondition and monthly_outuc_coverage.item_id='6' and monthly_outuc_coverage.antigen='5')";
									}else{
										$ou_tcols_att ="";
									}
								}else{
									$ou_tcols_att ="";
								}
								$queryForYearlyData .= "
									(select $coverage_detail_total from coverage_report_details where coverage_report_details.coverage_uncode_all_totalchildren=flcf1.uncode $fmonthCondition) as $asValueTT1 ,";
							}
						}
						for($j=1;$j<=sizeof($ttNames2);$j++)
						{
							if($vacc_to == 'gender' && $age_wise == 'all'){
								if($j==1){
									$coverage_detail_total='coalesce(sum(coverage_tt_non_pregnant_women_15_49_years_i_all_genderwise),0)';
								}else if($j==2){
									$coverage_detail_total='coalesce(sum(coverage_tt_non_pregnant_women_15_49_years_ii_all_genderwise),0)';
								}else if($j==3){
									$coverage_detail_total='coalesce(sum(coverage_tt_non_pregnant_women_15_49_years_iii_all_genderwise),0)';
								}else if($j==4){
									$coverage_detail_total='coalesce(sum(coverage_tt_non_pregnant_women_15_49_years_iv_all_genderwise),0)';
								}else if($j==5){
									$coverage_detail_total='coalesce(sum(coverage_tt_non_pregnant_women_15_49_years_v_all_genderwise),0)';
								}
							}else if($vacc_to == 'total_children' && $age_wise == 'all'){
								if($j==1){
									$coverage_detail_total='coalesce(sum(coverage_tt_non_pregnant_women_15_49_years_i_all_totalchildren),0)';
								}else if($j==2){
									$coverage_detail_total='coalesce(sum(coverage_tt_non_pregnant_women_15_49_years_ii_all_totalchildren),0)';
								}else if($j==3){
									$coverage_detail_total='coalesce(sum(coverage_tt_non_pregnant_women_15_49_years_iii_all_totalchildren),0)';
								}else if($j==4){
									$coverage_detail_total='coalesce(sum(coverage_tt_non_pregnant_women_15_49_years_iv_all_totalchildren),0)';
								}else if($j==5){
									$coverage_detail_total='coalesce(sum(coverage_tt_non_pregnant_women_15_49_years_v_all_totalchildren),0)';
								}
							}
							if($start_year >= 2021){
								if($j==1){
									$ou_tcols_att ="+(select coalesce(sum(fnp)+sum(onp)+sum(mnp)+sum(hnp),0) from monthly_outuc_coverage where monthly_outuc_coverage.uncode=fac_mvrf_db.uncode $monthly_ou_fmonthCondition and monthly_outuc_coverage.item_id='6' and monthly_outuc_coverage.antigen='1')";
								}else if($j==2){
									$ou_tcols_att ="+(select coalesce(sum(fnp)+sum(onp)+sum(mnp)+sum(hnp),0) from monthly_outuc_coverage where monthly_outuc_coverage.uncode=fac_mvrf_db.uncode $monthly_ou_fmonthCondition and monthly_outuc_coverage.item_id='6' and monthly_outuc_coverage.antigen='2')";
								}else if($j==3){
									$ou_tcols_att ="+(select coalesce(sum(fnp)+sum(onp)+sum(mnp)+sum(hnp),0) from monthly_outuc_coverage where monthly_outuc_coverage.uncode=fac_mvrf_db.uncode $monthly_ou_fmonthCondition and monthly_outuc_coverage.item_id='6' and monthly_outuc_coverage.antigen='3')";
								}else if($j==4){
									$ou_tcols_att ="+(select coalesce(sum(fnp)+sum(onp)+sum(mnp)+sum(hnp),0) from monthly_outuc_coverage where monthly_outuc_coverage.uncode=fac_mvrf_db.uncode $monthly_ou_fmonthCondition and monthly_outuc_coverage.item_id='6' and monthly_outuc_coverage.antigen='4')";
								}else if($j==5){
									$ou_tcols_att ="+(select coalesce(sum(fnp)+sum(onp)+sum(mnp)+sum(hnp),0) from monthly_outuc_coverage where monthly_outuc_coverage.uncode=fac_mvrf_db.uncode $monthly_ou_fmonthCondition and monthly_outuc_coverage.item_id='6' and monthly_outuc_coverage.antigen='5')";
								}else{
									$ou_tcols_att ="";
								}
							}else{
								$ou_tcols_att ="";
							}
							$asValueTT2=$ttNames2[$j-1];
							$queryForYearlyData .= "(select $coverage_detail_total from coverage_report_details where coverage_report_details.coverage_uncode_all_totalchildren=flcf1.uncode $fmonthCondition) as $asValueTT2 ,";
						}
					}
					if($in_out_coverage == 'out_uc'){
						for($k=1;$k<=sizeof($ttNames1);$k++)
						{
							$asValueTT1=$ttNames1[$k-1];
							if($k >=1 && $k<=2)
							{	
								if($vacc_to == 'gender' && $age_wise == 'all'){
									if($k==1){
										$coverage_detail_total='coalesce(sum(others_tt_pregnant_women_i_doses_all_genderwise),0)';
									}else if($k==2){
										$coverage_detail_total='coalesce(sum(others_tt_pregnant_women_ii_doses_all_genderwise),0)';
									}
								}else if($vacc_to == 'total_children' && $age_wise == 'all'){
									if($k==1){
										$coverage_detail_total='coalesce(sum(others_tt_pregnant_women_i_doses_all_totalchildren),0)';
									}else if($k==2){
										$coverage_detail_total='coalesce(sum(others_tt_pregnant_women_ii_doses_all_totalchildren),0)';
									}
								}
								$queryForYearlyData .= "
									(select $coverage_detail_total from coverage_report_details where coverage_report_details.coverage_uncode_all_totalchildren=flcf1.uncode $fmonthCondition) as PW$asValueTT1 ,";
							}
							else
							{
								if($vacc_to == 'gender' && $age_wise == 'all'){
									if($k==3){
										$coverage_detail_total='coalesce(sum(others_tt_pregnant_women_iii_all_genderwise),0)';
									}else if($k==4){
										$coverage_detail_total='coalesce(sum(others_tt_pregnant_women_iv_all_genderwise),0)';
									}else if($k==5){
										$coverage_detail_total='coalesce(sum(others_tt_pregnant_women_v_all_genderwise),0)';
									}
								}else if($vacc_to == 'total_children' && $age_wise == 'all'){
									if($k==3){
										$coverage_detail_total='coalesce(sum(others_tt_pregnant_women_iii_all_totalchildren),0)';
									}else if($k==4){
										$coverage_detail_total='coalesce(sum(others_tt_pregnant_women_iv_all_totalchildren),0)';
									}else if($k==5){
										$coverage_detail_total='coalesce(sum(others_tt_pregnant_women_v_all_totalchildren),0)';
									}
								}
								$queryForYearlyData .= "
									(select $coverage_detail_total from coverage_report_details where coverage_report_details.coverage_uncode_all_totalchildren=flcf1.uncode $fmonthCondition) as $asValueTT1 ,";
							}
						}
						for($j=1;$j<=sizeof($ttNames2);$j++)
						{
							if($vacc_to == 'gender' && $age_wise == 'all'){
								if($j==1){
									$coverage_detail_total='coalesce(sum(others_tt_non_pregnant_women_15_49_years_i_all_genderwise),0)';
								}else if($j==2){
									$coverage_detail_total='coalesce(sum(others_tt_non_pregnant_women_15_49_years_ii_all_genderwise),0)';
								}else if($j==3){
									$coverage_detail_total='coalesce(sum(others_tt_non_pregnant_women_15_49_years_iii_all_genderwise),0)';
								}else if($j==4){
									$coverage_detail_total='coalesce(sum(others_tt_non_pregnant_women_15_49_years_iv_all_genderwise),0)';
								}else if($j==5){
									$coverage_detail_total='coalesce(sum(others_tt_non_pregnant_women_15_49_years_v_all_genderwise),0)';
								}
							}else if($vacc_to == 'total_children' && $age_wise == 'all'){
								if($j==1){
									$coverage_detail_total='coalesce(sum(others_tt_non_pregnant_women_15_49_years_i_all_totalchildren),0)';
								}else if($j==2){
									$coverage_detail_total='coalesce(sum(others_tt_non_pregnant_women_15_49_years_ii_all_totalchildren),0)';
								}else if($j==3){
									$coverage_detail_total='coalesce(sum(others_tt_non_pregnant_women_15_49_years_iii_all_totalchildren),0)';
								}else if($j==4){
									$coverage_detail_total='coalesce(sum(own_tt_non_pregnant_women_15_49_years_iv_all_totalchildren),0)';
								}else if($j==5){
									$coverage_detail_total='coalesce(sum(own_tt_non_pregnant_women_15_49_years_v_all_totalchildren),0)';
								}
							}
							$asValueTT2=$ttNames2[$j-1];
							$queryForYearlyData .= "(select $coverage_detail_total from coverage_report_details where coverage_report_details.coverage_uncode_all_totalchildren=flcf1.uncode $fmonthCondition) as $asValueTT2 ,";
						}
					}
					if($in_out_coverage == 'in_district'){
						for($k=1;$k<=sizeof($ttNames1);$k++)
						{
							$asValueTT1=$ttNames1[$k-1];
							if($k >=1 && $k<=2)
							{
								if($vacc_to == 'gender' && $age_wise == 'all'){
									if($k==1){
										$coverage_detail_total='coalesce(sum(coverage_tt_pregnant_women_i_doses_all_genderwise),0)';
									}else if($k==2){
										$coverage_detail_total='coalesce(sum(coverage_tt_pregnant_women_ii_doses_all_genderwise),0)';
									}
								}else if($vacc_to == 'total_children' && $age_wise == 'all'){
									if($k==1){
										$coverage_detail_total='coalesce(sum(coverage_tt_pregnant_women_i_doses_all_totalchildren),0)';
									}else if($k==2){
										$coverage_detail_total='coalesce(sum(coverage_tt_pregnant_women_ii_doses_all_totalchildren),0)';
									}
								}
								if($start_year >= 2021){
									if($k==1){
										$ou_tcols_att ="+(select coalesce(sum(fp)+sum(op)+sum(mp)+sum(hp),0) from monthly_outuc_coverage where monthly_outuc_coverage.uncode=fac_mvrf_db.uncode $monthly_ou_fmonthCondition and monthly_outuc_coverage.item_id='6' and monthly_outuc_coverage.antigen='1')";
									}else if($k==2){
										$ou_tcols_att ="+(select coalesce(sum(fp)+sum(op)+sum(mp)+sum(hp),0) from monthly_outuc_coverage where monthly_outuc_coverage.uncode=fac_mvrf_db.uncode $monthly_ou_fmonthCondition and monthly_outuc_coverage.item_id='6' and monthly_outuc_coverage.antigen='2')";
									}else{
										$ou_tcols_att ="";
									}
								}else{
									$ou_tcols_att ="";
								}
								$queryForYearlyData .= "
									(select $coverage_detail_total from coverage_report_details where coverage_report_details.coverage_uncode_all_totalchildren=flcf1.uncode $fmonthCondition) as PW$asValueTT1 ,
									(select CASE WHEN $targetWomen = 0 THEN 0 ELSE round(($coverage_detail_total*100)/NULLIF($targetWomen,0)) END from coverage_report_details where coverage_report_details.coverage_uncode_all_totalchildren=flcf1.uncode $fmonthCondition group by coverage_report_details.coverage_uncode_all_totalchildren ) as PWperc$asValueTT1 ,";
							}
							else
							{
								if($vacc_to == 'gender' && $age_wise == 'all'){
									if($k==3){
										$coverage_detail_total='coalesce(sum(coverage_tt_pregnant_women_iii_all_genderwise),0)';
									}else if($k==4){
										$coverage_detail_total='coalesce(sum(coverage_tt_pregnant_women_iv_all_genderwise),0)';
									}else if($k==5){
										$coverage_detail_total='coalesce(sum(coverage_tt_pregnant_women_v_all_genderwise),0)';
									}
								}else if($vacc_to == 'total_children' && $age_wise == 'all'){
									if($k==3){
										$coverage_detail_total='coalesce(sum(coverage_tt_pregnant_women_iii_all_totalchildren),0)';
									}else if($k==4){
										$coverage_detail_total='coalesce(sum(coverage_tt_pregnant_women_iv_all_totalchildren),0)';
									}else if($k==5){
										$coverage_detail_total='coalesce(sum(coverage_tt_pregnant_women_v_all_totalchildren),0)';
									}
								}
								if($start_year >= 2021){
									if($k==3){
										$ou_tcols_att ="+(select coalesce(sum(fp)+sum(op)+sum(mp)+sum(hp),0) from monthly_outuc_coverage where monthly_outuc_coverage.uncode=fac_mvrf_db.uncode $monthly_ou_fmonthCondition and monthly_outuc_coverage.item_id='6' and monthly_outuc_coverage.antigen='3')";
									}else if($k==4){
										$ou_tcols_att ="+(select coalesce(sum(fp)+sum(op)+sum(mp)+sum(hp),0) from monthly_outuc_coverage where monthly_outuc_coverage.uncode=fac_mvrf_db.uncode $monthly_ou_fmonthCondition and monthly_outuc_coverage.item_id='6' and monthly_outuc_coverage.antigen='4')";
									}else if($k==5){
										$ou_tcols_att ="+(select coalesce(sum(fp)+sum(op)+sum(mp)+sum(hp),0) from monthly_outuc_coverage where monthly_outuc_coverage.uncode=fac_mvrf_db.uncode $monthly_ou_fmonthCondition and monthly_outuc_coverage.item_id='6' and monthly_outuc_coverage.antigen='5')";
									}else{
										$ou_tcols_att ="";
									}
								}else{
									$ou_tcols_att ="";
								}
								$queryForYearlyData .= "
									(select $coverage_detail_total from coverage_report_details where coverage_report_details.coverage_uncode_all_totalchildren=flcf1.uncode $fmonthCondition) as $asValueTT1 ,";
							}
						}
						for($j=1;$j<=sizeof($ttNames2);$j++)
						{
							if($vacc_to == 'gender' && $age_wise == 'all'){
								if($j==1){
									$coverage_detail_total='coalesce(sum(coverage_tt_non_pregnant_women_15_49_years_i_all_genderwise),0)';
								}else if($j==2){
									$coverage_detail_total='coalesce(sum(coverage_tt_non_pregnant_women_15_49_years_ii_all_genderwise),0)';
								}else if($j==3){
									$coverage_detail_total='coalesce(sum(coverage_tt_non_pregnant_women_15_49_years_iii_all_genderwise),0)';
								}else if($j==4){
									$coverage_detail_total='coalesce(sum(coverage_tt_non_pregnant_women_15_49_years_iv_all_genderwise),0)';
								}else if($j==5){
									$coverage_detail_total='coalesce(sum(coverage_tt_non_pregnant_women_15_49_years_v_all_genderwise),0)';
								}
							}else if($vacc_to == 'total_children' && $age_wise == 'all'){
								if($j==1){
									$coverage_detail_total='coalesce(sum(coverage_tt_non_pregnant_women_15_49_years_i_all_totalchildren),0)';
								}else if($j==2){
									$coverage_detail_total='coalesce(sum(coverage_tt_non_pregnant_women_15_49_years_ii_all_totalchildren),0)';
								}else if($j==3){
									$coverage_detail_total='coalesce(sum(coverage_tt_non_pregnant_women_15_49_years_iii_all_totalchildren),0)';
								}else if($j==4){
									$coverage_detail_total='coalesce(sum(coverage_tt_non_pregnant_women_15_49_years_iv_all_totalchildren),0)';
								}else if($j==5){
									$coverage_detail_total='coalesce(sum(coverage_tt_non_pregnant_women_15_49_years_v_all_totalchildren),0)';
								}
							}
							if($start_year >= 2021){
								if($j==1){
									$ou_tcols_att ="+(select coalesce(sum(fnp)+sum(onp)+sum(mnp)+sum(hnp),0) from monthly_outuc_coverage where monthly_outuc_coverage.uncode=fac_mvrf_db.uncode $monthly_ou_fmonthCondition and monthly_outuc_coverage.item_id='6' and monthly_outuc_coverage.antigen='1')";
								}else if($j==2){
									$ou_tcols_att ="+(select coalesce(sum(fnp)+sum(onp)+sum(mnp)+sum(hnp),0) from monthly_outuc_coverage where monthly_outuc_coverage.uncode=fac_mvrf_db.uncode $monthly_ou_fmonthCondition and monthly_outuc_coverage.item_id='6' and monthly_outuc_coverage.antigen='2')";
								}else if($j==3){
									$ou_tcols_att ="+(select coalesce(sum(fnp)+sum(onp)+sum(mnp)+sum(hnp),0) from monthly_outuc_coverage where monthly_outuc_coverage.uncode=fac_mvrf_db.uncode $monthly_ou_fmonthCondition and monthly_outuc_coverage.item_id='6' and monthly_outuc_coverage.antigen='3')";
								}else if($j==4){
									$ou_tcols_att ="+(select coalesce(sum(fnp)+sum(onp)+sum(mnp)+sum(hnp),0) from monthly_outuc_coverage where monthly_outuc_coverage.uncode=fac_mvrf_db.uncode $monthly_ou_fmonthCondition and monthly_outuc_coverage.item_id='6' and monthly_outuc_coverage.antigen='4')";
								}else if($j==5){
									$ou_tcols_att ="+(select coalesce(sum(fnp)+sum(onp)+sum(mnp)+sum(hnp),0) from monthly_outuc_coverage where monthly_outuc_coverage.uncode=fac_mvrf_db.uncode $monthly_ou_fmonthCondition and monthly_outuc_coverage.item_id='6' and monthly_outuc_coverage.antigen='5')";
								}else{
									$ou_tcols_att ="";
								}
							}else{
								$ou_tcols_att ="";
							}
							$asValueTT2=$ttNames2[$j-1];
							$queryForYearlyData .= "(select $coverage_detail_total from coverage_report_details where coverage_report_details.coverage_uncode_all_totalchildren=flcf1.uncode $fmonthCondition) as $asValueTT2 ,";
						}
					}
					if($in_out_coverage == 'total_ucs'){
						for($k=1;$k<=sizeof($ttNames1);$k++)
						{
							$asValueTT1=$ttNames1[$k-1];
							if($k >=1 && $k<=2)
							{
								if($vacc_to == 'gender' && $age_wise == 'all'){
									if($k==1){
										$coverage_detail_total='coalesce(sum(own_tt_pregnant_women_i_doses_all_genderwise),0)';
									}else if($k==2){
										$coverage_detail_total='coalesce(sum(own_tt_pregnant_women_ii_doses_all_genderwise),0)';
									}
								}else if($vacc_to == 'total_children' && $age_wise == 'all'){
									if($k==1){
										$coverage_detail_total='coalesce(sum(own_tt_pregnant_women_i_doses_all_totalchildren),0)';
									}else if($k==2){
										$coverage_detail_total='coalesce(sum(own_tt_pregnant_women_ii_doses_all_totalchildren),0)';
									}
								}
								$queryForYearlyData .= "
									(select $coverage_detail_total from coverage_report_details where coverage_report_details.coverage_uncode_all_totalchildren=flcf1.uncode $fmonthCondition) as PW$asValueTT1 ,
									(select CASE WHEN $targetWomen = 0 THEN 0 ELSE round(($coverage_detail_total*100)/NULLIF($targetWomen,0)) END from coverage_report_details where coverage_report_details.coverage_uncode_all_totalchildren=flcf1.uncode $fmonthCondition group by coverage_report_details.coverage_uncode_all_totalchildren ) as PWperc$asValueTT1 ,";
									
							}
							else
							{
								if($vacc_to == 'gender' && $age_wise == 'all'){
									if($k==3){
										$coverage_detail_total='coalesce(sum(own_tt_pregnant_women_iii_all_genderwise),0)';
									}else if($k==4){
										$coverage_detail_total='coalesce(sum(own_tt_pregnant_women_iv_all_genderwise),0)';
									}else if($k==5){
										$coverage_detail_total='coalesce(sum(own_tt_pregnant_women_v_all_genderwise),0)';
									}
								}else if($vacc_to == 'total_children' && $age_wise == 'all'){
									if($k==3){
										$coverage_detail_total='coalesce(sum(own_tt_pregnant_women_iii_all_totalchildren),0)';
									}else if($k==4){
										$coverage_detail_total='coalesce(sum(own_tt_pregnant_women_iv_all_totalchildren),0)';
									}else if($k==5){
										$coverage_detail_total='coalesce(sum(own_tt_pregnant_women_v_all_totalchildren),0)';
									}
								}
								$queryForYearlyData .= "
									(select $coverage_detail_total from coverage_report_details where coverage_report_details.coverage_uncode_all_totalchildren=flcf1.uncode $fmonthCondition) as $asValueTT1 ,";	
							}
						}
						for($j=1;$j<=sizeof($ttNames2);$j++)
						{
							if($vacc_to == 'gender' && $age_wise == 'all'){
								if($j==1){
									$coverage_detail_total='coalesce(sum(own_tt_non_pregnant_women_15_49_years_i_all_genderwise),0)';
								}else if($j==2){
									$coverage_detail_total='coalesce(sum(own_tt_non_pregnant_women_15_49_years_ii_all_genderwise),0)';
								}else if($j==3){
									$coverage_detail_total='coalesce(sum(own_tt_non_pregnant_women_15_49_years_iii_all_genderwise),0)';
								}else if($j==4){
									$coverage_detail_total='coalesce(sum(own_tt_non_pregnant_women_15_49_years_iv_all_genderwise),0)';
								}else if($j==5){
									$coverage_detail_total='coalesce(sum(own_tt_non_pregnant_women_15_49_years_v_all_genderwise),0)';
								}
							}else if($vacc_to == 'total_children' && $age_wise == 'all'){
								if($j==1){
									$coverage_detail_total='coalesce(sum(own_tt_non_pregnant_women_15_49_years_i_all_totalchildren),0)';
								}else if($j==2){
									$coverage_detail_total='coalesce(sum(own_tt_non_pregnant_women_15_49_years_ii_all_totalchildren),0)';
								}else if($j==3){
									$coverage_detail_total='coalesce(sum(own_tt_non_pregnant_women_15_49_years_iii_all_totalchildren),0)';
								}else if($j==4){
									$coverage_detail_total='coalesce(sum(own_tt_non_pregnant_women_15_49_years_iv_all_totalchildren),0)';
								}else if($j==5){
									$coverage_detail_total='coalesce(sum(own_tt_non_pregnant_women_15_49_years_v_all_totalchildren),0)';
								}
							}
							$asValueTT2=$ttNames2[$j-1];
							$queryForYearlyData .= "(select $coverage_detail_total from coverage_report_details where coverage_report_details.coverage_uncode_all_totalchildren=flcf1.uncode $fmonthCondition) as $asValueTT2 ,";
						}
					}
				}
				if(isset($data['tcode'])){
					$wc = " flcf1.tcode = '{$data['tcode']}'";
				}else{
					$wc = " flcf1.distcode='{$distcode}'";
				}
				$queryForYearlyData = rtrim($queryForYearlyData,",");
				$queryForYearlyData .= " from unioncouncil flcf1 join coverage_report_details fac on flcf1.uncode=fac.coverage_uncode_all_totalchildren where $wc group by flcf1.uncode,un_name order by un_name";
			}
		}	
		$result = $this -> db -> query($queryForYearlyData) -> result_array();
		//echo $this -> db -> last_query(); exit();
		if ($this -> input -> post('export_excel')) {
			//if request is from excel
			header("Content-type: application/octet-stream");
			header("Content-Disposition: attachment; filename=Consolidated_Facility_Wise_Vaccination_of_Childern_and_Women.xls");
			header("Pragma: no-cache");
			header("Expires: 0");
			//Excel Ending here
		}
		//Excel file code ENDS*******************
		//print_r($data); exit();
		$result['TopInfo'] = reportsTopInfo($subTitle, $data);
		$result['exportIcons']=exportIcons($_REQUEST);
		return $result;
	}	
}
?>	