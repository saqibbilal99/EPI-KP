<?php
class Redrec_reportmodel extends CI_Model {
	//================ Constructor function Starts Here ==================//
	public function __construct() {
		parent::__construct();
		$this -> load -> helper('epi_reports_helper');
	}
	//====================== Constructor Function Ends Here ==========================//
	function Quartely_Schedule_plane($data){
		//Excel file code is here*******************
		if($this->input->post('export_excel'))
		{
			header("Content-type: application/octet-stream");
			header("Content-Disposition: attachment; filename=Red_Rec_Compilation.xls");
			header("Pragma: no-cache");
			header("Expires: 0");
		}
		//Excel file code ENDS*******************
		$distcode = $data['distcode'];
		$quarter = $data['quarter'];
		$year = $data['year'];
		if($distcode > 0)
		{	
			$wc = " and distcode= '".$data['distcode']."'";
		}
		if(isset($data['tcode']) AND $data['tcode'] > 0){
			$wc = " and tcode= '".$data['tcode']."'";
		}
		if(isset($data['uncode']) AND $data['uncode'] > 0){
			$wc = " and uncode= '".$data['uncode']."'";
		}
		if(isset($data['facode']) AND $data['facode'] > 0){
			$wc = " and facode= '".$data['facode']."'";
		}
		//print_r($uncode);exit;
		//$query="SELECT uncode, unname(uncode) as unioncouncil, facode, facilityname(facode) as fac_name, area_code,sitename_s,area_dateschedule_m1,area_dateschedule_m2,area_dateschedule_m3,sitename_h,area_dateheld_m1,area_dateheld_m2,area_dateheld_m3 from hf_quarterplan_dates_db where year='$year' and quarter='$quarter'".$wc." ;";

		$query="SELECT hfdates.uncode, unname(hfdates.uncode) as unioncouncil, hfdates.facode, facilityname(hfdates.facode) as fac_name, hfdates.area_code, hfdates.sitename_s, hfdates.area_dateschedule_m1, hfdates.area_dateschedule_m2, hfdates.area_dateschedule_m3, hfdates.sitename_h, hfdates.area_dateheld_m1, hfdates.area_dateheld_m2, hfdates.area_dateheld_m3, technicianname(hfnm.area_resperson_m1) as area_resperson_m1, technicianname(hfnm.area_resperson_m2) as area_resperson_m2, technicianname(hfnm.area_resperson_m3) as area_resperson_m3 from hf_quarterplan_dates_db as hfdates inner join (select pk_id, area_resperson_m1, area_resperson_m2, area_resperson_m3 from hf_quarterplan_nm_db where year='$year' and quarter='$quarter'".$wc.") as hfnm on hfdates.link_id = hfnm.pk_id where hfdates.year='$year' and hfdates.quarter='$quarter'".$wc." order by unname(hfdates.uncode), facilityname(hfdates.facode), technicianname(hfnm.area_resperson_m1), hfdates.area_dateschedule_m1;";

		/* $this->db->select('uncode, unname(uncode) as unioncouncil ,villagename(area_code) as areaname,sitename_s,area_dateschedule_m1,area_dateschedule_m2,area_dateschedule_m3,sitename_h,area_dateheld_m1,area_dateheld_m2,area_dateheld_m3 ');
		$this->db->from('hf_quarterplan_dates_db');
		$this->db->where('year', $year);
		$this->db->where('quarter', $quarter);
		$this->db->where('distcode', $distcode);
		$this->db->where('uncode', $uncode);
	   */
		//select techniciancode from techniciandb where 
		$result = $this-> db-> query($query);	
		$data['data'] = $result-> result_array(); 
		$resultt['distcode']=$distcode;
		$resultt['quarter']=$quarter;
		$resultt['year']=$year;
		return $data;
	} 
	  
	  
	function Quartely_Datewise_plane($data){
		//Excel file code is here*******************
		if($this->input->post('export_excel'))
		{
			header("Content-type: application/octet-stream");
			header("Content-Disposition: attachment; filename=Red_Rec_Compilation.xls");
			header("Pragma: no-cache");
			header("Expires: 0");
		}
		//Excel file code ENDS*******************
		$distcode = $data['distcode'];
		$quarter = $data['quarter'];
		$year = $data['year'];
		$query="select unname(uncode) as ucname ,technicianname(techniciancode) as technicianname, case when session_type='Fixed' then facilityname(sitename_s) else sitename_s end  as sitename ,* from hf_quarterplan_dates_db where distcode='$distcode' and quarter ='$quarter' and year='$year' order by tcode,uncode,techniciancode";
		$result = $this-> db-> query($query);	
		$data['data'] = $result-> result_array(); 
		$resultt['distcode']=$distcode;
		$resultt['quarter']=$quarter;
		$resultt['year']=$year;
		return $data;
	}
}
?>