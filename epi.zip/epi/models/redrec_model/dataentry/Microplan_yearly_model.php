<?php 
class Microplan_yearly_model extends CI_Model {
	public function __construct(){
		parent::__construct();
		$this -> load -> model('Common_model');
		$this-> load-> helper('epi_functions_helper'); 
	}
	public function microplan_yearly_add_model($distcode){
		$query="SELECT tcode, tehsilname(tcode) as tehsil from tehsil where distcode='{$distcode}'";
		$data['data'] = $this->db->query($query)->result_array();
		return $data; 
	}
	public function microplan_yearly_list(){
		$distcode = $this -> session -> District;
		$procode = $this -> session -> Province;
		//$data['distcode'] = $_SESSION['District'];
		$data['ulevel'] = $_SESSION['UserLevel'];
		$data['utype'] = $_SESSION['utype'];		
		$wc = "";
		switch ($_SESSION['UserLevel']) {
			case '1' :
				# code...
				break;
			case '2' :
				$UserLevel = 2;
				if (isset($_SESSION['Province'])) {
					$wc .= "  procode = '" . $_SESSION['Province'] . "' ";
				}
				break;
			case '3' :
				$UserLevel = 3;
				if (isset($_SESSION['Province']) && isset($_SESSION['District'])) {
					$wc .= "  procode = '" . $_SESSION['Province'] . "' AND distcode = '" . $_SESSION['District'] . "'";
				}
				break;
			case '4' :
				$UserLevel = 4;
				if (isset($_SESSION['Province']) && isset($_SESSION['District']) && isset($_SESSION['facode'])) {
					$wc .= "distcode = '" . $_SESSION['District'] . "'AND facode = '" . $_SESSION['facode'] . "'  ";
				}
				break;
		
		}
		//print_r($wc);exit;
		$data['UserLevel'] = $UserLevel;	
		$query = "SELECT facode, fatype ,fac_name from facilities where $wc and hf_type='e' order by facode";
		$Fac_result = $this -> db -> query($query);
		$data['resultFac'] = $Fac_result -> result_array();

		$query = "SELECT tcode, tehsil from tehsil where $wc order by tcode";
		$Teh_result = $this -> db -> query($query);
		$data['resultTeh'] = $Teh_result -> result_array();

		$this->db->select(' tehsilname(tcode) as tehsil, unname(uncode) as uc_name, uncode, facilityname(facode) as facility, facode, year');
		if(isset($_SESSION['District'])){
			$this->db->where('distcode',$distcode);
		}
		else{
			$this->db->where('procode',$procode);
		}
		$this->db->from('situation_analysis_db');
		$this->db->group_by('tcode,uncode,facode,year');
		$this->db->order_by('facode', 'ASC');
		$data['data'] = $this-> db-> get()-> result_array();
		return $data['data'];	
	}
	public function microplan_yearly_editb_model($uncode,$year,$facode){
		$recordexist="SELECT EXISTS(select * from situation_analysis_db where facode='$facode' and year='$year' )";
		$result = $this-> db-> query($recordexist);	
		$exist =	$result-> result_array();
		if($exist[0]['exists'] == 't'){
			$existrecord ="select *,village_merger_id as merger_code,vcode as vcode_yearly,less_one_year as pop from situation_analysis_db where facode='$facode' and year='$year'";
			$result = $this-> db-> query($existrecord);	
			$addrecord =	$result->result_array();
			$village_merger_id = "'" .implode( "', '",array_column($addrecord,"merger_code")). "'";
					
			//print_r($village_merger_id); exit();
			$villagerecord="select *,merger_group_id as vcode,totalpopulation as pop from village_merger where facode='$facode' and year='$year' and  merger_group_id not in ($village_merger_id)";
			$result = $this-> db-> query($villagerecord);	
			$vrecord =	$result->result_array();
			
			$data['data'] = array_merge($addrecord,$vrecord);
			return $data['data'];
			
		}else{
			$villagerecord="select *,merger_group_id as vcode,totalpopulation as pop from village_merger where facode='$facode' and year='$year' ";
			$result = $this-> db-> query($villagerecord);	
			$data['data'] = $result->result_array();
			return $data['data'];
		}
		///befor merger//
		/* $recordexist="select  EXISTS(select * from situation_analysis_db where uncode='$uncode' and year='$year' )";
		$result = $this-> db-> query($recordexist);	
		$exist =	$result-> result_array();
		if($exist[0]['exists'] == 't'){
			
			$existrecord ="select *,vcode as vcode_yearly,less_one_year as pop from situation_analysis_db where uncode='$uncode' and year='$year'";
			$result = $this-> db-> query($existrecord);	
			$addrecord =	$result->result_array();
			$vcode = "'" .implode( "', '",array_column($addrecord,"vcode")). "'";
					
			//print_r($village_merger_id);
			$villagerecord="select *,vcode as vcode,population as pop from villages_population where uncode='$uncode' and year='$year' and  vcode not in ($vcode)";
			$result = $this-> db-> query($villagerecord);	
			$vrecord =	$result->result_array();
			
			$data['data'] = array_merge($addrecord,$vrecord);
			return $data['data'];
			
		}else{
			$villagerecord="select *,vcode as vcode,population as pop from villages_population where uncode='$uncode' and year='$year' ";
			$result = $this-> db-> query($villagerecord);	
			$data['data'] = $result->result_array();
			return $data['data'];
		} */
		/* 	$recordexist="select * from microplan_yearly_plan_master where uncode='$uncode' and year='$year' ";
		$result = $this-> db-> query($recordexist);	
		$exist =	$result-> result_array();
		if(isset($exist[0]['pk_id'])){
			$master_id = implode(",",array_column($exist,"pk_id"));
			///////////////////////
			$existrecord ="select *,village_merger_id as merger_code,less_one_year as pop from microplan_yearly_plan_detail where master_id in ($master_id) ";
			$result = $this-> db-> query($existrecord);	
			$ucrecord =	$result->result_array();
			/////////////////////
			$village_merger_id = implode(",",array_column($ucrecord,"village_merger_id"));
			$villagerecord="select *,merger_group_id as merger_code,totalpopulation as pop from village_merger where uncode='$uncode' and year='$year' and  merger_group_id not in ($village_merger_id)";
			$result = $this-> db-> query($villagerecord);	
			$vrecord =	$result->result_array();
			/////////////////////
			$technicianrecord ="SELECT 
									microplan_yearly_plan_master.*,microplan_yearly_plan_master.pk_id as master_id,tehsilname(microplan_yearly_plan_master.tcode) as tehsil, unname(microplan_yearly_plan_master.uncode) as uc_name, facilityname(microplan_yearly_plan_master.facode) as facility,technicianname(microplan_yearly_plan_master.techniciancode) as technician,
									microplan_yearly_plan_detail.*,microplan_yearly_plan_detail.village_merger_id as merger_code,microplan_yearly_plan_detail.less_one_year as pop
								FROM 
									microplan_yearly_plan_master
								FULL OUTER JOIN 
									microplan_yearly_plan_detail 
								ON
									microplan_yearly_plan_master.pk_id=microplan_yearly_plan_detail.master_id
								WHERE 
									 microplan_yearly_plan_master.techniciancode='$techniciancode' ";
			
			//$technicianrecord ="select *,village_merger_id as merger_code,less_one_year as pop,tehsilname(tcode) as tehsil, unname(uncode) as uc_name, facilityname(facode) as facility,technicianname(techniciancode) as technician from microplan_yearly_plan_master where uncode='$uncode' and year='$year' and techniciancode='$techniciancode' and pk_id='$master_id' ";
			$result = $this-> db-> query($technicianrecord);
			$technicianrecord =	$result->result_array();
			if(isset($technicianrecord[0]['techniciancode'] )){
				return $data['data'] = array_merge($technicianrecord,$vrecord);	
			}
			else{
				return $data['data'] = $vrecord;
			}
		}else{
			$villagerecord="select *,merger_group_id as merger_code,totalpopulation as pop from village_merger where uncode='$uncode' and year='$year' ";
			$result = $this-> db-> query($villagerecord);	
			$data['data'] = $result->result_array();
			return $data['data'];
		} */
	}
	public function situation_analysis_edit_model($uncode,$year,$facode){
		$recordexist="select  EXISTS(select * from situation_analysis_db where facode='$facode' and year='$year' )";
		$result = $this-> db-> query($recordexist);	
		$exist =	$result-> result_array();
		if($exist[0]['exists'] == 't'){
			
			$existrecord ="select *,village_merger_id as merger_code,vcode as vcode_yearly,less_one_year as pop from situation_analysis_db where facode='$facode' and year='$year'";
			$result = $this-> db-> query($existrecord);	
			$addrecord =	$result->result_array();
			$village_merger_id = "'" .implode( "', '",array_column($addrecord,"merger_code")). "'";
					
			//print_r($village_merger_id);
			$villagerecord="select *,merger_group_id as vcode,totalpopulation as pop from village_merger where facode='$facode' and year='$year' and  merger_group_id not in ($village_merger_id)";
			$result = $this-> db-> query($villagerecord);	
			$vrecord =	$result->result_array();
			
			$data['data'] = array_merge($addrecord,$vrecord);
			return $data['data'];
			
		}else{
			$villagerecord="select *,merger_group_id as vcode,totalpopulation as pop from village_merger where facode='$facode' and year='$year' ";
			$result = $this-> db-> query($villagerecord);	
			$data['data'] = $result->result_array();
			return $data['data'];
		}
		
		////befor merger////
		/* $recordexist="select  EXISTS(select * from situation_analysis_db where uncode='$uncode' and year='$year' )";
		$result = $this-> db-> query($recordexist);	
		$exist =	$result-> result_array();
		if($exist[0]['exists'] == 't'){
			
			$existrecord ="select *,vcode as vcode_yearly,less_one_year as pop from situation_analysis_db where uncode='$uncode' and year='$year'";
			$result = $this-> db-> query($existrecord);	
			$addrecord =	$result->result_array();
			$vcode = "'" .implode( "', '",array_column($addrecord,"vcode")). "'";
					
			//print_r($village_merger_id);
			$villagerecord="select *,vcode as vcode,population as pop from villages_population where uncode='$uncode' and year='$year' and  vcode not in ($vcode)";
			$result = $this-> db-> query($villagerecord);	
			$vrecord =	$result->result_array();
			
			$data['data'] = array_merge($addrecord,$vrecord);
			return $data['data'];
			
		}else{
			$villagerecord="select *,vcode as vcode,population as pop from villages_population where uncode='$uncode' and year='$year' ";
			$result = $this-> db-> query($villagerecord);	
			$data['data'] = $result->result_array();
			return $data['data'];
		} */
		
	/* $recordexist="select * from microplan_yearly_plan_master where uncode='$uncode' and year='$year' ";
		$result = $this-> db-> query($recordexist);	
		$exist =	$result-> result_array();
		if(isset($exist[0]['pk_id'])){
			$master_id = implode(",",array_column($exist,"pk_id"));
			///////////////////////
			$existrecord ="select *,village_merger_id as merger_code,less_one_year as pop from microplan_yearly_plan_detail where master_id in ($master_id) ";
			$result = $this-> db-> query($existrecord);	
			$ucrecord =	$result->result_array();
			/////////////////////
			$village_merger_id = implode(",",array_column($ucrecord,"village_merger_id"));
			$villagerecord="select *,merger_group_id as merger_code,totalpopulation as pop from village_merger where uncode='$uncode' and year='$year' and  merger_group_id not in ($village_merger_id)";
			$result = $this-> db-> query($villagerecord);	
			$vrecord =	$result->result_array();
			/////////////////////
			$technicianrecord ="SELECT 
									microplan_yearly_plan_master.*,microplan_yearly_plan_master.pk_id as master_id,tehsilname(microplan_yearly_plan_master.tcode) as tehsil, unname(microplan_yearly_plan_master.uncode) as uc_name, facilityname(microplan_yearly_plan_master.facode) as facility,technicianname(microplan_yearly_plan_master.techniciancode) as technician,
									microplan_yearly_plan_detail.*,microplan_yearly_plan_detail.village_merger_id as merger_code,microplan_yearly_plan_detail.less_one_year as pop
								FROM 
									microplan_yearly_plan_master
								FULL OUTER JOIN 
									microplan_yearly_plan_detail 
								ON
									microplan_yearly_plan_master.pk_id=microplan_yearly_plan_detail.master_id
								WHERE 
									 microplan_yearly_plan_master.techniciancode='$techniciancode' ";
			
			//$technicianrecord ="select *,village_merger_id as merger_code,less_one_year as pop,tehsilname(tcode) as tehsil, unname(uncode) as uc_name, facilityname(facode) as facility,technicianname(techniciancode) as technician from microplan_yearly_plan_master where uncode='$uncode' and year='$year' and techniciancode='$techniciancode' and pk_id='$master_id' ";
			$result = $this-> db-> query($technicianrecord);
			$technicianrecord =	$result->result_array();
			if(isset($technicianrecord[0]['techniciancode'] )){
				return $data['data'] = array_merge($technicianrecord,$vrecord);	
			}
			else{
				return $data['data'] = $vrecord;
			}
		}else{
			$villagerecord="select *,merger_group_id as merger_code,totalpopulation as pop from village_merger where uncode='$uncode' and year='$year' ";
			$result = $this-> db-> query($villagerecord);	
			$data['data'] = $result->result_array();
			return $data['data'];
		} */
	}

	
	public function situation_analysis_save_model($situationAnalysisData){
		//print_r($situationAnalysisData);exit();
		if($situationAnalysisData['edit'] != '' || $situationAnalysisData['add_edit'] != '' ){
			$procode = $situationAnalysisData['procode'];
			$distcode = $situationAnalysisData['distcode'];
			$tcode = $situationAnalysisData['tcode'];
			$uncode = $situationAnalysisData['uncode'];
			//print_r($uncode);exit;
			$facode = $situationAnalysisData['facode'];
			$techniciancode = $situationAnalysisData['techniciancode'];
			//$plan_id = $situationAnalysisData['plan_id'];
			$year = $situationAnalysisData['year'];
			$submitted_date = $situationAnalysisData['submitted_date'];		   
			$v_code = $situationAnalysisData['v_code'];
			$village_merger_id = $situationAnalysisData['village_merger_id'];
			$less_one_year = $situationAnalysisData['less_one_year'];
			$f3_total_population = $situationAnalysisData['f3_total_population'];
			$penta1 = $situationAnalysisData['penta1'];
			$penta3= $situationAnalysisData['penta3'];					
			$measles = $situationAnalysisData['measles'];
			$tt2 = $situationAnalysisData['tt2'];
			$penta1_percent = $situationAnalysisData['penta1_percent'];
			$penta3_percent = $situationAnalysisData['penta3_percent'];
			$measles_percent = $situationAnalysisData['measles_percent'];
			$tt2_percent = $situationAnalysisData['tt2_percent'];
			$penta3_not = $situationAnalysisData['penta3_not'];
			$measles_not = $situationAnalysisData['measles_not'];
			$penta1penta3 = $situationAnalysisData['penta1penta3'];
			$penta1measles = $situationAnalysisData['penta1measles'];
			$access = $situationAnalysisData['access'];
			$utilization = $situationAnalysisData['utilization'];
			$category = $situationAnalysisData['category'];
			$priority = $situationAnalysisData['priority'];
			$recid = $situationAnalysisData['id'];
			//echo "abc"; exit();
			if (array_filter($recid)){
				//print_r($recid);exit;
				$rec_id = $this -> checkrecordExist($uncode,$year,$facode);
				$recid = implode( ',' , $recid = $situationAnalysisData['id']);
				$trimrecid=rtrim($recid,',');
				//print_r($trimrecid);exit;
				if($rec_id != ''){
					$query = "delete from situation_analysis_db where facode='$facode' and year='$year' and recid not in ($trimrecid)";
					$result = $this-> db-> query($query);
				}	
			}
			//echo'empty';exit;
			foreach($situationAnalysisData['id'] as $key=>$val){
				$recid = (isset($val) AND $val > 0)?$val:0;
				$edit_array=array(
					'procode' => $procode,
					'distcode' => $distcode,
					'tcode' => $tcode,		   
					'uncode' => $uncode,
					'facode' => $facode,
					//'techniciancode' => $techniciancode,
					'year' => $year,
					'submitted_date' => date("Y-m-d"),
					'updated_date'=>date("Y-m-d"),
					'vcode' => (isset($v_code[$key]) AND $v_code[$key] != '')?$v_code[$key]:NULL,
					'village_merger_id' => (isset($village_merger_id[$key]) AND $village_merger_id[$key] != '')?$village_merger_id[$key]:NULL,
					//'facode' => (isset($facode[$key]) AND $facode[$key] != '')?$facode[$key]:NULL,
					'techniciancode' => (isset($techniciancode[$key]) AND $techniciancode[$key] != '')?$techniciancode[$key]:NULL,
					'less_one_year' => (isset($less_one_year[$key]) AND $less_one_year[$key] > 0)?$less_one_year[$key]:0,
					'f3_total_population' => (isset($f3_total_population[$key]) AND $f3_total_population[$key] > 0)?$f3_total_population[$key]:0,
					'penta1' => (isset($penta1[$key]) AND $penta1[$key] != '')?$penta1[$key]:0,
					'penta3' => (isset($penta3[$key]) AND $penta3[$key] != '')?$penta3[$key]:0,
					'measles' => (isset($measles[$key]) AND $measles[$key] != '')?$measles[$key]:0,
					'tt2' => (isset($tt2[$key]) AND $tt2[$key] != '')?$tt2[$key]:0,
					'penta1_percent' => (isset($penta1_percent[$key]) AND $penta1_percent[$key] != '')?$penta1_percent[$key]:0,
					'penta3_percent' => (isset($penta3_percent[$key]) AND $penta3_percent[$key] != '')?$penta3_percent[$key]:0,
					'measles_percent' => (isset($measles_percent[$key]) AND $measles_percent[$key] != '')?$measles_percent[$key]:0,
					'tt2_percent' => (isset($tt2_percent[$key]) AND $tt2_percent[$key] != '')?$tt2_percent[$key]:0,
					'penta3_not' => (isset($penta3_not[$key]) AND $penta3_not[$key] != '')?$penta3_not[$key]:0,
					'measles_not' => (isset($measles_not[$key]) AND $measles_not[$key] != '')?$measles_not[$key]:0,
					'penta1penta3' => (isset($penta1penta3[$key]) AND $penta1penta3[$key] != '')?$penta1penta3[$key]:0,
					'penta1measles' => (isset($penta1measles[$key]) AND $penta1measles[$key] != '')?$penta1measles[$key]:0,
					'access' => (isset($access[$key]) AND $access[$key] != '')?$access[$key]:NULL,
					'utilization' => (isset($utilization[$key]) AND $utilization[$key] != '')?$utilization[$key]:NULL,
					'category' => (isset($category[$key]) AND $category[$key] > 0)?$category[$key]:0,
					'priority' => (isset($priority[$key]) AND $priority[$key] > 0)?$priority[$key]:0,   
				);
				$vcode=$v_code[$key];
				$vcode_exist=$v_code[$key];
				$vcode_exist = $this -> checkvillageExist($vcode_exist);
				if(isset($vcode_exist) AND $vcode_exist != NULL){
					//echo 'update';
					//print_r($edit_array); exit();
					$this-> Common_model-> update_record('situation_analysis_db',$edit_array,array('facode'=>$facode,'year'=>$year,'vcode'=>$vcode));  
				}else{
					//echo 'inset';
					//print_r($edit_array);
					//exit;
					$this-> Common_model-> insert_record('situation_analysis_db',$edit_array); 
				}		
			}//exit;
			$data['data'] = $this->microplan_yearly_data($uncode,$year,$facode);
			//print_r($data['data']);exit();
			return $data;
		}
	}
	public function situation_analysis_view($uncode,$year,$facode){
		$data['data'] = $this->microplan_yearly_data($uncode,$year,$facode);
		return $data;
		/* $query = "SELECT *,village_merger_id, tehsilname(tcode) as tehsil, unname(uncode) as uc_name, facilityname(facode) as facility,technicianname(techniciancode) as technician, year from microplan_yearly_plan where uncode='$uncode' and year='$year' and techniciancode='$techniciancode' order by priority asc";
		$result = $this-> db-> query($query);	
		$data =	$result-> result_array();
		return $data;	 */
	}

	public function planning_problem_area_save_model($planningProblemData){	
		$uncode = $planningProblemData['uncode'];
		//$techniciancode = $planningProblemData['techniciancode'];
		$facode = $planningProblemData['facode'];
		$year = $planningProblemData['year']; 
		$hard_to_reach = $planningProblemData['hard_to_reach'];
		$reached_last_year = $planningProblemData['reached_last_year'];
		$activities_improve_hf= $planningProblemData['activities_improve_hf'];					
		$activities_need_support = $planningProblemData['activities_need_support'];
		$interventions_delivered = $planningProblemData['interventions_delivered'];
		
		foreach($planningProblemData['v_code'] as $key=>$val){
			$v_code = $planningProblemData['v_code'][$key];
			$rec_id = $planningProblemData['rec_id'][$key];
			$add_array=array(
				'f2_hard_to_reach' => (isset($hard_to_reach[$key]) AND $hard_to_reach[$key] != '')?$hard_to_reach[$key]:NULL,
				'f2_reached_last_year' => (isset($reached_last_year[$key]) AND $reached_last_year[$key] > 0)?$reached_last_year[$key]:0,
				'f2_activities_improve_hf' => (isset($activities_improve_hf[$key]) AND $activities_improve_hf[$key] != '')?$activities_improve_hf[$key]:NULL,
				'f2_activities_need_support' => (isset($activities_need_support[$key]) AND $activities_need_support[$key] != '')?$activities_need_support[$key]:NULL,
				'f2_interventions_delivered' => (isset($interventions_delivered[$key]) AND $interventions_delivered[$key] != '')?$interventions_delivered[$key]:NULL,	
			);
			//print_r($add_array);exit;
			$this-> Common_model-> update_record('situation_analysis_db',$add_array,array('vcode'=>$v_code,'recid'=>$rec_id));	
		}
		$data['data'] = $this->microplan_yearly_data($uncode,$year,$facode);
		return $data;		
	}
	
	public function planning_problem_area_edit_model($uncode,$year,$facode){
		$data['data'] = $this->microplan_yearly_data($uncode,$year,$facode);
		return $data;
	}
	public function planning_problem_area_view($uncode,$year,$facode){	
		$data['data'] = $this->microplan_yearly_data($uncode,$year,$facode);
		return $data;
	}
	public function session_plan_area_save_model($sessionplanData){	
		$uncode = $sessionplanData['uncode'];
		$facode = $sessionplanData['facode'];
		//$techniciancode = $sessionplanData['techniciancode'];
		$year = $sessionplanData['year'];
		$total_population = $sessionplanData['total_population'];
		$target_population = $sessionplanData['target_population'];
		$session_type = $sessionplanData['session_type'];
		$injections_per_year = $sessionplanData['injections_per_year'];
		$injections_per_month = $sessionplanData['injections_per_month'];
		$estimated_sessions = $sessionplanData['estimated_sessions'];
		$sessions_per_month= $sessionplanData['sessions_per_month'];					
		$actual_sessions_plan = $sessionplanData['actual_sessions_plan'];
		$child_survival_interventions = $sessionplanData['child_survival_interventions'];
		$hard_to_reach = $sessionplanData['hard_to_reach'];
		$hard_to_reach_population = $sessionplanData['hard_to_reach_population'];
		$v_code = $sessionplanData['v_code'];
		$rec_id = $sessionplanData['rec_id'];
		foreach($sessionplanData['v_code'] as $key=>$val){
			$v_code = $sessionplanData['v_code'][$key];
			$rec_id = $sessionplanData['rec_id'][$key];
			$add_array=array(
				'f3_total_population' => (isset($total_population[$key]) AND $total_population[$key] > 0)?$total_population[$key]:0,
				'f3_target_population' => (isset($target_population[$key]) AND $target_population[$key] > 0)?$target_population[$key]:0,
				'f3_session_type' => (isset($session_type[$key]) AND $session_type[$key] != '')?$session_type[$key]:NULL,
				'f3_injections_per_year' => (isset($injections_per_year[$key]) AND $injections_per_year[$key] > 0)?$injections_per_year[$key]:0,
				'f3_injections_per_month' => (isset($injections_per_month[$key]) AND $injections_per_month[$key] > 0)?$injections_per_month[$key]:0,
				'f3_estimated_sessions' => (isset($estimated_sessions[$key]) AND $estimated_sessions[$key] > 0)?$estimated_sessions[$key]:0,
				'f3_sessions_per_month' => (isset($sessions_per_month[$key]) AND $sessions_per_month[$key] > 0)?$sessions_per_month[$key]:0,
				'f3_actual_sessions_plan' => (isset($actual_sessions_plan[$key]) AND $actual_sessions_plan[$key] > 0)?$actual_sessions_plan[$key]:NULL,
				'f3_child_survival_interventions' => (isset($child_survival_interventions[$key]) AND $child_survival_interventions[$key] != '')?$child_survival_interventions[$key]:NULL,
				'f3_hard_to_reach' => (isset($hard_to_reach[$key]) AND $hard_to_reach[$key] != '')?$hard_to_reach[$key]:NULL,
				'f3_hard_to_reach_population' => (isset($hard_to_reach_population[$key]) AND $hard_to_reach_population[$key] > 0)?$hard_to_reach_population[$key]:0,	
			);
			$this-> Common_model-> update_record('situation_analysis_db',$add_array,array('recid'=>$rec_id,'vcode'=>$v_code));	         
		}
		$data['data'] = $this->microplan_yearly_data($uncode,$year,$facode);
		return $data;
	}
	public function session_plan_area_edit_model($uncode,$year,$facode){
		$data['data'] = $this->microplan_yearly_data($uncode,$year,$facode);
		return $data;
		/* $data['master_data'] = $this->get_master_data($uncode,$year,$techniciancode);
		$pk_id=$data['master_data'][0]['pk_id'];
		$data['detail_data'] = $this->get_detail_data($pk_id);
		return $data; */
	}
	public function session_plan_view($uncode,$year,$facode){
		$data['data'] = $this->microplan_yearly_data($uncode,$year,$facode);
		return $data;
	}
	public function red_strategy_save_model($redstrategyData){
		//print_r($redstrategyData);exit;
		$uncode = $redstrategyData['uncode'];
		//$techniciancode = $redstrategyData['techniciancode'];
		$facode = $redstrategyData['facode'];
		$year = $redstrategyData['year'];
		$rec_id = $redstrategyData['rec_id'];
		$v_code = $redstrategyData['v_code'];
		//for r1
		$f4_problems_r1_c1 =  $redstrategyData['problems_r1_c1'];
		$f4_actlimitres_r1_c2 = $redstrategyData['actlimitres_r1_c2'];
		$f4_actneedresources_r1_c3 = $redstrategyData['actneedresources_r1_c3'];
		$f4_date_r1_c4 = $redstrategyData['date_r1_c4'];
		$f4_area_r1_c5 = $redstrategyData['area_r1_c5'];
		$f4_person_r1_c6 = $redstrategyData['person_r1_c6'];
		//for r2
		$f4_problems_r2_c1 = $redstrategyData['problems_r2_c1'];
		$f4_actlimitres_r2_c2 = $redstrategyData['actlimitres_r2_c2'];
		$f4_actneedresources_r2_c3 = $redstrategyData['actneedresources_r2_c3'];
		$f4_date_r2_c4 = $redstrategyData['date_r2_c4'];
		$f4_area_r2_c5 = $redstrategyData['area_r2_c5'];
		$f4_person_r2_c6 = $redstrategyData['person_r2_c6'];
		//for r3
		$f4_problems_r3_c1 = $redstrategyData['problems_r3_c1'];
		$f4_actlimitres_r3_c2 = $redstrategyData['actlimitres_r3_c2'];
		$f4_actneedresources_r3_c3 = $redstrategyData['actneedresources_r3_c3'];
		$f4_date_r3_c4 = $redstrategyData['date_r3_c4'];
		$f4_area_r3_c5 = $redstrategyData['area_r3_c5'];
		$f4_person_r3_c6 = $redstrategyData['person_r3_c6'];
		//for r4
		$f4_problems_r4_c1 = $redstrategyData['problems_r4_c1'];
		$f4_actlimitres_r4_c2 = $redstrategyData['actlimitres_r4_c2'];
		$f4_actneedresources_r4_c3 = $redstrategyData['actneedresources_r4_c3'];
		$f4_date_r4_c4 = $redstrategyData['date_r4_c4'];
		$f4_area_r4_c5 = $redstrategyData['area_r4_c5'];
		$f4_person_r4_c6 = $redstrategyData['person_r4_c6'];
		//for r5
		$f4_problems_r5_c1 = $this-> input-> post('problems_r5_c1');
		$f4_actlimitres_r5_c2 = $this-> input-> post('actlimitres_r5_c2');
		$f4_actneedresources_r5_c3 = $this-> input-> post('actneedresources_r5_c3');
		$f4_date_r5_c4 = $this-> input-> post('date_r5_c4');
		$f4_area_r5_c5 = $this-> input-> post('area_r5_c5');
		$f4_person_r5_c6 = $this-> input-> post('person_r5_c6');				 
		for($i=1; $i<=5; $i++){					
			$edit_array['f4_problems_r'.$i.'_c1'] = (isset(${'f4_problems_r'.$i.'_c1'}) AND ${'f4_problems_r'.$i.'_c1'} != '')?${'f4_problems_r'.$i.'_c1'}:NULL;
			$edit_array['f4_actlimitres_r'.$i.'_c2'] = (isset(${'f4_actlimitres_r'.$i.'_c2'}) AND ${'f4_actlimitres_r'.$i.'_c2'} != '')?${'f4_actlimitres_r'.$i.'_c2'}:NULL;
			$edit_array['f4_actneedresources_r'.$i.'_c3'] = (isset(${'f4_actneedresources_r'.$i.'_c3'}) AND ${'f4_actneedresources_r'.$i.'_c3'} != '')?${'f4_actneedresources_r'.$i.'_c3'}:NULL;
			$edit_array['f4_date_r'.$i.'_c4'] = (isset(${'f4_date_r'.$i.'_c4'}) AND ${'f4_date_r'.$i.'_c4'} != '')?date('Y-m-d', strtotime(${'f4_date_r'.$i.'_c4'})):NULL;
			$edit_array['f4_area_r'.$i.'_c5'] = (isset(${'f4_area_r'.$i.'_c5'}) AND ${'f4_area_r'.$i.'_c5'} != '')?${'f4_area_r'.$i.'_c5'}:NULL;
			$edit_array['f4_person_r'.$i.'_c6'] = (isset(${'f4_person_r'.$i.'_c6'}) AND ${'f4_person_r'.$i.'_c6'} != '')?${'f4_person_r'.$i.'_c6'}:NULL;
		}
		$this-> Common_model-> update_record('situation_analysis_db',$edit_array,array('uncode'=>$uncode,'year'=>$year,'facode'=>$facode));		
		$data['data'] = $this->microplan_yearly_data($uncode,$year,$facode);
		return $data;
	}
	
	public function red_strategy_edit_model($uncode,$year,$facode){
		$data['data'] = $this->microplan_yearly_data($uncode,$year,$facode);
		return $data;
	}
	public function red_strategy_view($uncode,$year,$facode){
		$data['data'] = $this->microplan_yearly_data($uncode,$year,$facode);
		return $data;
	}	
	public function red_map_save_model($red_map,$uncode,$year,$facode){
		$this-> Common_model-> update_record('situation_analysis_db',$red_map,array('uncode'=>$uncode,'year'=>$year,'facode'=>$facode));
		return TRUE;
	}
	public function red_map_edit_model($uncode,$year,$facode){
		$data['data'] = $this->microplan_yearly_data($uncode,$year,$facode);
		return $data;
		/* $data['master_data'] = $this->get_master_data($uncode,$year,$techniciancode);
		$pk_id=$data['master_data'][0]['pk_id'];
		$data['detail_data'] = $this->get_detail_data($pk_id);
		return $data; */
	}
	public function red_map_view($uncode,$year,$facode){
		$data['data'] = $this->microplan_yearly_data($uncode,$year,$facode);
		return $data;
	}
	public function microplan_yearly_data($uncode,$year,$facode){
		//echo $uncode; echo ' / '; echo $year; echo ' / '; echo $facode; echo ' / '; exit();  
		$this -> db -> select(' *,tcode,tehsilname(tcode) as tehsil,uncode, unname(uncode) as uc_name, facode,facilityname(facode) as facility,techniciancode,hr_name(techniciancode) as technician, year');
		$this -> db -> from('situation_analysis_db');
		$this -> db -> where(array('uncode'=>$uncode,'year'=>$year,'facode'=>$facode));
		$this->db->order_by('priority', 'ASC');
		//echo $this -> db -> last_query();exit();
		return $this -> db -> get() -> result_array();
	}
	public function get_detail_data($pk_id){	
		$this -> db -> select('*');
		$this -> db -> from('microplan_yearly_plan_detail');
		$this -> db -> where(array('master_id'=>$pk_id));
		return  $this -> db -> get() -> result_array();
	}
	public function Add_microplan_technician_history($situationAnalysisData){	
		$year=$situationAnalysisData['year'];
		$from_date= date("Y-m-d", strtotime('first day of January'.date($year) ));
		$to_date= date("Y-m-d", strtotime('last day of December '.date($year) ));
		$add_array=array(
					'techniciancode' => $situationAnalysisData['techniciancode'],
					'plan_id' => $situationAnalysisData['plan_id'],
					'area_id' => $situationAnalysisData['facode'],
					'creation_date' => date('Y-m-d'),
					'from_date' =>$from_date,
					'to_date' => $to_date
		);
		$this-> Common_model-> insert_record('microplan_technician_history',$add_array); 
	}
	public function checkvillageExist($vcode){
		$this -> db -> select('vcode');
		$this -> db -> from('situation_analysis_db');
		$this -> db -> where('vcode', $vcode);
		$data = $this -> db -> get() -> result_array();
		return $data ;
	}
	public function checkrecordExist($uncode,$year,$facode){
		$this -> db -> select('recid');
		$this -> db -> from('situation_analysis_db');
		$this -> db -> where(array('uncode'=>$uncode,'year'=>$year,'facode'=>$facode));
		$data = $this -> db -> get() -> result_array();
		return $data ;
	}
	public function technician_attachment_view_model($uncode,$year,$techniciancode){
		$query = "SELECT *, tehsilname(tcode) as tehsil, unname(uncode) as uc_name, facilityname(facode) as facility,hr_name(techniciancode) as technician, year from microplan_yearly_plan_master where uncode='$uncode' and year='$year' and  techniciancode='$techniciancode' ";
		$result = $this-> db-> query($query);	
		$data1 =	$result-> result_array();
		$plan_id =$data1[0]['plan_id'];
		$facode=$data1[0]['facode'];
		$query = "SELECT * from microplan_technician_history where plan_id='$plan_id' and facode='$facode'";
		$result = $this-> db-> query($query);	
		$data2 =	$result-> result_array();
	    $data =array_merge($data2,$data1);
		return $data;	
	}
	public function technician_attachment_save_model($tecniciandata){		
		$plan_id=$tecniciandata['plan_id'];
		$facode=$tecniciandata['facode'];
		$update_array=array(
			'techniciancode'=>$tecniciandata['techniciancode'],
		);
		$technician_exist = get_Microplan_Technician_Config($facode,$plan_id);
		if($technician_exist != NULL AND $technician_exist != ''){
			$script = '<script language="javascript" type="text/javascript">';
			$script .= 'alert("This Microplan already attach with technician !!");';
			$script .= 'history.go(-1);';
			$script .= '</script>';
			echo $script;

			exit;
		}else{
			echo 'update';exit;
			//$this-> Common_model-> update_record('microplan_yearly_plan_detail',$update_array,array('plan_id'=>$plan_id,'facode'=>$facode));
		}
		return $data;	
	}	
	
}	
