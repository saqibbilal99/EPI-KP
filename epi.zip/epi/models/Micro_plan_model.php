<?php 
class Micro_plan_model extends CI_Model{
	public function __construct(){
		parent::__construct();
		$this -> load -> model('Common_model');
		$this -> load -> helper('epi_functions_helper'); 
	}
	public function supervisory_plan_edit($supervisorcode,$quarter,$fmonth,$year,$tcode){
		$fmonths=getMonthQuater($quarter);
		//print_r($fmonths); exit;
		$month1=$fmonths['monthm1'];
		$month2=$fmonths['monthm2'];
		$month3=$fmonths['monthm3'];
		//echo $month3;
		$query = "select fmonth from supervisory_plan where supervisorcode='$supervisorcode' and quarter='$quarter'";
		$result = $this->db->query($query);	
		$data =	$result->result_array();
		//$year= substr($data[0]['fmonth'],0,4); 
		$fmonth1=$year.'-'.$month1;
		$fmonth2=$year.'-'.$month2;
		$fmonth3=$year.'-'.$month3;
		//print_r($fmonth3); exit;
		$query = "select *,id,supervisorcode,uncode,designation,fmonth,session_type,site_name,facode,conduct_date,is_conducted,conduct_remarks,submitted_date,area_name,quarter,CASE WHEN quarter='01' then 'Quarter 1' WHEN quarter ='02' then 'Quarter 2' WHEN  quarter='03' then 'Quarter 3' WHEN  quarter='04' then 'Quarter 4' ELSE '' END from supervisory_plan where supervisorcode='$supervisorcode' and quarter = '$quarter'";
		$result = $this->db->query($query);	
		$addm1record =	$result->result_array();
		$tcode=$addm1record[0]['tcode'];
		$uncode = "'" .implode( "', '",array_column($addm1record,"uncode")). "'";
		$ucm1record="select * from unioncouncil  where tcode='$tcode' and  uncode not in ($uncode)";
		$result = $this-> db-> query($ucm1record);	
		$ucm1record =	$result->result_array();
		$data['data']  = array_merge($addm1record,$ucm1record);
		//return $data['m1'];
		//exist
		$checkexist="Select count(supervisorcode) from supervisory_plan where supervisorcode='$supervisorcode' and quarter='$quarter' and fmonth ='$fmonth1'";
		$result= $this->db->query($checkexist);
		$recordexsit =	$result->result_array();
		//print_r($recordexsit[0]['count']);exit;
		if($recordexsit[0]['count'] > 0){
		$query = "select id,supervisorcode,uncode,tcode,designation,fmonth,session_type,site_name,facode,planned_date,is_conducted,remarks,submitted_date,area_name,quarter,CASE WHEN quarter='01' then 'Quarter 1' WHEN quarter ='02' then 'Quarter 2' WHEN  quarter='03' then 'Quarter 3' WHEN  quarter='04' then 'Quarter 4' ELSE '' END from supervisory_plan where supervisorcode='$supervisorcode' and quarter='$quarter'  and fmonth ='$fmonth1'";
		$result = $this->db->query($query);	
		$addm1record =	$result->result_array();
		$tcode=$addm1record[0]['tcode'];
		$uncode = "'" .implode( "', '",array_column($addm1record,"uncode")). "'";
		$ucm1record="select * from unioncouncil  where tcode='$tcode' and  uncode not in ($uncode)";
		$result = $this-> db-> query($ucm1record);	
		$ucm1record =	$result->result_array();
		$data['m1']  = array_merge($addm1record,$ucm1record);
		}else{
		$ucm1record="select * from unioncouncil  where tcode='$tcode' and  uncode not in ($uncode)";
		$result = $this-> db-> query($ucm1record);	
		$ucm1record =	$result->result_array();
		$data['m1']  = array_merge($ucm1record);
		$data['month1']=$month1;
		}
		//return $data['m2'];
		//$data['data']  = array_merge($addm2record);
		$checkexist="Select count(supervisorcode) from supervisory_plan where supervisorcode='$supervisorcode' and quarter='$quarter' and fmonth ='$fmonth2'";
		$result= $this->db->query($checkexist);
		$recordexsit =	$result->result_array();
		//print_r($recordexsit[0]['count']);exit;
		if($recordexsit[0]['count'] > 0){
		$query = "select id,supervisorcode,uncode,tcode,designation,fmonth,session_type,site_name,facode,planned_date,is_conducted,remarks,submitted_date,area_name,quarter,CASE WHEN quarter='01' then 'Quarter 1' WHEN quarter ='02' then 'Quarter 2' WHEN  quarter='03' then 'Quarter 3' WHEN  quarter='04' then 'Quarter 4' ELSE '' END from supervisory_plan where supervisorcode='$supervisorcode' and quarter='$quarter'  and fmonth ='$fmonth2'";
		$result = $this->db->query($query);	
		$addm2record =	$result->result_array();
		$tcode=$addm2record[0]['tcode'];
		$uncode = "'" .implode( "', '",array_column($addm2record,"uncode")). "'";
		$ucm2record="select * from unioncouncil  where tcode='$tcode' and  uncode not in ($uncode)";
		$result = $this-> db-> query($ucm2record);	
		$ucm2record =	$result->result_array();
		$data['m2']  = array_merge($addm2record,$ucm2record);
		}else{
		$ucm2record="select * from unioncouncil  where tcode='$tcode' and  uncode not in ($uncode)";
		$result = $this-> db-> query($ucm2record);	
		$ucm2record =	$result->result_array();
		$data['m2']  = array_merge($ucm2record);
		$data['month2']=$month2;
		//$data['qmonth']='04';
		}//return $data['m3'];
		$checkexist="Select count(supervisorcode) from supervisory_plan where supervisorcode='$supervisorcode' and quarter='$quarter' and fmonth ='$fmonth3'";
		$result= $this->db->query($checkexist);
		$recordexsit =	$result->result_array();
		//print_r($recordexsit[0]['count']);exit;
		if($recordexsit[0]['count'] > 0){
		$query = "select id,supervisorcode,uncode,tcode,designation,fmonth,session_type,site_name,facode,planned_date,is_conducted,remarks,submitted_date,area_name,quarter,CASE WHEN quarter='01' then 'Quarter 1' WHEN quarter ='02' then 'Quarter 2' WHEN  quarter='03' then 'Quarter 3' WHEN  quarter='04' then 'Quarter 4' ELSE '' END from supervisory_plan where supervisorcode='$supervisorcode' and quarter='$quarter'  and fmonth ='$fmonth3'";
		$result = $this->db->query($query);	
		$addm3record =	$result->result_array();
		$tcode=$addm3record[0]['tcode'];
		$uncode = "'" .implode( "', '",array_column($addm3record,"uncode")). "'";
		$ucm3record="select * from unioncouncil  where tcode='$tcode' and  uncode not in ($uncode)";
		$result = $this-> db-> query($ucm3record);	
		//print_r($ucm3record);exit;
		$ucm3record =	$result->result_array();
		$data['m3']  = array_merge($addm3record,$ucm3record);
		}else{
		$ucm3record="select * from unioncouncil  where tcode='$tcode' and  uncode not in ($uncode)";
		$result = $this-> db-> query($ucm3record);	
		$ucm3record =	$result->result_array();
		$data['m3']  = array_merge($ucm3record);
		$data['month3']=$month3;
		//$data['qmonth']='04';
		}	
		
		/* $query = "select id,supervisorcode,uncode,tcode,designation,fmonth,session_type,site_name,facode,planned_date,is_conducted,remarks,submitted_date,area_name,quarter,CASE WHEN quarter='01' then 'Quarter 1' WHEN quarter ='02' then 'Quarter 2' WHEN  quarter='03' then 'Quarter 3' WHEN  quarter='04' then 'Quarter 4' ELSE '' END from supervisory_plan where supervisorcode='$supervisorcode' and quarter='$quarter' and fmonth='$fmonth3'";
		$result = $this->db->query($query);	
		$addm3record =	$result->result_array();
		$tcode=$addm3record[0]['tcode'];
		$uncode = "'" .implode( "', '",array_column($addm3record,"uncode")). "'";
		$ucm3record="select * from unioncouncil  where tcode='$tcode' and  uncode not in ($uncode)";
		$result = $this-> db-> query($ucm3record);	
		$ucm3record =	$result->result_array();
		$data['m3']  = array_merge($addm3record,$ucm3record); */
		
		return $data;
	}
	public function supervisory_plan_conducted($supervisorcode,$quarter,$fmonth,$year){	
        $fmonths=getMonthQuater($quarter);
		//print_r($fmonths); exit();
		$month1=$fmonths['monthm1'];
		$month2=$fmonths['monthm2'];
		$month3=$fmonths['monthm3'];
		$query = "select fmonth from supervisory_plan where supervisorcode='$supervisorcode' and quarter='$quarter'";
		$result = $this->db->query($query);	
		$data =	$result->result_array();
		//$year= substr($data[0]['fmonth'],0,4); 
		$fmonth1=$year.'-'.$month1;
		$fmonth2=$year.'-'.$month2;
		$fmonth3=$year.'-'.$month3;
		//print_r($fmonth3); exit;
		$query = "select *,id,supervisorcode,uncode,designation,fmonth,session_type,site_name,facode,conduct_date,is_conducted,conduct_remarks,submitted_date,area_name,quarter,CASE WHEN quarter='01' then 'Quarter 1' WHEN quarter ='02' then 'Quarter 2' WHEN  quarter='03' then 'Quarter 3' WHEN  quarter='04' then 'Quarter 4' ELSE '' END,health_facility_monitoring_fill from supervisory_plan where supervisorcode='$supervisorcode' and quarter='$quarter'  and fmonth ='$fmonth1'";
		$result = $this->db->query($query);	
		$data['data'] =	$result->result_array();
		//return $data['m1'];
		$query = "select *,id,supervisorcode,uncode,designation,fmonth,session_type,site_name,facode,conduct_date,is_conducted,conduct_remarks,submitted_date,area_name,quarter,CASE WHEN quarter='01' then 'Quarter 1' WHEN quarter ='02' then 'Quarter 2' WHEN  quarter='03' then 'Quarter 3' WHEN  quarter='04' then 'Quarter 4' ELSE '' END,health_facility_monitoring_fill from supervisory_plan where supervisorcode='$supervisorcode' and quarter='$quarter'  and fmonth ='$fmonth1'";
		$result = $this->db->query($query);	
		$data['m1'] =	$result->result_array();
		//return $data['m1'];
		$query = "select *,id,supervisorcode,uncode,designation,fmonth,session_type,site_name,facode,conduct_date,is_conducted,conduct_remarks,submitted_date,area_name,quarter,CASE WHEN quarter='01' then 'Quarter 1' WHEN quarter ='02' then 'Quarter 2' WHEN  quarter='03' then 'Quarter 3' WHEN  quarter='04' then 'Quarter 4' ELSE '' END,health_facility_monitoring_fill from supervisory_plan where supervisorcode='$supervisorcode' and quarter='$quarter'  and fmonth ='$fmonth2'";
		$result = $this->db->query($query);	
		$data['m2'] =	$result->result_array();
		//return $data['m2'];
		$query = "select *,id,supervisorcode,uncode,designation,fmonth,session_type,site_name,facode,conduct_date,is_conducted,conduct_remarks,submitted_date,area_name,quarter,CASE WHEN quarter='01' then 'Quarter 1' WHEN quarter ='02' then 'Quarter 2' WHEN  quarter='03' then 'Quarter 3' WHEN  quarter='04' then 'Quarter 4' ELSE '' END,health_facility_monitoring_fill from supervisory_plan where supervisorcode='$supervisorcode' and quarter='$quarter'  and fmonth ='$fmonth3'";
		$result = $this->db->query($query);	
		$data['m3'] =	$result->result_array();
		//return $data['m3'];
		//print_r($data); exit();
		return $data;		
	}
	public function supervisory_plan(){	
	    $distcode = $this-> session->District;
		$query = "select supervisorcode, designation, quarter, status, substr(fmonth,1,4) as year, CASE WHEN quarter='01' then 'Quarter 1' WHEN quarter ='02' then 'Quarter 2' WHEN  quarter='03' then 'Quarter 3' WHEN  quarter='04' then 'Quarter 4' ELSE '' END from supervisory_plan where distcode='$distcode' group by supervisorcode, quarter, designation, status, substr(fmonth,1,4) ";
		$result = $this->db->query($query);	 
		$data['data'] =	$result->result_array();
		$query = "SELECT distinct designation from supervisory_plan order by designation ASC";
		$Sup_result = $this -> db -> query($query);
		$data['resultSuper_type'] = $Sup_result -> result_array();
		//print_r($data[0]);
		return $data;	
	}
	public function supervisory_plan_view($supervisorcode,$quarter,$year){	
		$fmonths=getMonthQuater($quarter);
		
		$month1=$fmonths['monthm1'];
		$month2=$fmonths['monthm2'];
		$month3=$fmonths['monthm3'];
		$query = "select fmonth from supervisory_plan where supervisorcode='$supervisorcode' and quarter='$quarter'";
		$result = $this->db->query($query);	
		$data =	$result->result_array();
		//$year= substr($data[0]['fmonth'],0,4); 

		$fmonth1=$year.'-'.$month1;
		$fmonth2=$year.'-'.$month2;
		$fmonth3=$year.'-'.$month3; 
		//print_r($fmonth); exit;
		$query = "select *,id,supervisorcode,uncode,designation,fmonth,session_type,site_name,facode,conduct_date,is_conducted,conduct_remarks,submitted_date,area_name,quarter,CASE WHEN quarter='01' then 'Quarter 1' WHEN quarter ='02' then 'Quarter 2' WHEN  quarter='03' then 'Quarter 3' WHEN  quarter='04' then 'Quarter 4' ELSE '' END,health_facility_monitoring_fill from supervisory_plan where supervisorcode='$supervisorcode'";
		$result = $this->db->query($query);	
		$data['data'] =	$result->result_array();
		//print_r($fmonth3); exit;
		 $query = "select *,CASE WHEN quarter='01' then 'Quarter 1' WHEN quarter ='02' then 'Quarter 2' WHEN  quarter='03' then 'Quarter 3' WHEN  quarter='04' then 'Quarter 4' ELSE '' END from supervisory_plan where supervisorcode='$supervisorcode' and quarter='$quarter' and fmonth = '$fmonth1'";
		//$query = "select *,CASE WHEN quarter='01' then 'Quarter 1' WHEN quarter ='02' then 'Quarter 2' WHEN  quarter='03' then 'Quarter 3' WHEN  quarter='04' then 'Quarter 4' ELSE '' END from supervisory_plan where supervisorcode='$supervisorcode' and quarter='$quarter' and 'fmonth' like '$year'";
		$result = $this->db->query($query);	
		$data['m1'] =	$result->result_array();
		//return $data['m1'];
		$query = "select *,CASE WHEN quarter='01' then 'Quarter 1' WHEN quarter ='02' then 'Quarter 2' WHEN  quarter='03' then 'Quarter 3' WHEN  quarter='04' then 'Quarter 4' ELSE '' END from supervisory_plan where supervisorcode='$supervisorcode' and quarter='$quarter' and fmonth = '$fmonth2'";
		//$query = "select *,CASE WHEN quarter='01' then 'Quarter 1' WHEN quarter ='02' then 'Quarter 2' WHEN  quarter='03' then 'Quarter 3' WHEN  quarter='04' then 'Quarter 4' ELSE '' END from supervisory_plan where supervisorcode='$supervisorcode' and quarter='$quarter' and fmonth='$fmonth2'";
		$result = $this->db->query($query);	
		$data['m2'] =	$result->result_array();
		//return $data['m2'];
		//$query = "select *,CASE WHEN quarter='01' then 'Quarter 1' WHEN quarter ='02' then 'Quarter 2' WHEN  quarter='03' then 'Quarter 3' WHEN  quarter='04' then 'Quarter 4' ELSE '' END from supervisory_plan where supervisorcode='$supervisorcode' and quarter='$quarter' and  'fmonth' like '$year'";
		//echo $query = "select *,CASE WHEN quarter='01' then 'Quarter 1' WHEN quarter ='02' then 'Quarter 2' WHEN  quarter='03' then 'Quarter 3' WHEN  quarter='04' then 'Quarter 4' ELSE '' END from supervisory_plan where supervisorcode='$supervisorcode' and quarter='$quarter' and 'fmonth' like '$year'%"; exit;
		 $query = "select *,CASE WHEN quarter='01' then 'Quarter 1' WHEN quarter ='02' then 'Quarter 2' WHEN  quarter='03' then 'Quarter 3' WHEN  quarter='04' then 'Quarter 4' ELSE '' END from supervisory_plan where supervisorcode='$supervisorcode' and quarter='$quarter' and fmonth = '$fmonth3'";
		$result = $this->db->query($query);	
		$data['m3'] =	$result->result_array();
		//return $data['m3'];
		return $data;	
	}
	public function health_facility_monitoring_add_model($quarter,$id){
		$this->db->select('*');
		$this->db->from('supervisory_plan');	
		$this->db->where('quarter',$quarter);
		$this->db->where('id',$id);
		$data['data'] =  $this -> db -> get() -> result_array();
		$this->db->select('*');
		$this->db->from('health_facility_monitoring');	
		$this->db->where('fk_id',$id);
		$data['hfmdata'] =  $this -> db -> get() -> result_array();
		return $data;		
	}
	public function fixed_session_monitoring_add_model($quarter,$id){		
		$this->db->select('*');
		$this->db->from('supervisory_plan');
		$this->db->where('quarter',$quarter);
		$this->db->where('id',$id);
		$data['data'] =  $this -> db -> get() -> result_array();
		$this->db->select('*');
		$this->db->from('fixed_session_monitoring');	
		$this->db->where('fk_id',$id);
		$data['fsmdata'] =  $this -> db -> get() -> result_array();
		return $data;	
	}
	public function outreach_session_monitoring_add_model($quarter,$id){		
		$this->db->select('*');
		$this->db->from('supervisory_plan');	
		$this->db->where('quarter',$quarter);
		$this->db->where('id',$id);
		$data['data'] =  $this -> db -> get() -> result_array();
		$this->db->select('*');
		$this->db->from('outreach_session_monitoring');	
		$this->db->where('fk_id',$id);
		$data['ormdata'] =  $this -> db -> get() -> result_array();
		return $data;
	}
	public function house_hold_cluster_assesment_add_model($quarter,$id){			
		$this->db->select('*');
		$this->db->from('supervisory_plan');		
		$this->db->where('quarter',$quarter);
		$this->db->where('id',$id);
		$data['data'] =  $this -> db -> get() -> result_array();
		$this->db->select('*');
		$this->db->from('house_hold_cluster_assesment');	
		$this->db->where('fk_id',$id);
		$data['hhcdata'] =  $this -> db -> get() -> result_array();
		
		return $data;	
	}
	public function community_verification_add_model($facode,$area_name,$quarter,$id){		
		$this->db->select('*');
		$this->db->from('supervisory_plan');		
		$this->db->where('quarter',$quarter);
		$this->db->where('id',$id);
		return $this -> db -> get() -> result_array();
	}
	public function health_facility_monitoring_save_model($checklist_data){	
		$edit = $this->input->post('edit');
		$id = $this->input->post('pk_id');
		$area_code = $this->input->post('area_name');
		$quarter = $this->input->post('quarter');
		$supervisorcode = $this->input->post('supervisor_name');
		$fmonths=getMonthQuater($quarter);
		
		$month1=$fmonths['monthm1'];
		$month2=$fmonths['monthm2'];
		$month3=$fmonths['monthm3'];
		$query = "select fmonth from supervisory_plan where supervisorcode='$supervisorcode' and quarter='$quarter'";
		$result = $this->db->query($query);	
		$data =	$result->result_array();
		$year= substr($data[0]['fmonth'],0,4); 
		if($edit!="" AND $edit=="edit" ) {
			$this->db->update('health_facility_monitoring',$checklist_data,array('pk_id' => $id,'area_code'=>$area_code,'quarter'=>$quarter));
			$this -> session -> set_flashdata('message','You have successfully Updated your record!'); 
			$location = base_url()."micro_plan/Micro_plan_controller/supervisory_plan_conducted/".$supervisorcode."/".$quarter."/".$year;
			redirect($location);
		}else{
			$this->db->insert('health_facility_monitoring',$checklist_data);
			$this -> session -> set_flashdata('message','You have successfully Add your record!'); 
			$location = base_url()."micro_plan/Micro_plan_controller/supervisory_plan_conducted/".$supervisorcode."/".$quarter."/".$year;
			redirect($location);
		}		
	}
	public function fixed_session_monitoring_save_model($checklist_data){	
		$edit = $this->input->post('edit');
		$id = $this->input->post('pk_id');
		$area_code = $this->input->post('area_name');
		$supervisorcode = $this->input->post('supervisor_name');
		$quarter = $this->input->post('quarter');
		$fmonths=getMonthQuater($quarter);
		
		$month1=$fmonths['monthm1'];
		$month2=$fmonths['monthm2'];
		$month3=$fmonths['monthm3'];
		$query = "select fmonth from supervisory_plan where supervisorcode='$supervisorcode' and quarter='$quarter'";
		$result = $this->db->query($query);	
		$data =	$result->result_array();
		$year= substr($data[0]['fmonth'],0,4); 
		if($edit!="" AND $edit=="edit" ) {
			$this->db->update('fixed_session_monitoring',$checklist_data,array('pk_id' => $id,'area_code'=>$area_code,'quarter'=>$quarter));
			$this -> session -> set_flashdata('message','You have successfully Updated your record!'); 
			$location = base_url()."micro_plan/Micro_plan_controller/supervisory_plan_conducted/".$supervisorcode."/".$quarter."/".$year;
			redirect($location);
		}else{
			$this->db->insert('fixed_session_monitoring',$checklist_data);	
			$this -> session -> set_flashdata('message','You have successfully Add your record!'); 
			$location = base_url()."micro_plan/Micro_plan_controller/supervisory_plan_conducted/".$supervisorcode."/".$quarter."/".$year;
			redirect($location);
		}
	}
	public function outreach_session_monitoring_save_model($checklist_data){	
		$edit = $this->input->post('edit');
		$id = $this->input->post('pk_id');
		$area_code = $this->input->post('area_name');
		$supervisorcode = $this->input->post('supervisor_name');
		$quarter = $this->input->post('quarter');
		$fmonths=getMonthQuater($quarter);
		
		$month1=$fmonths['monthm1'];
		$month2=$fmonths['monthm2'];
		$month3=$fmonths['monthm3'];
		$query = "select fmonth from supervisory_plan where supervisorcode='$supervisorcode' and quarter='$quarter'";
		$result = $this->db->query($query);	
		$data =	$result->result_array();
		$year= substr($data[0]['fmonth'],0,4); 
		if($edit!="" AND $edit=="edit" ) {
			$this->db->update('outreach_session_monitoring',$checklist_data,array('pk_id' => $id,'area_code'=>$area_code,'quarter'=>$quarter));
			$this -> session -> set_flashdata('message','You have successfully Updated your record!'); 
			$location = base_url()."micro_plan/Micro_plan_controller/supervisory_plan_conducted/".$supervisorcode."/".$quarter."/".$year;
			redirect($location);
		}else{
			$this->db->insert('outreach_session_monitoring',$checklist_data);	
			$this -> session -> set_flashdata('message','You have successfully Add your record!'); 
			$location = base_url()."micro_plan/Micro_plan_controller/supervisory_plan_conducted/".$supervisorcode."/".$quarter."/".$year;
			redirect($location);			
		}
	}
	public function house_hold_cluster_assesment_save_model($cluster_data){	
		$edit = $this->input->post('edit');
		$id = $this->input->post('pk_id');
		$area_code = $this->input->post('area_code');
		$supervisorcode = $this->input->post('supervisor_name');
		$quarter = $this->input->post('quarter');
		$fmonths=getMonthQuater($quarter);
		
		$month1=$fmonths['monthm1'];
		$month2=$fmonths['monthm2'];
		$month3=$fmonths['monthm3'];
		$query = "select fmonth from supervisory_plan where supervisorcode='$supervisorcode' and quarter='$quarter'";
		$result = $this->db->query($query);	
		$data =	$result->result_array();
		$year= substr($data[0]['fmonth'],0,4); 
		
		if($edit!="" AND $edit=="edit" ) {
			$this->db->update('house_hold_cluster_assesment',$cluster_data,array('pk_id' => $id,'area_code'=>$area_code,'quarter'=>$quarter));
			$this -> session -> set_flashdata('message','You have successfully Updated your record!'); 
			$location = base_url()."micro_plan/Micro_plan_controller/supervisory_plan_conducted/".$supervisorcode."/".$quarter."/".$year;
			redirect($location);
		}else{
			$this->db->insert('house_hold_cluster_assesment',$cluster_data);
			$this -> session -> set_flashdata('message','You have successfully Add your record!'); 
			$location = base_url()."micro_plan/Micro_plan_controller/supervisory_plan_conducted/".$supervisorcode."/".$quarter."/".$year;
			redirect($location);	
		}
		                   
	}
}